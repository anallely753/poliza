

<?php $__env->startSection('content'); ?>

  <div class="body-tabs_inter">
    <main class="main-inter">
     <section class="container-fluid tabs-inter">
      <div class="main-inter_header">
        <!-- Flex header -->
       <div class="main-inter_flex">
         <div class="main-inter_header_titulos">
           <h4>No. Poliza</h4>
           <h3 class="main-inter_h3"><?php echo e($noPoliza); ?></h3>
         </div>
          <div>
            <a href="<?php echo e(url('/')); ?>" class="ver-tabla ">Ver tabla general</a>
            <img src="<?php echo e(asset('img/logos-tabs.svg')); ?>" alt="">
          </div>
       </div>

       
       <div class="tab-content d-none">
          
            <div class="tab-pane fade show active" >
              
              <div class="table-title">Datos</div>
              <table class="table table-hover table-responsive ">
                <thead>
                  <tr class="fixed-table">
                    
                    <th scope="col">Pagina</th>
                    <th scope="col">Plazo</th>
                    <th scope="col">Forma de Pago</th>
                    <th scope="col">Contributorio</th>
                    <th scope="col">Inicio Vigencia</th>
                    <th scope="col">Fin Vigencia</th>
                    <th scope="col">Tipo de Administracion</th>
                    <th scope="col">Datos del contratante</th>
                    <th scope="col">Prima Neta</th>
                    <th scope="col">Recargos</th>
                    <th scope="col">Gastos expedición</th>
                    <th scope="col">IVA</th>
                    <th scope="col">Prima Total</th>
                    <th scope="col">Moneda</th>
                    <span class="d-none"><?php echo e($numColumnas=13); ?></span>
                  </tr>
                </thead>
                <tbody>
                  <?php $__currentLoopData = $caratula_datos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $caratula_dato): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <tr>
                    
                    <td><?php echo e($caratula_dato->pagina); ?></td>
                    <td>
                      <?php if($caratula_dato->plazo == 1): ?>
                      <div class="checkdiv"><input disabled checked type="checkbox" class="le-checkbox"/></div>
                      <span class="d-none"><?php echo e($numAciertos++); ?></span>
                      <?php elseif($caratula_dato->plazo == 0): ?>
                      <div class="checkdiv"><input disabled  type="checkbox" class="le-checkbox"/></div>
                      <?php else: ?>
                      <img src="<?php echo e(asset('img/unknown.png')); ?>" alt="" width="32">
                      <?php endif; ?>
                    </td>
                    <td>
                      <?php if($caratula_dato->formaDePago == 1): ?>
                      <span class="d-none"><?php echo e($numAciertos++); ?></span>
                      <div class="checkdiv"><input disabled checked type="checkbox" class="le-checkbox"/></div>
                      <?php elseif($caratula_dato->formaDePago == 0): ?>
                      <div class="checkdiv"><input disabled  type="checkbox" class="le-checkbox"/></div>
                      <?php else: ?>
                      <img src="<?php echo e(asset('img/unknown.png')); ?>" alt="" width="32">
                      <?php endif; ?>
                    </td>
                    <td>
                      <?php if($caratula_dato->contributorio == 1): ?>
                      <span class="d-none"><?php echo e($numAciertos++); ?></span>
                      <div class="checkdiv"><input disabled checked type="checkbox" class="le-checkbox"/></div>
                      <?php elseif($caratula_dato->contributorio == 0): ?>
                      <div class="checkdiv"><input disabled  type="checkbox" class="le-checkbox"/></div>
                      <?php else: ?>
                      <img src="<?php echo e(asset('img/unknown.png')); ?>" alt="" width="32">
                      <?php endif; ?>
                    </td>
                    <td>
                      <?php if($caratula_dato->inicioVigencia == 1): ?>
                      <span class="d-none"><?php echo e($numAciertos++); ?></span>
                      <div class="checkdiv"><input disabled checked type="checkbox" class="le-checkbox"/></div>
                      <?php elseif($caratula_dato->inicioVigencia == 0): ?>
                      <div class="checkdiv"><input disabled  type="checkbox" class="le-checkbox"/></div>
                      <?php else: ?>
                      <img src="<?php echo e(asset('img/unknown.png')); ?>" alt="" width="32">
                      <?php endif; ?>
                    </td>
                    <td>
                      <?php if($caratula_dato->finVigencia == 1): ?>
                      <span class="d-none"><?php echo e($numAciertos++); ?></span>
                      <div class="checkdiv"><input disabled checked type="checkbox" class="le-checkbox"/></div>
                      <?php elseif($caratula_dato->finVigencia == 0): ?>
                      <div class="checkdiv"><input disabled  type="checkbox" class="le-checkbox"/></div>
                      <?php else: ?>
                      <img src="<?php echo e(asset('img/unknown.png')); ?>" alt="" width="32">
                      <?php endif; ?>
                    </td>
                    <td>
                      <?php if($caratula_dato->tipoDeAdministracion == 1): ?>
                      <span class="d-none"><?php echo e($numAciertos++); ?></span>
                      <div class="checkdiv"><input disabled checked type="checkbox" class="le-checkbox"/></div>
                      <?php elseif($caratula_dato->tipoDeAdministracion == 0): ?>
                      <div class="checkdiv"><input disabled  type="checkbox" class="le-checkbox"/></div>
                      <?php else: ?>
                      <img src="<?php echo e(asset('img/unknown.png')); ?>" alt="" width="32">
                      <?php endif; ?>
                    </td>
                    <td>
                      <?php if($caratula_dato->datosDelContratante == 1): ?>
                      <span class="d-none"><?php echo e($numAciertos++); ?></span>
                      <div class="checkdiv"><input disabled checked type="checkbox" class="le-checkbox"/></div>
                      <?php elseif($caratula_dato->datosDelContratante == 0): ?>
                      <div class="checkdiv"><input disabled  type="checkbox" class="le-checkbox"/></div>
                      <?php else: ?>
                      <img src="<?php echo e(asset('img/unknown.png')); ?>" alt="" width="32">
                      <?php endif; ?>
                    </td>
                    <td>
                      <?php if($caratula_dato->primaNeta == 1): ?>
                      <span class="d-none"><?php echo e($numAciertos++); ?></span>
                      <div class="checkdiv"><input disabled checked type="checkbox" class="le-checkbox"/></div>
                      <?php elseif($caratula_dato->primaNeta == 0): ?>
                      <div class="checkdiv"><input disabled  type="checkbox" class="le-checkbox"/></div>
                      <?php else: ?>
                      <img src="<?php echo e(asset('img/unknown.png')); ?>" alt="" width="32">
                      <?php endif; ?>
                    </td>
                    <td>
                      <?php if($caratula_dato->recargos == 1): ?>
                      <span class="d-none"><?php echo e($numAciertos++); ?></span>
                      <div class="checkdiv"><input disabled checked type="checkbox" class="le-checkbox"/></div>
                      <?php elseif($caratula_dato->recargos == 0): ?>
                      <div class="checkdiv"><input disabled  type="checkbox" class="le-checkbox"/></div>
                      <?php else: ?>
                      <img src="<?php echo e(asset('img/unknown.png')); ?>" alt="" width="32">
                      <?php endif; ?>
                    </td>
                    <td>
                      <?php if($caratula_dato->gtosExpedicion == 1): ?>
                      <span class="d-none"><?php echo e($numAciertos++); ?></span>
                      <div class="checkdiv"><input disabled checked type="checkbox" class="le-checkbox"/></div>
                      <?php elseif($caratula_dato->gtosExpedicion == 0): ?>
                      <div class="checkdiv"><input disabled  type="checkbox" class="le-checkbox"/></div>
                      <?php else: ?>
                      <img src="<?php echo e(asset('img/unknown.png')); ?>" alt="" width="32">
                      <?php endif; ?>
                    </td>
                    <td>
                      <?php if($caratula_dato->IVA == 1): ?>
                      <span class="d-none"><?php echo e($numAciertos++); ?></span>
                      <div class="checkdiv"><input disabled checked type="checkbox" class="le-checkbox"/></div>
                      <?php elseif($caratula_dato->IVA == 0): ?>
                      <div class="checkdiv"><input disabled  type="checkbox" class="le-checkbox"/></div>
                      <?php else: ?>
                      <img src="<?php echo e(asset('img/unknown.png')); ?>" alt="" width="32">
                      <?php endif; ?>
                    </td>
                    <td>
                      <?php if($caratula_dato->primaTotal == 1): ?>
                      <span class="d-none"><?php echo e($numAciertos++); ?></span>
                      <div class="checkdiv"><input disabled checked type="checkbox" class="le-checkbox"/></div>
                      <?php elseif($caratula_dato->primaTotal == 0): ?>
                      <div class="checkdiv"><input disabled  type="checkbox" class="le-checkbox"/></div>
                      <?php else: ?>
                      <img src="<?php echo e(asset('img/unknown.png')); ?>" alt="" width="32">
                      <?php endif; ?>
                    </td>
                    <td>
                      <?php if($caratula_dato->moneda == 1): ?>
                      <span class="d-none"><?php echo e($numAciertos++); ?></span>
                      <div class="checkdiv"><input disabled checked type="checkbox" class="le-checkbox"/></div>
                      <?php elseif($caratula_dato->moneda == 0): ?>
                      <div class="checkdiv"><input disabled  type="checkbox" class="le-checkbox"/></div>
                      <?php else: ?>
                      <img src="<?php echo e(asset('img/unknown.png')); ?>" alt="" width="32">
                      <?php endif; ?>
                    </td>
                  </tr>
                  <span class="d-none"><?php echo e($contador++); ?></span>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  <div class="btn-success d-none">Aciertos Datos= <?php echo e($numAciertos); ?>/<?php echo e($numColumnas*$contador); ?></div>
                </tbody>
              </table>
              
              <span class="d-none"><?php echo e($guardarAciertos=$numAciertos, $guardarColumnas=$numColumnas*$contador); ?></span>
             
              
              <div class="table-title">Coberturas</div>
              <span class="d-none"><?php echo e($numAciertos=0, $numColumnas=0, $contador=0); ?></span>
              <table class="table table-hover  table-responsive ">
                <thead>
                  <tr class="fixed-table">
                    
                    <th scope="col">Pagina</th>
                    <th scope="col">Cobertura</th>
                    <th scope="col">Suma Asegurada</th>
                    <th scope="col">Prima Neta</th>
                    <span class="d-none"><?php echo e($numColumnas=2); ?></span>
                  </tr>
                </thead>
                  
                <tbody>
                  <?php $__currentLoopData = $caratula_coberturas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $caratula_cobertura): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <tr>
                    
                    <td><?php echo e($caratula_cobertura->pagina); ?></td>
                    <td>
                      <?php echo e($caratula_cobertura->cobertura); ?>

                    </td>
                    <td>
                      <?php if($caratula_cobertura->sumaAsegurada == 1): ?>
                      <div class="checkdiv"><input disabled checked type="checkbox" class="le-checkbox"/></div>
                      <span class="d-none"><?php echo e($numAciertos++); ?></span>

                      <?php elseif($caratula_cobertura->sumaAsegurada == 0): ?>
                      <div class="checkdiv"><input disabled  type="checkbox" class="le-checkbox"/></div>
                      <?php else: ?>
                      <img src="<?php echo e(asset('img/unknown.png')); ?>" alt="" width="32">
                      <?php endif; ?>
                    </td>
                    <td>
                      <?php if($caratula_cobertura->primaNeta == 1): ?>
                      <span class="d-none"><?php echo e($numAciertos++); ?></span>
                      <div class="checkdiv"><input disabled checked type="checkbox" class="le-checkbox"/></div>
                      <?php elseif($caratula_cobertura->primaNeta == 0): ?>
                      <div class="checkdiv"><input disabled  type="checkbox" class="le-checkbox"/></div>
                      <?php else: ?>
                      <img src="<?php echo e(asset('img/unknown.png')); ?>" alt="" width="32">
                      <?php endif; ?>
                    </td>
                  </tr>
                  <span class="d-none"><?php echo e($contador++); ?></span>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  <div class="btn-success d-none">Aciertos Coberturas = <?php echo e($numAciertos); ?>/<?php echo e($numColumnas*$contador); ?></div>
                </tbody>
              </table>
              <span class="d-none"><?php echo e($guardarAciertos=$guardarAciertos+$numAciertos, $guardarColumnas=$guardarColumnas+($numColumnas*$contador)); ?></span>

              
              <div class="btn-success d-none position-absolute"><?php echo e($caratulaA = $guardarAciertos); ?>/<?php echo e($caratulaC = $guardarColumnas); ?></div>

                 
            </div>

          
            <div class="tab-pane fade" >
              <form class="d-flex w-25" id="searchform" onkeyup="filterConsentimientos()">
                <input class="form-control me-2 d-flex shadow-none" type="text" placeholder="No. de certificado" id="searchConsentimientos">
                <button type="submit" disabled><img src="<?php echo e(asset('img/search.svg')); ?>"  alt="" ></button/>
              </form>
              <span class="d-none"><?php echo e($numAciertos=0, $contador=0); ?></span>
              <table class="table table-hover table-responsive ">
                <thead>
                  <tr class="fixed-table">
                    
                    <th scope="col">Certificado</th>
                    <th scope="col">Nombre</th>
                    <th scope="col">Sexo</th>
                    <th scope="col">Edad</th>
                    <th scope="col">Fecha de Nacimiento</th>
                    <th scope="col">Datos del contratante</th>
                    <th scope="col">Plazo</th>
                    <th scope="col">Forma de Pago</th>
                    <th scope="col">Contributorio</th>
                    <th scope="col">Inicio Vigencia</th>
                    <th scope="col">Fin Vigencia</th>
                    <th scope="col">Moneda</th>
                    <span class="d-none"><?php echo e($numColumnas=11); ?></span>
                  </tr>
                </thead>
                <tbody id="tbody-consentimientos_vida_datos">
                  <?php $__currentLoopData = $consentimientos_vida_datos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $consentimientos_vida_dato): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <tr class="tr-consentimientos_vida_datos">
                    <td class="tr-td-certificado-consentimientos_vida_datos"><?php echo e($consentimientos_vida_dato->certificado); ?></td>
                    <td>
                      <?php if($consentimientos_vida_dato->nombre == 1): ?>
                      <span class="d-none"><?php echo e($numAciertos++); ?></span>
                      <div class="checkdiv"><input disabled checked type="checkbox" class="le-checkbox"/></div>
                      <?php elseif($consentimientos_vida_dato->nombre == 0): ?>
                      <div class="checkdiv"><input disabled  type="checkbox" class="le-checkbox"/></div>
                      <?php else: ?>
                      <img src="<?php echo e(asset('img/unknown.png')); ?>" alt="" width="32">
                      <?php endif; ?>
                    </td>
                    <td>
                      <?php if($consentimientos_vida_dato->sexo == 1): ?>
                      <span class="d-none"><?php echo e($numAciertos++); ?></span>
                      <div class="checkdiv"><input disabled checked type="checkbox" class="le-checkbox"/></div>
                      <?php elseif($consentimientos_vida_dato->nombre == 0): ?>
                      <div class="checkdiv"><input disabled  type="checkbox" class="le-checkbox"/></div>
                      <?php else: ?>
                      <img src="<?php echo e(asset('img/unknown.png')); ?>" alt="" width="32">
                      <?php endif; ?>
                    </td>
                    <td>
                      <?php if($consentimientos_vida_dato->edad == 1): ?>
                      <span class="d-none"><?php echo e($numAciertos++); ?></span>
                      <div class="checkdiv"><input disabled checked type="checkbox" class="le-checkbox"/></div>
                      <?php elseif($consentimientos_vida_dato->edad == 0): ?>
                      <div class="checkdiv"><input disabled  type="checkbox" class="le-checkbox"/></div>
                      <?php else: ?>
                      <img src="<?php echo e(asset('img/unknown.png')); ?>" alt="" width="32">
                      <?php endif; ?>
                    </td>
                    <td>
                      <?php if($consentimientos_vida_dato->fechaDeNacimiento == 1): ?>
                      <span class="d-none"><?php echo e($numAciertos++); ?></span>
                      <div class="checkdiv"><input disabled checked type="checkbox" class="le-checkbox"/></div>
                      <?php elseif($consentimientos_vida_dato->fechaDeNacimiento == 0): ?>
                      <div class="checkdiv"><input disabled  type="checkbox" class="le-checkbox"/></div>
                      <?php else: ?>
                      <img src="<?php echo e(asset('img/unknown.png')); ?>" alt="" width="32">
                      <?php endif; ?>
                    </td>
                    <td>
                      <?php if($consentimientos_vida_dato->datosDelContratante == 1): ?>
                      <span class="d-none"><?php echo e($numAciertos++); ?></span>
                      <div class="checkdiv"><input disabled checked type="checkbox" class="le-checkbox"/></div>
                      <?php elseif($consentimientos_vida_dato->datosDelContratante == 0): ?>
                      <div class="checkdiv"><input disabled  type="checkbox" class="le-checkbox"/></div>
                      <?php else: ?>
                      <img src="<?php echo e(asset('img/unknown.png')); ?>" alt="" width="32">
                      <?php endif; ?>
                    </td>
                    <td>
                      <?php if($consentimientos_vida_dato->plazo == 1): ?>
                      <span class="d-none"><?php echo e($numAciertos++); ?></span>
                      <div class="checkdiv"><input disabled checked type="checkbox" class="le-checkbox"/></div>
                      <?php elseif($consentimientos_vida_dato->plazo == 0): ?>
                      <div class="checkdiv"><input disabled  type="checkbox" class="le-checkbox"/></div>
                      <?php else: ?>
                      <img src="<?php echo e(asset('img/unknown.png')); ?>" alt="" width="32">
                      <?php endif; ?>
                    </td>
                    <td>
                      <?php if($consentimientos_vida_dato->formaDePago == 1): ?>
                      <span class="d-none"><?php echo e($numAciertos++); ?></span>
                      <div class="checkdiv"><input disabled checked type="checkbox" class="le-checkbox"/></div>
                      <?php elseif($consentimientos_vida_dato->formaDePago == 0): ?>
                      <div class="checkdiv"><input disabled  type="checkbox" class="le-checkbox"/></div>
                      <?php else: ?>
                      <img src="<?php echo e(asset('img/unknown.png')); ?>" alt="" width="32">
                      <?php endif; ?>
                    </td>
                    <td>
                      <?php if($consentimientos_vida_dato->contributorio == 1): ?>
                      <span class="d-none"><?php echo e($numAciertos++); ?></span>
                      <div class="checkdiv"><input disabled checked type="checkbox" class="le-checkbox"/></div>
                      <?php elseif($consentimientos_vida_dato->contributorio == 0): ?>
                      <div class="checkdiv"><input disabled  type="checkbox" class="le-checkbox"/></div>
                      <?php else: ?>
                      <img src="<?php echo e(asset('img/unknown.png')); ?>" alt="" width="32">
                      <?php endif; ?>
                    </td>
                    <td>
                      <?php if($consentimientos_vida_dato->inicioVigencia == 1): ?>
                      <span class="d-none"><?php echo e($numAciertos++); ?></span>
                      <div class="checkdiv"><input disabled checked type="checkbox" class="le-checkbox"/></div>
                      <?php elseif($consentimientos_vida_dato->inicioVigencia == 0): ?>
                      <div class="checkdiv"><input disabled  type="checkbox" class="le-checkbox"/></div>
                      <?php else: ?>
                      <img src="<?php echo e(asset('img/unknown.png')); ?>" alt="" width="32">
                      <?php endif; ?>
                    </td>
                    <td>
                      <?php if($consentimientos_vida_dato->finVigencia == 1): ?>
                      <span class="d-none"><?php echo e($numAciertos++); ?></span>
                      <div class="checkdiv"><input disabled checked type="checkbox" class="le-checkbox"/></div>
                      <?php elseif($consentimientos_vida_dato->finVigencia == 0): ?>
                      <div class="checkdiv"><input disabled  type="checkbox" class="le-checkbox"/></div>
                      <?php else: ?>
                      <img src="<?php echo e(asset('img/unknown.png')); ?>" alt="" width="32">
                      <?php endif; ?>
                    </td>
                    <td>
                      <?php if($consentimientos_vida_dato->moneda == 1): ?>
                      <span class="d-none"><?php echo e($numAciertos++); ?></span>
                      <div class="checkdiv"><input disabled checked type="checkbox" class="le-checkbox"/></div>
                      <?php elseif($consentimientos_vida_dato->moneda == 0): ?>
                      <div class="checkdiv"><input disabled  type="checkbox" class="le-checkbox"/></div>
                      <?php else: ?>
                      <img src="<?php echo e(asset('img/unknown.png')); ?>" alt="" width="32">
                      <?php endif; ?>
                    </td>
                    <span class="d-none"><?php echo e($contador++); ?></span>
                  </tr>
                    
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  <div class="btn-success d-none">Aciertos Coberturas = <?php echo e($conA=$numAciertos); ?>/<?php echo e($conC = $numColumnas*$contador); ?></div>

                </tbody>
              </table>
            </div>

          
            <div class="tab-pane fade" >
              
              <div class="table-title">Datos</div>
              <span class="d-none"><?php echo e($numAciertos=0, $contador=0); ?></span>
              <table class="table table-hover table-responsive">
                <thead>
                  <tr class="fixed-table">
                    
                    <th scope="col">Pagina</th>
                    <th scope="col">Plazo</th>
                    <th scope="col">Forma de Pago</th>
                    <th scope="col">Contributorio</th>
                    <th scope="col">Inicio Vigencia</th>
                    <th scope="col">Fin Vigencia</th>
                    <th scope="col">Asegurados</th>
                    <th scope="col">Datos del contratante</th>
                    <th scope="col">Prima Neta</th>
                    <th scope="col">Recargos</th>
                    <th scope="col">Gastos expedición</th>
                    <th scope="col">IVA</th>
                    <th scope="col">Prima Total</th>
                    <th scope="col">Moneda</th>
                    <span class="d-none"><?php echo e($numColumnas=13); ?></span>
                  </tr>
                </thead>
                <tbody>
                  <?php $__currentLoopData = $detalle_cobertura_datos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $detalle_cobertura_dato): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <tr>
                    
                    <td><?php echo e($detalle_cobertura_dato->pagina); ?></td>
                    <td>
                      <?php if($detalle_cobertura_dato->plazo == 1): ?>
                      <div class="checkdiv"><input disabled checked type="checkbox" class="le-checkbox"/></div>
                      <span class="d-none"><?php echo e($numAciertos++); ?></span>
                      <?php elseif($detalle_cobertura_dato->plazo == 0): ?>
                      <div class="checkdiv"><input disabled  type="checkbox" class="le-checkbox"/></div>
                      <?php else: ?>
                      <img src="<?php echo e(asset('img/unknown.png')); ?>" alt="" width="32">
                      <?php endif; ?>
                    </td>
                    <td>
                      <?php if($detalle_cobertura_dato->formaDePago == 1): ?>
                      <span class="d-none"><?php echo e($numAciertos++); ?></span>
                      <div class="checkdiv"><input disabled checked type="checkbox" class="le-checkbox"/></div>
                      <?php elseif($detalle_cobertura_dato->formaDePago == 0): ?>
                      <div class="checkdiv"><input disabled  type="checkbox" class="le-checkbox"/></div>
                      <?php else: ?>
                      <img src="<?php echo e(asset('img/unknown.png')); ?>" alt="" width="32">
                      <?php endif; ?>
                    </td>
                    <td>
                      <?php if($detalle_cobertura_dato->contributorio == 1): ?>
                      <span class="d-none"><?php echo e($numAciertos++); ?></span>
                      <div class="checkdiv"><input disabled checked type="checkbox" class="le-checkbox"/></div>
                      <?php elseif($detalle_cobertura_dato->contributorio == 0): ?>
                      <div class="checkdiv"><input disabled  type="checkbox" class="le-checkbox"/></div>
                      <?php else: ?>
                      <img src="<?php echo e(asset('img/unknown.png')); ?>" alt="" width="32">
                      <?php endif; ?>
                    </td>
                    <td>
                      <?php if($detalle_cobertura_dato->inicioVigencia == 1): ?>
                      <span class="d-none"><?php echo e($numAciertos++); ?></span>
                      <div class="checkdiv"><input disabled checked type="checkbox" class="le-checkbox"/></div>
                      <?php elseif($detalle_cobertura_dato->inicioVigencia == 0): ?>
                      <div class="checkdiv"><input disabled  type="checkbox" class="le-checkbox"/></div>
                      <?php else: ?>
                      <img src="<?php echo e(asset('img/unknown.png')); ?>" alt="" width="32">
                      <?php endif; ?>
                    </td>
                    <td>
                      <?php if($detalle_cobertura_dato->finVigencia == 1): ?>
                      <span class="d-none"><?php echo e($numAciertos++); ?></span>
                      <div class="checkdiv"><input disabled checked type="checkbox" class="le-checkbox"/></div>
                      <?php elseif($detalle_cobertura_dato->finVigencia == 0): ?>
                      <div class="checkdiv"><input disabled  type="checkbox" class="le-checkbox"/></div>
                      <?php else: ?>
                      <img src="<?php echo e(asset('img/unknown.png')); ?>" alt="" width="32">
                      <?php endif; ?>
                    </td>
                    <td>
                      <?php if($detalle_cobertura_dato->asegurados == 1): ?>
                      <span class="d-none"><?php echo e($numAciertos++); ?></span>
                      <div class="checkdiv"><input disabled checked type="checkbox" class="le-checkbox"/></div>
                      <?php elseif($detalle_cobertura_dato->asegurados == 0): ?>
                      <div class="checkdiv"><input disabled  type="checkbox" class="le-checkbox"/></div>
                      <?php else: ?>
                      <img src="<?php echo e(asset('img/unknown.png')); ?>" alt="" width="32">
                      <?php endif; ?>
                    </td>
                    <td>
                      <?php if($detalle_cobertura_dato->datosDelContratante == 1): ?>
                      <span class="d-none"><?php echo e($numAciertos++); ?></span>
                      <div class="checkdiv"><input disabled checked type="checkbox" class="le-checkbox"/></div>
                      <?php elseif($detalle_cobertura_dato->datosDelContratante == 0): ?>
                      <div class="checkdiv"><input disabled  type="checkbox" class="le-checkbox"/></div>
                      <?php else: ?>
                      <img src="<?php echo e(asset('img/unknown.png')); ?>" alt="" width="32">
                      <?php endif; ?>
                    </td>
                    <td>
                      <?php if($detalle_cobertura_dato->primaNeta == 1): ?>
                      <span class="d-none"><?php echo e($numAciertos++); ?></span>
                      <div class="checkdiv"><input disabled checked type="checkbox" class="le-checkbox"/></div>
                      <?php elseif($detalle_cobertura_dato->primaNeta == 0): ?>
                      <div class="checkdiv"><input disabled  type="checkbox" class="le-checkbox"/></div>
                      <?php else: ?>
                      <img src="<?php echo e(asset('img/unknown.png')); ?>" alt="" width="32">
                      <?php endif; ?>
                    </td>
                    <td>
                      <?php if($detalle_cobertura_dato->recargos == 1): ?>
                      <span class="d-none"><?php echo e($numAciertos++); ?></span>
                      <div class="checkdiv"><input disabled checked type="checkbox" class="le-checkbox"/></div>
                      <?php elseif($detalle_cobertura_dato->recargos == 0): ?>
                      <div class="checkdiv"><input disabled  type="checkbox" class="le-checkbox"/></div>
                      <?php else: ?>
                      <img src="<?php echo e(asset('img/unknown.png')); ?>" alt="" width="32">
                      <?php endif; ?>
                    </td>
                    <td>
                      <?php if($detalle_cobertura_dato->gtosExpedicion == 1): ?>
                      <span class="d-none"><?php echo e($numAciertos++); ?></span>
                      <div class="checkdiv"><input disabled checked type="checkbox" class="le-checkbox"/></div>
                      <?php elseif($detalle_cobertura_dato->gtosExpedicion == 0): ?>
                      <div class="checkdiv"><input disabled  type="checkbox" class="le-checkbox"/></div>
                      <?php else: ?>
                      <img src="<?php echo e(asset('img/unknown.png')); ?>" alt="" width="32">
                      <?php endif; ?>
                    </td>
                    <td>
                      <?php if($detalle_cobertura_dato->IVA == 1): ?>
                      <span class="d-none"><?php echo e($numAciertos++); ?></span>
                      <div class="checkdiv"><input disabled checked type="checkbox" class="le-checkbox"/></div>
                      <?php elseif($detalle_cobertura_dato->IVA == 0): ?>
                      <div class="checkdiv"><input disabled  type="checkbox" class="le-checkbox"/></div>
                      <?php else: ?>
                      <img src="<?php echo e(asset('img/unknown.png')); ?>" alt="" width="32">
                      <?php endif; ?>
                    </td>
                    <td>
                      <?php if($detalle_cobertura_dato->primaTotal == 1): ?>
                      <span class="d-none"><?php echo e($numAciertos++); ?></span>
                      <div class="checkdiv"><input disabled checked type="checkbox" class="le-checkbox"/></div>
                      <?php elseif($detalle_cobertura_dato->primaTotal == 0): ?>
                      <div class="checkdiv"><input disabled  type="checkbox" class="le-checkbox"/></div>
                      <?php else: ?>
                      <img src="<?php echo e(asset('img/unknown.png')); ?>" alt="" width="32">
                      <?php endif; ?>
                    </td>
                    <td>
                      <?php if($detalle_cobertura_dato->moneda == 1): ?>
                      <span class="d-none"><?php echo e($numAciertos++); ?></span>
                      <div class="checkdiv"><input disabled checked type="checkbox" class="le-checkbox"/></div>
                      <?php elseif($detalle_cobertura_dato->moneda == 0): ?>
                      <div class="checkdiv"><input disabled  type="checkbox" class="le-checkbox"/></div>
                      <?php else: ?>
                      <img src="<?php echo e(asset('img/unknown.png')); ?>" alt="" width="32">
                      <?php endif; ?>
                    </td>
                  </tr>
                  <span class="d-none"><?php echo e($contador++); ?></span>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  <div class="btn-success d-none">Aciertos Datos= <?php echo e($numAciertos); ?>/<?php echo e($numColumnas*$contador); ?></div>
                </tbody>
              </table>
              
              <span class="d-none"><?php echo e($guardarAciertos=$numAciertos, $guardarColumnas=$numColumnas*$contador); ?></span>
              
              
              <div class="table-title">Datos</div>
              <span class="d-none"><?php echo e($numAciertos=0, $numColumnas=0, $contador=0); ?></span>
              <table class="table table-hover  table-responsive ">
                <thead>
                  <tr class="fixed-table">
                    <th scope="col">Pagina</th>
                    <th scope="col">Cobertura</th>
                    <th scope="col">Prima Neta</th>
                    <span class="d-none"><?php echo e($numColumnas=1); ?></span>
                  </tr>
                </thead>
                <tbody>
                  <?php $__currentLoopData = $detalle_cobertura_coberturas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $detalle_cobertura_cobertura): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <tr>
                    
                    <td><?php echo e($detalle_cobertura_cobertura->pagina); ?></td>
                    <td>
                      <?php echo e($detalle_cobertura_cobertura->cobertura); ?>

                    </td>
                    <td>
                      <?php if($detalle_cobertura_cobertura->primaNeta == 1): ?>
                      <span class="d-none"><?php echo e($numAciertos++); ?></span>
                      <div class="checkdiv"><input disabled checked type="checkbox" class="le-checkbox"/></div>
                      <?php elseif($detalle_cobertura_cobertura->primaNeta == 0): ?>
                      <div class="checkdiv"><input disabled  type="checkbox" class="le-checkbox"/></div>
                      <?php else: ?>
                      <img src="<?php echo e(asset('img/unknown.png')); ?>" alt="" width="32">
                      <?php endif; ?>
                    </td>
                  </tr>
                  <span class="d-none"><?php echo e($contador++); ?></span>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  <div class="btn-success d-none">Aciertos Coberturas = <?php echo e($numAciertos); ?>/<?php echo e($numColumnas*$contador); ?></div>
                </tbody>
              </table>
              <span class="d-none"><?php echo e($guardarAciertos=$guardarAciertos+$numAciertos, $guardarColumnas=$guardarColumnas+($numColumnas*$contador)); ?></span>

              
              <div class="btn-success d-none position-absolute"><?php echo e($DetA=$guardarAciertos); ?>/<?php echo e($DetC=$guardarColumnas); ?></div>
            </div>

          
            <div class="tab-pane fade" >
              <span class="d-none"><?php echo e($numAciertos=0, $contador=0); ?></span>
              <table class="table table-hover table-responsive">
                <thead>
                  <tr class="fixed-table">
                    
                    <th scope="col">Subgrupo</th>
                    <th scope="col">Categoría</th>
                    <th scope="col">Endoso</th>
                    <th scope="col">Valor</th>
                    <span class="d-none"><?php echo e($numColumnas=1); ?></span>
                  </tr>
                </thead>
                <tbody>
                  <?php $__currentLoopData = $endosos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $endoso): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <tr>
                    
                    <td><?php echo e($endoso->subgrupo); ?></td>
                    <td><?php echo e($endoso->categoria); ?></td>
                    <td><?php echo e($endoso->endoso); ?></td>
                    <td>
                      <?php if($endoso->valorEndoso == 1): ?>
                      <div class="checkdiv"><input disabled checked type="checkbox" class="le-checkbox"/></div>
                      <span class="d-none"><?php echo e($numAciertos++); ?></span>
                      <?php elseif($endoso->valorEndoso == 0): ?>
                      <div class="checkdiv"><input disabled  type="checkbox" class="le-checkbox"/></div>
                      <?php else: ?>
                      <img src="<?php echo e(asset('img/unknown.png')); ?>" alt="" width="32">
                      <?php endif; ?>
                    </td>
                    <span class="d-none"><?php echo e($contador++); ?></span>
                  </tr>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  <div class="btn-success d-none">Aciertos Coberturas = <?php echo e($EnA=$numAciertos); ?>/<?php echo e($EnC= $numColumnas*$contador); ?></div>
                </tbody>
              </table>
            </div>

          
            <div class="tab-pane fade">
              <form class="d-flex w-25" id="searchform" onkeyup="filterListado()">
                <input class="form-control me-2 shadow-none" type="text" placeholder="No. de certificado" id="searchListado">
                <button type="submit" disabled><img src="<?php echo e(asset('img/search.svg')); ?>"  alt="" ></button/>
                
              </form>
              
              <span class="d-none"><?php echo e($numAciertos=0, $contador=0); ?></span>

              <table class="table table-hover table-responsive ">
                <thead>
                  <tr class="fixed-table">
                    
                    <th scope="col">Certificado</th>
                    <th scope="col">Subgrupo</th>
                    <th scope="col">Categoría</th>
                    <th scope="col">Nombre</th>
                    <th scope="col">Antiguedad</th>
                    <th scope="col">Edad</th>
                    <th scope="col">Sexo</th>
                    <th scope="col">Fecha Alta/Baja</th>
                    <span class="d-none"><?php echo e($numColumnas=6); ?></span>
                  </tr>
                </thead>
                <tbody id="tbody-listado_asegurados">
                  <?php $__currentLoopData = $listado_asegurados; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $listado_asegurado): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <tr>
                    
                    <td class="tr-td-certificado-listado_asegurados"><?php echo e($listado_asegurado->certificado); ?></td>
                    <td><?php echo e($listado_asegurado->subgrupo); ?></td>
                    <td>
                      <?php if($listado_asegurado->categoria == 1): ?>
                      <span class="d-none"><?php echo e($numAciertos++); ?></span>
                      <div class="checkdiv"><input disabled checked type="checkbox" class="le-checkbox"/></div>
                      <?php elseif($listado_asegurado->categoria == 0): ?>
                      <div class="checkdiv"><input disabled  type="checkbox" class="le-checkbox"/></div>
                      <?php else: ?>
                      <img src="<?php echo e(asset('img/unknown.png')); ?>" alt="" width="32">
                      <?php endif; ?>
                    </td>
                    <td>
                      <?php if($listado_asegurado->nombre == 1): ?>
                      <span class="d-none"><?php echo e($numAciertos++); ?></span>
                      <div class="checkdiv"><input disabled checked type="checkbox" class="le-checkbox"/></div>
                      <?php elseif($listado_asegurado->nombre == 0): ?>
                      <div class="checkdiv"><input disabled  type="checkbox" class="le-checkbox"/></div>
                      <?php else: ?>
                      <img src="<?php echo e(asset('img/unknown.png')); ?>" alt="" width="32">
                      <?php endif; ?>
                    </td>
                    <td>
                      <?php if($listado_asegurado->antiguedad == 1): ?>
                      <span class="d-none"><?php echo e($numAciertos++); ?></span>
                      <div class="checkdiv"><input disabled checked type="checkbox" class="le-checkbox"/></div>
                      <?php elseif($listado_asegurado->antiguedad == 0): ?>
                      <div class="checkdiv"><input disabled  type="checkbox" class="le-checkbox"/></div>
                      <?php else: ?>
                      <img src="<?php echo e(asset('img/unknown.png')); ?>" alt="" width="32">
                      <?php endif; ?>
                    </td>
                    <td>
                      <?php if($listado_asegurado->edad == 1): ?>
                      <span class="d-none"><?php echo e($numAciertos++); ?></span>
                      <div class="checkdiv"><input disabled checked type="checkbox" class="le-checkbox"/></div>
                      <?php elseif($listado_asegurado->edad == 0): ?>
                      <div class="checkdiv"><input disabled  type="checkbox" class="le-checkbox"/></div>
                      <?php else: ?>
                      <img src="<?php echo e(asset('img/unknown.png')); ?>" alt="" width="32">
                      <?php endif; ?>
                    </td>
                    <td>
                      <?php if($listado_asegurado->sexo == 1): ?>
                      <span class="d-none"><?php echo e($numAciertos++); ?></span>
                      <div class="checkdiv"><input disabled checked type="checkbox" class="le-checkbox"/></div>
                      <?php elseif($listado_asegurado->sexo == 0): ?>
                      <div class="checkdiv"><input disabled  type="checkbox" class="le-checkbox"/></div>
                      <?php else: ?>
                      <img src="<?php echo e(asset('img/unknown.png')); ?>" alt="" width="32">
                      <?php endif; ?>
                    </td>
                    <td>
                      <?php if($listado_asegurado->fechaAltaBaja == 1): ?>
                      <span class="d-none"><?php echo e($numAciertos++); ?></span>
                      <div class="checkdiv"><input disabled checked type="checkbox" class="le-checkbox"/></div>
                      <?php elseif($listado_asegurado->fechaAltaBaja == 0): ?>
                      <div class="checkdiv"><input disabled  type="checkbox" class="le-checkbox"/></div>
                      <?php else: ?>
                      <img src="<?php echo e(asset('img/unknown.png')); ?>" alt="" width="32">
                      <?php endif; ?>
                    </td>
                    <span class="d-none"><?php echo e($contador++); ?></span>
                  </tr>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  <div class="btn-success d-none">Aciertos Coberturas = <?php echo e($LisA=$numAciertos); ?>/<?php echo e($LisC= $numColumnas*$contador); ?></div>
                </tbody>
              </table>
            </div>
       </div>

       

       <!-- Tabs header -->
        <div class="nav-tabs-wrapper">
            <ul class="nav nav-tabs dragscroll horizontal">
                <li class="nav-item"><a class="nav-link active" data-toggle="tab" href="#tabA"><img src="<?php echo e(asset('img/consentimientos-icon.svg')); ?>" alt="">Carátula <br><?php echo e($caratulaA); ?>/<?php echo e($caratulaC); ?></a></li>
                <li class="nav-item"><a class="nav-link" data-toggle="tab" href="#tabB"><img src="<?php echo e(asset('img/consentimientos-icon.svg')); ?>" alt="">Consentimientos <br><?php echo e($conA); ?>/<?php echo e($conC); ?></a></li>
                <li class="nav-item"><a class="nav-link" data-toggle="tab" href="#tabC"><img src="<?php echo e(asset('img/detalle-icon.svg')); ?>" alt="">Detalle coberturas <br><?php echo e($DetA); ?>/<?php echo e($DetC); ?></a></li>
                <li class="nav-item"><a class="nav-link" data-toggle="tab" href="#tabD"><img src="<?php echo e(asset('img/endosos-icon.svg')); ?>" alt="">Endosos especiales <br><?php echo e($EnA); ?>/<?php echo e($EnC); ?></a></li>
                <li class="nav-item"><a class="nav-link" data-toggle="tab" href="#tabE"><img src="<?php echo e(asset('img/asegurados-icon.svg')); ?>" alt="">Listado asegurados <br><?php echo e($LisA); ?>/<?php echo e($LisC); ?></a></li>
            </ul>
        </div>
      </div>
         <div class="tab-content">
            
              <div class="tab-pane fade show active" id="tabA">
                
                <div class="table-title">Datos</div>
                <table class="table table-hover table-responsive ">
                  <thead>
                    <tr class="fixed-table">
                      
                      <th scope="col">Pagina</th>
                      <th scope="col">Plazo</th>
                      <th scope="col">Forma de Pago</th>
                      <th scope="col">Contributorio</th>
                      <th scope="col">Inicio Vigencia</th>
                      <th scope="col">Fin Vigencia</th>
                      <th scope="col">Tipo de Administracion</th>
                      <th scope="col">Datos del contratante</th>
                      <th scope="col">Prima Neta</th>
                      <th scope="col">Recargos</th>
                      <th scope="col">Gastos expedición</th>
                      <th scope="col">IVA</th>
                      <th scope="col">Prima Total</th>
                      <th scope="col">Moneda</th>
                      <span class="d-none"><?php echo e($numColumnas=13); ?></span>
                    </tr>
                  </thead>
                  <tbody>
                    <?php $__currentLoopData = $caratula_datos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $caratula_dato): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                      
                      <td><?php echo e($caratula_dato->pagina); ?></td>
                      <td>
                        <?php if($caratula_dato->plazo == 1): ?>
                        <div class="checkdiv"><input disabled checked type="checkbox" class="le-checkbox"/></div>
                        <span class="d-none"><?php echo e($numAciertos++); ?></span>
                        <?php elseif($caratula_dato->plazo == 0): ?>
                        <div class="checkdiv"><input disabled  type="checkbox" class="le-checkbox"/></div>
                        <?php else: ?>
                        <img src="<?php echo e(asset('img/unknown.png')); ?>" alt="" width="32">
                        <?php endif; ?>
                      </td>
                      <td>
                        <?php if($caratula_dato->formaDePago == 1): ?>
                        <span class="d-none"><?php echo e($numAciertos++); ?></span>
                        <div class="checkdiv"><input disabled checked type="checkbox" class="le-checkbox"/></div>
                        <?php elseif($caratula_dato->formaDePago == 0): ?>
                        <div class="checkdiv"><input disabled  type="checkbox" class="le-checkbox"/></div>
                        <?php else: ?>
                        <img src="<?php echo e(asset('img/unknown.png')); ?>" alt="" width="32">
                        <?php endif; ?>
                      </td>
                      <td>
                        <?php if($caratula_dato->contributorio == 1): ?>
                        <span class="d-none"><?php echo e($numAciertos++); ?></span>
                        <div class="checkdiv"><input disabled checked type="checkbox" class="le-checkbox"/></div>
                        <?php elseif($caratula_dato->contributorio == 0): ?>
                        <div class="checkdiv"><input disabled  type="checkbox" class="le-checkbox"/></div>
                        <?php else: ?>
                        <img src="<?php echo e(asset('img/unknown.png')); ?>" alt="" width="32">
                        <?php endif; ?>
                      </td>
                      <td>
                        <?php if($caratula_dato->inicioVigencia == 1): ?>
                        <span class="d-none"><?php echo e($numAciertos++); ?></span>
                        <div class="checkdiv"><input disabled checked type="checkbox" class="le-checkbox"/></div>
                        <?php elseif($caratula_dato->inicioVigencia == 0): ?>
                        <div class="checkdiv"><input disabled  type="checkbox" class="le-checkbox"/></div>
                        <?php else: ?>
                        <img src="<?php echo e(asset('img/unknown.png')); ?>" alt="" width="32">
                        <?php endif; ?>
                      </td>
                      <td>
                        <?php if($caratula_dato->finVigencia == 1): ?>
                        <span class="d-none"><?php echo e($numAciertos++); ?></span>
                        <div class="checkdiv"><input disabled checked type="checkbox" class="le-checkbox"/></div>
                        <?php elseif($caratula_dato->finVigencia == 0): ?>
                        <div class="checkdiv"><input disabled  type="checkbox" class="le-checkbox"/></div>
                        <?php else: ?>
                        <img src="<?php echo e(asset('img/unknown.png')); ?>" alt="" width="32">
                        <?php endif; ?>
                      </td>
                      <td>
                        <?php if($caratula_dato->tipoDeAdministracion == 1): ?>
                        <span class="d-none"><?php echo e($numAciertos++); ?></span>
                        <div class="checkdiv"><input disabled checked type="checkbox" class="le-checkbox"/></div>
                        <?php elseif($caratula_dato->tipoDeAdministracion == 0): ?>
                        <div class="checkdiv"><input disabled  type="checkbox" class="le-checkbox"/></div>
                        <?php else: ?>
                        <img src="<?php echo e(asset('img/unknown.png')); ?>" alt="" width="32">
                        <?php endif; ?>
                      </td>
                      <td>
                        <?php if($caratula_dato->datosDelContratante == 1): ?>
                        <span class="d-none"><?php echo e($numAciertos++); ?></span>
                        <div class="checkdiv"><input disabled checked type="checkbox" class="le-checkbox"/></div>
                        <?php elseif($caratula_dato->datosDelContratante == 0): ?>
                        <div class="checkdiv"><input disabled  type="checkbox" class="le-checkbox"/></div>
                        <?php else: ?>
                        <img src="<?php echo e(asset('img/unknown.png')); ?>" alt="" width="32">
                        <?php endif; ?>
                      </td>
                      <td>
                        <?php if($caratula_dato->primaNeta == 1): ?>
                        <span class="d-none"><?php echo e($numAciertos++); ?></span>
                        <div class="checkdiv"><input disabled checked type="checkbox" class="le-checkbox"/></div>
                        <?php elseif($caratula_dato->primaNeta == 0): ?>
                        <div class="checkdiv"><input disabled  type="checkbox" class="le-checkbox"/></div>
                        <?php else: ?>
                        <img src="<?php echo e(asset('img/unknown.png')); ?>" alt="" width="32">
                        <?php endif; ?>
                      </td>
                      <td>
                        <?php if($caratula_dato->recargos == 1): ?>
                        <span class="d-none"><?php echo e($numAciertos++); ?></span>
                        <div class="checkdiv"><input disabled checked type="checkbox" class="le-checkbox"/></div>
                        <?php elseif($caratula_dato->recargos == 0): ?>
                        <div class="checkdiv"><input disabled  type="checkbox" class="le-checkbox"/></div>
                        <?php else: ?>
                        <img src="<?php echo e(asset('img/unknown.png')); ?>" alt="" width="32">
                        <?php endif; ?>
                      </td>
                      <td>
                        <?php if($caratula_dato->gtosExpedicion == 1): ?>
                        <span class="d-none"><?php echo e($numAciertos++); ?></span>
                        <div class="checkdiv"><input disabled checked type="checkbox" class="le-checkbox"/></div>
                        <?php elseif($caratula_dato->gtosExpedicion == 0): ?>
                        <div class="checkdiv"><input disabled  type="checkbox" class="le-checkbox"/></div>
                        <?php else: ?>
                        <img src="<?php echo e(asset('img/unknown.png')); ?>" alt="" width="32">
                        <?php endif; ?>
                      </td>
                      <td>
                        <?php if($caratula_dato->IVA == 1): ?>
                        <span class="d-none"><?php echo e($numAciertos++); ?></span>
                        <div class="checkdiv"><input disabled checked type="checkbox" class="le-checkbox"/></div>
                        <?php elseif($caratula_dato->IVA == 0): ?>
                        <div class="checkdiv"><input disabled  type="checkbox" class="le-checkbox"/></div>
                        <?php else: ?>
                        <img src="<?php echo e(asset('img/unknown.png')); ?>" alt="" width="32">
                        <?php endif; ?>
                      </td>
                      <td>
                        <?php if($caratula_dato->primaTotal == 1): ?>
                        <span class="d-none"><?php echo e($numAciertos++); ?></span>
                        <div class="checkdiv"><input disabled checked type="checkbox" class="le-checkbox"/></div>
                        <?php elseif($caratula_dato->primaTotal == 0): ?>
                        <div class="checkdiv"><input disabled  type="checkbox" class="le-checkbox"/></div>
                        <?php else: ?>
                        <img src="<?php echo e(asset('img/unknown.png')); ?>" alt="" width="32">
                        <?php endif; ?>
                      </td>
                      <td>
                        <?php if($caratula_dato->moneda == 1): ?>
                        <span class="d-none"><?php echo e($numAciertos++); ?></span>
                        <div class="checkdiv"><input disabled checked type="checkbox" class="le-checkbox"/></div>
                        <?php elseif($caratula_dato->moneda == 0): ?>
                        <div class="checkdiv"><input disabled  type="checkbox" class="le-checkbox"/></div>
                        <?php else: ?>
                        <img src="<?php echo e(asset('img/unknown.png')); ?>" alt="" width="32">
                        <?php endif; ?>
                      </td>
                    </tr>
                    <span class="d-none"><?php echo e($contador++); ?></span>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <div class="btn-success d-none">Aciertos Datos= <?php echo e($numAciertos); ?>/<?php echo e($numColumnas*$contador); ?></div>
                  </tbody>
                </table>
                
                <span class="d-none"><?php echo e($guardarAciertos=$numAciertos, $guardarColumnas=$numColumnas*$contador); ?></span>
               
                
                <div class="table-title">Coberturas</div>
                <span class="d-none"><?php echo e($numAciertos=0, $numColumnas=0, $contador=0); ?></span>
                <table class="table table-hover  table-responsive ">
                  <thead>
                    <tr class="fixed-table">
                      
                      <th scope="col">Pagina</th>
                      <th scope="col">Cobertura</th>
                      <th scope="col">Suma Asegurada</th>
                      <th scope="col">Prima Neta</th>
                      <span class="d-none"><?php echo e($numColumnas=2); ?></span>
                    </tr>
                  </thead>
                    
                  <tbody>
                    <?php $__currentLoopData = $caratula_coberturas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $caratula_cobertura): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                      
                      <td><?php echo e($caratula_cobertura->pagina); ?></td>
                      <td>
                        <?php echo e($caratula_cobertura->cobertura); ?>

                      </td>
                      <td>
                        <?php if($caratula_cobertura->sumaAsegurada == 1): ?>
                        <div class="checkdiv"><input disabled checked type="checkbox" class="le-checkbox"/></div>
                        <span class="d-none"><?php echo e($numAciertos++); ?></span>

                        <?php elseif($caratula_cobertura->sumaAsegurada == 0): ?>
                        <div class="checkdiv"><input disabled  type="checkbox" class="le-checkbox"/></div>
                        <?php else: ?>
                        <img src="<?php echo e(asset('img/unknown.png')); ?>" alt="" width="32">
                        <?php endif; ?>
                      </td>
                      <td>
                        <?php if($caratula_cobertura->primaNeta == 1): ?>
                        <span class="d-none"><?php echo e($numAciertos++); ?></span>
                        <div class="checkdiv"><input disabled checked type="checkbox" class="le-checkbox"/></div>
                        <?php elseif($caratula_cobertura->primaNeta == 0): ?>
                        <div class="checkdiv"><input disabled  type="checkbox" class="le-checkbox"/></div>
                        <?php else: ?>
                        <img src="<?php echo e(asset('img/unknown.png')); ?>" alt="" width="32">
                        <?php endif; ?>
                      </td>
                    </tr>
                    <span class="d-none"><?php echo e($contador++); ?></span>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <div class="btn-success d-none">Aciertos Coberturas = <?php echo e($numAciertos); ?>/<?php echo e($numColumnas*$contador); ?></div>
                  </tbody>
                </table>
                <span class="d-none"><?php echo e($guardarAciertos=$guardarAciertos+$numAciertos, $guardarColumnas=$guardarColumnas+($numColumnas*$contador)); ?></span>

                
                <div class="btn-success d-none position-absolute"><?php echo e($guardarAciertos); ?>/<?php echo e($guardarColumnas); ?></div>

                   
              </div>

            
              <div class="tab-pane fade" id="tabB">
                <form class="d-flex w-25" id="searchform" onkeyup="filterConsentimientos()">
                  <input class="form-control me-2 d-flex shadow-none" type="text" placeholder="No. de certificado" id="searchConsentimientos">
                  <button type="submit" disabled><img src="<?php echo e(asset('img/search.svg')); ?>"  alt="" ></button/>
                </form>
                <span class="d-none"><?php echo e($numAciertos=0, $contador=0); ?></span>
                <table class="table table-hover table-responsive ">
                  <thead>
                    <tr class="fixed-table">
                      
                      <th scope="col">Certificado</th>
                      <th scope="col">Nombre</th>
                      <th scope="col">Sexo</th>
                      <th scope="col">Edad</th>
                      <th scope="col">Fecha de Nacimiento</th>
                      <th scope="col">Datos del contratante</th>
                      <th scope="col">Plazo</th>
                      <th scope="col">Forma de Pago</th>
                      <th scope="col">Contributorio</th>
                      <th scope="col">Inicio Vigencia</th>
                      <th scope="col">Fin Vigencia</th>
                      <th scope="col">Moneda</th>
                      <span class="d-none"><?php echo e($numColumnas=11); ?></span>
                    </tr>
                  </thead>
                  <tbody id="tbody-consentimientos_vida_datos">
                    <?php $__currentLoopData = $consentimientos_vida_datos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $consentimientos_vida_dato): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr class="tr-consentimientos_vida_datos">
                      <td class="tr-td-certificado-consentimientos_vida_datos"><?php echo e($consentimientos_vida_dato->certificado); ?></td>
                      <td>
                        <?php if($consentimientos_vida_dato->nombre == 1): ?>
                        <span class="d-none"><?php echo e($numAciertos++); ?></span>
                        <div class="checkdiv"><input disabled checked type="checkbox" class="le-checkbox"/></div>
                        <?php elseif($consentimientos_vida_dato->nombre == 0): ?>
                        <div class="checkdiv"><input disabled  type="checkbox" class="le-checkbox"/></div>
                        <?php else: ?>
                        <img src="<?php echo e(asset('img/unknown.png')); ?>" alt="" width="32">
                        <?php endif; ?>
                      </td>
                      <td>
                        <?php if($consentimientos_vida_dato->sexo == 1): ?>
                        <span class="d-none"><?php echo e($numAciertos++); ?></span>
                        <div class="checkdiv"><input disabled checked type="checkbox" class="le-checkbox"/></div>
                        <?php elseif($consentimientos_vida_dato->nombre == 0): ?>
                        <div class="checkdiv"><input disabled  type="checkbox" class="le-checkbox"/></div>
                        <?php else: ?>
                        <img src="<?php echo e(asset('img/unknown.png')); ?>" alt="" width="32">
                        <?php endif; ?>
                      </td>
                      <td>
                        <?php if($consentimientos_vida_dato->edad == 1): ?>
                        <span class="d-none"><?php echo e($numAciertos++); ?></span>
                        <div class="checkdiv"><input disabled checked type="checkbox" class="le-checkbox"/></div>
                        <?php elseif($consentimientos_vida_dato->edad == 0): ?>
                        <div class="checkdiv"><input disabled  type="checkbox" class="le-checkbox"/></div>
                        <?php else: ?>
                        <img src="<?php echo e(asset('img/unknown.png')); ?>" alt="" width="32">
                        <?php endif; ?>
                      </td>
                      <td>
                        <?php if($consentimientos_vida_dato->fechaDeNacimiento == 1): ?>
                        <span class="d-none"><?php echo e($numAciertos++); ?></span>
                        <div class="checkdiv"><input disabled checked type="checkbox" class="le-checkbox"/></div>
                        <?php elseif($consentimientos_vida_dato->fechaDeNacimiento == 0): ?>
                        <div class="checkdiv"><input disabled  type="checkbox" class="le-checkbox"/></div>
                        <?php else: ?>
                        <img src="<?php echo e(asset('img/unknown.png')); ?>" alt="" width="32">
                        <?php endif; ?>
                      </td>
                      <td>
                        <?php if($consentimientos_vida_dato->datosDelContratante == 1): ?>
                        <span class="d-none"><?php echo e($numAciertos++); ?></span>
                        <div class="checkdiv"><input disabled checked type="checkbox" class="le-checkbox"/></div>
                        <?php elseif($consentimientos_vida_dato->datosDelContratante == 0): ?>
                        <div class="checkdiv"><input disabled  type="checkbox" class="le-checkbox"/></div>
                        <?php else: ?>
                        <img src="<?php echo e(asset('img/unknown.png')); ?>" alt="" width="32">
                        <?php endif; ?>
                      </td>
                      <td>
                        <?php if($consentimientos_vida_dato->plazo == 1): ?>
                        <span class="d-none"><?php echo e($numAciertos++); ?></span>
                        <div class="checkdiv"><input disabled checked type="checkbox" class="le-checkbox"/></div>
                        <?php elseif($consentimientos_vida_dato->plazo == 0): ?>
                        <div class="checkdiv"><input disabled  type="checkbox" class="le-checkbox"/></div>
                        <?php else: ?>
                        <img src="<?php echo e(asset('img/unknown.png')); ?>" alt="" width="32">
                        <?php endif; ?>
                      </td>
                      <td>
                        <?php if($consentimientos_vida_dato->formaDePago == 1): ?>
                        <span class="d-none"><?php echo e($numAciertos++); ?></span>
                        <div class="checkdiv"><input disabled checked type="checkbox" class="le-checkbox"/></div>
                        <?php elseif($consentimientos_vida_dato->formaDePago == 0): ?>
                        <div class="checkdiv"><input disabled  type="checkbox" class="le-checkbox"/></div>
                        <?php else: ?>
                        <img src="<?php echo e(asset('img/unknown.png')); ?>" alt="" width="32">
                        <?php endif; ?>
                      </td>
                      <td>
                        <?php if($consentimientos_vida_dato->contributorio == 1): ?>
                        <span class="d-none"><?php echo e($numAciertos++); ?></span>
                        <div class="checkdiv"><input disabled checked type="checkbox" class="le-checkbox"/></div>
                        <?php elseif($consentimientos_vida_dato->contributorio == 0): ?>
                        <div class="checkdiv"><input disabled  type="checkbox" class="le-checkbox"/></div>
                        <?php else: ?>
                        <img src="<?php echo e(asset('img/unknown.png')); ?>" alt="" width="32">
                        <?php endif; ?>
                      </td>
                      <td>
                        <?php if($consentimientos_vida_dato->inicioVigencia == 1): ?>
                        <span class="d-none"><?php echo e($numAciertos++); ?></span>
                        <div class="checkdiv"><input disabled checked type="checkbox" class="le-checkbox"/></div>
                        <?php elseif($consentimientos_vida_dato->inicioVigencia == 0): ?>
                        <div class="checkdiv"><input disabled  type="checkbox" class="le-checkbox"/></div>
                        <?php else: ?>
                        <img src="<?php echo e(asset('img/unknown.png')); ?>" alt="" width="32">
                        <?php endif; ?>
                      </td>
                      <td>
                        <?php if($consentimientos_vida_dato->finVigencia == 1): ?>
                        <span class="d-none"><?php echo e($numAciertos++); ?></span>
                        <div class="checkdiv"><input disabled checked type="checkbox" class="le-checkbox"/></div>
                        <?php elseif($consentimientos_vida_dato->finVigencia == 0): ?>
                        <div class="checkdiv"><input disabled  type="checkbox" class="le-checkbox"/></div>
                        <?php else: ?>
                        <img src="<?php echo e(asset('img/unknown.png')); ?>" alt="" width="32">
                        <?php endif; ?>
                      </td>
                      <td>
                        <?php if($consentimientos_vida_dato->moneda == 1): ?>
                        <span class="d-none"><?php echo e($numAciertos++); ?></span>
                        <div class="checkdiv"><input disabled checked type="checkbox" class="le-checkbox"/></div>
                        <?php elseif($consentimientos_vida_dato->moneda == 0): ?>
                        <div class="checkdiv"><input disabled  type="checkbox" class="le-checkbox"/></div>
                        <?php else: ?>
                        <img src="<?php echo e(asset('img/unknown.png')); ?>" alt="" width="32">
                        <?php endif; ?>
                      </td>
                      <span class="d-none"><?php echo e($contador++); ?></span>
                    </tr>
                      
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <div class="btn-success d-none">Aciertos Coberturas = <?php echo e($numAciertos); ?>/<?php echo e($numColumnas*$contador); ?></div>
                  </tbody>
                </table>
              </div>

            
              <div class="tab-pane fade" id="tabC">
                
                <div class="table-title">Datos</div>
                <span class="d-none"><?php echo e($numAciertos=0, $contador=0); ?></span>
                <table class="table table-hover table-responsive">
                  <thead>
                    <tr class="fixed-table">
                      
                      <th scope="col">Pagina</th>
                      <th scope="col">Plazo</th>
                      <th scope="col">Forma de Pago</th>
                      <th scope="col">Contributorio</th>
                      <th scope="col">Inicio Vigencia</th>
                      <th scope="col">Fin Vigencia</th>
                      <th scope="col">Asegurados</th>
                      <th scope="col">Datos del contratante</th>
                      <th scope="col">Prima Neta</th>
                      <th scope="col">Recargos</th>
                      <th scope="col">Gastos expedición</th>
                      <th scope="col">IVA</th>
                      <th scope="col">Prima Total</th>
                      <th scope="col">Moneda</th>
                      <span class="d-none"><?php echo e($numColumnas=13); ?></span>
                    </tr>
                  </thead>
                  <tbody>
                    <?php $__currentLoopData = $detalle_cobertura_datos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $detalle_cobertura_dato): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                      
                      <td><?php echo e($detalle_cobertura_dato->pagina); ?></td>
                      <td>
                        <?php if($detalle_cobertura_dato->plazo == 1): ?>
                        <div class="checkdiv"><input disabled checked type="checkbox" class="le-checkbox"/></div>
                        <span class="d-none"><?php echo e($numAciertos++); ?></span>
                        <?php elseif($detalle_cobertura_dato->plazo == 0): ?>
                        <div class="checkdiv"><input disabled  type="checkbox" class="le-checkbox"/></div>
                        <?php else: ?>
                        <img src="<?php echo e(asset('img/unknown.png')); ?>" alt="" width="32">
                        <?php endif; ?>
                      </td>
                      <td>
                        <?php if($detalle_cobertura_dato->formaDePago == 1): ?>
                        <span class="d-none"><?php echo e($numAciertos++); ?></span>
                        <div class="checkdiv"><input disabled checked type="checkbox" class="le-checkbox"/></div>
                        <?php elseif($detalle_cobertura_dato->formaDePago == 0): ?>
                        <div class="checkdiv"><input disabled  type="checkbox" class="le-checkbox"/></div>
                        <?php else: ?>
                        <img src="<?php echo e(asset('img/unknown.png')); ?>" alt="" width="32">
                        <?php endif; ?>
                      </td>
                      <td>
                        <?php if($detalle_cobertura_dato->contributorio == 1): ?>
                        <span class="d-none"><?php echo e($numAciertos++); ?></span>
                        <div class="checkdiv"><input disabled checked type="checkbox" class="le-checkbox"/></div>
                        <?php elseif($detalle_cobertura_dato->contributorio == 0): ?>
                        <div class="checkdiv"><input disabled  type="checkbox" class="le-checkbox"/></div>
                        <?php else: ?>
                        <img src="<?php echo e(asset('img/unknown.png')); ?>" alt="" width="32">
                        <?php endif; ?>
                      </td>
                      <td>
                        <?php if($detalle_cobertura_dato->inicioVigencia == 1): ?>
                        <span class="d-none"><?php echo e($numAciertos++); ?></span>
                        <div class="checkdiv"><input disabled checked type="checkbox" class="le-checkbox"/></div>
                        <?php elseif($detalle_cobertura_dato->inicioVigencia == 0): ?>
                        <div class="checkdiv"><input disabled  type="checkbox" class="le-checkbox"/></div>
                        <?php else: ?>
                        <img src="<?php echo e(asset('img/unknown.png')); ?>" alt="" width="32">
                        <?php endif; ?>
                      </td>
                      <td>
                        <?php if($detalle_cobertura_dato->finVigencia == 1): ?>
                        <span class="d-none"><?php echo e($numAciertos++); ?></span>
                        <div class="checkdiv"><input disabled checked type="checkbox" class="le-checkbox"/></div>
                        <?php elseif($detalle_cobertura_dato->finVigencia == 0): ?>
                        <div class="checkdiv"><input disabled  type="checkbox" class="le-checkbox"/></div>
                        <?php else: ?>
                        <img src="<?php echo e(asset('img/unknown.png')); ?>" alt="" width="32">
                        <?php endif; ?>
                      </td>
                      <td>
                        <?php if($detalle_cobertura_dato->asegurados == 1): ?>
                        <span class="d-none"><?php echo e($numAciertos++); ?></span>
                        <div class="checkdiv"><input disabled checked type="checkbox" class="le-checkbox"/></div>
                        <?php elseif($detalle_cobertura_dato->asegurados == 0): ?>
                        <div class="checkdiv"><input disabled  type="checkbox" class="le-checkbox"/></div>
                        <?php else: ?>
                        <img src="<?php echo e(asset('img/unknown.png')); ?>" alt="" width="32">
                        <?php endif; ?>
                      </td>
                      <td>
                        <?php if($detalle_cobertura_dato->datosDelContratante == 1): ?>
                        <span class="d-none"><?php echo e($numAciertos++); ?></span>
                        <div class="checkdiv"><input disabled checked type="checkbox" class="le-checkbox"/></div>
                        <?php elseif($detalle_cobertura_dato->datosDelContratante == 0): ?>
                        <div class="checkdiv"><input disabled  type="checkbox" class="le-checkbox"/></div>
                        <?php else: ?>
                        <img src="<?php echo e(asset('img/unknown.png')); ?>" alt="" width="32">
                        <?php endif; ?>
                      </td>
                      <td>
                        <?php if($detalle_cobertura_dato->primaNeta == 1): ?>
                        <span class="d-none"><?php echo e($numAciertos++); ?></span>
                        <div class="checkdiv"><input disabled checked type="checkbox" class="le-checkbox"/></div>
                        <?php elseif($detalle_cobertura_dato->primaNeta == 0): ?>
                        <div class="checkdiv"><input disabled  type="checkbox" class="le-checkbox"/></div>
                        <?php else: ?>
                        <img src="<?php echo e(asset('img/unknown.png')); ?>" alt="" width="32">
                        <?php endif; ?>
                      </td>
                      <td>
                        <?php if($detalle_cobertura_dato->recargos == 1): ?>
                        <span class="d-none"><?php echo e($numAciertos++); ?></span>
                        <div class="checkdiv"><input disabled checked type="checkbox" class="le-checkbox"/></div>
                        <?php elseif($detalle_cobertura_dato->recargos == 0): ?>
                        <div class="checkdiv"><input disabled  type="checkbox" class="le-checkbox"/></div>
                        <?php else: ?>
                        <img src="<?php echo e(asset('img/unknown.png')); ?>" alt="" width="32">
                        <?php endif; ?>
                      </td>
                      <td>
                        <?php if($detalle_cobertura_dato->gtosExpedicion == 1): ?>
                        <span class="d-none"><?php echo e($numAciertos++); ?></span>
                        <div class="checkdiv"><input disabled checked type="checkbox" class="le-checkbox"/></div>
                        <?php elseif($detalle_cobertura_dato->gtosExpedicion == 0): ?>
                        <div class="checkdiv"><input disabled  type="checkbox" class="le-checkbox"/></div>
                        <?php else: ?>
                        <img src="<?php echo e(asset('img/unknown.png')); ?>" alt="" width="32">
                        <?php endif; ?>
                      </td>
                      <td>
                        <?php if($detalle_cobertura_dato->IVA == 1): ?>
                        <span class="d-none"><?php echo e($numAciertos++); ?></span>
                        <div class="checkdiv"><input disabled checked type="checkbox" class="le-checkbox"/></div>
                        <?php elseif($detalle_cobertura_dato->IVA == 0): ?>
                        <div class="checkdiv"><input disabled  type="checkbox" class="le-checkbox"/></div>
                        <?php else: ?>
                        <img src="<?php echo e(asset('img/unknown.png')); ?>" alt="" width="32">
                        <?php endif; ?>
                      </td>
                      <td>
                        <?php if($detalle_cobertura_dato->primaTotal == 1): ?>
                        <span class="d-none"><?php echo e($numAciertos++); ?></span>
                        <div class="checkdiv"><input disabled checked type="checkbox" class="le-checkbox"/></div>
                        <?php elseif($detalle_cobertura_dato->primaTotal == 0): ?>
                        <div class="checkdiv"><input disabled  type="checkbox" class="le-checkbox"/></div>
                        <?php else: ?>
                        <img src="<?php echo e(asset('img/unknown.png')); ?>" alt="" width="32">
                        <?php endif; ?>
                      </td>
                      <td>
                        <?php if($detalle_cobertura_dato->moneda == 1): ?>
                        <span class="d-none"><?php echo e($numAciertos++); ?></span>
                        <div class="checkdiv"><input disabled checked type="checkbox" class="le-checkbox"/></div>
                        <?php elseif($detalle_cobertura_dato->moneda == 0): ?>
                        <div class="checkdiv"><input disabled  type="checkbox" class="le-checkbox"/></div>
                        <?php else: ?>
                        <img src="<?php echo e(asset('img/unknown.png')); ?>" alt="" width="32">
                        <?php endif; ?>
                      </td>
                    </tr>
                    <span class="d-none"><?php echo e($contador++); ?></span>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <div class="btn-success d-none">Aciertos Datos= <?php echo e($numAciertos); ?>/<?php echo e($numColumnas*$contador); ?></div>
                  </tbody>
                </table>
                
                <span class="d-none"><?php echo e($guardarAciertos=$numAciertos, $guardarColumnas=$numColumnas*$contador); ?></span>
                
                
                <div class="table-title">Datos</div>
                <span class="d-none"><?php echo e($numAciertos=0, $numColumnas=0, $contador=0); ?></span>
                <table class="table table-hover  table-responsive ">
                  <thead>
                    <tr class="fixed-table">
                      <th scope="col">Pagina</th>
                      <th scope="col">Cobertura</th>
                      <th scope="col">Prima Neta</th>
                      <span class="d-none"><?php echo e($numColumnas=1); ?></span>
                    </tr>
                  </thead>
                  <tbody>
                    <?php $__currentLoopData = $detalle_cobertura_coberturas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $detalle_cobertura_cobertura): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                      
                      <td><?php echo e($detalle_cobertura_cobertura->pagina); ?></td>
                      <td>
                        <?php echo e($detalle_cobertura_cobertura->cobertura); ?>

                      </td>
                      <td>
                        <?php if($detalle_cobertura_cobertura->primaNeta == 1): ?>
                        <span class="d-none"><?php echo e($numAciertos++); ?></span>
                        <div class="checkdiv"><input disabled checked type="checkbox" class="le-checkbox"/></div>
                        <?php elseif($detalle_cobertura_cobertura->primaNeta == 0): ?>
                        <div class="checkdiv"><input disabled  type="checkbox" class="le-checkbox"/></div>
                        <?php else: ?>
                        <img src="<?php echo e(asset('img/unknown.png')); ?>" alt="" width="32">
                        <?php endif; ?>
                      </td>
                    </tr>
                    <span class="d-none"><?php echo e($contador++); ?></span>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <div class="btn-success d-none">Aciertos Coberturas = <?php echo e($numAciertos); ?>/<?php echo e($numColumnas*$contador); ?></div>
                  </tbody>
                </table>
                <span class="d-none"><?php echo e($guardarAciertos=$guardarAciertos+$numAciertos, $guardarColumnas=$guardarColumnas+($numColumnas*$contador)); ?></span>

                
                <div class="btn-success d-none position-absolute"><?php echo e($guardarAciertos); ?>/<?php echo e($guardarColumnas); ?></div>
              </div>

            
              <div class="tab-pane fade" id="tabD">
                <span class="d-none"><?php echo e($numAciertos=0, $contador=0); ?></span>
                <table class="table table-hover table-responsive">
                  <thead>
                    <tr class="fixed-table">
                      
                      <th scope="col">Subgrupo</th>
                      <th scope="col">Categoría</th>
                      <th scope="col">Endoso</th>
                      <th scope="col">Valor</th>
                      <span class="d-none"><?php echo e($numColumnas=1); ?></span>
                    </tr>
                  </thead>
                  <tbody>
                    <?php $__currentLoopData = $endosos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $endoso): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                      
                      <td><?php echo e($endoso->subgrupo); ?></td>
                      <td><?php echo e($endoso->categoria); ?></td>
                      <td><?php echo e($endoso->endoso); ?></td>
                      <td>
                        <?php if($endoso->valorEndoso == 1): ?>
                        <div class="checkdiv"><input disabled checked type="checkbox" class="le-checkbox"/></div>
                        <span class="d-none"><?php echo e($numAciertos++); ?></span>
                        <?php elseif($endoso->valorEndoso == 0): ?>
                        <div class="checkdiv"><input disabled  type="checkbox" class="le-checkbox"/></div>
                        <?php else: ?>
                        <img src="<?php echo e(asset('img/unknown.png')); ?>" alt="" width="32">
                        <?php endif; ?>
                      </td>
                      <span class="d-none"><?php echo e($contador++); ?></span>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <div class="btn-success d-none">Aciertos Coberturas = <?php echo e($numAciertos); ?>/<?php echo e($numColumnas*$contador); ?></div>
                  </tbody>
                </table>
              </div>

            
              <div class="tab-pane fade" id="tabE">
                <form class="d-flex w-25" id="searchform" onkeyup="filterListado()">
                  <input class="form-control me-2 shadow-none" type="text" placeholder="No. de certificado" id="searchListado">
                  <button type="submit" disabled><img src="<?php echo e(asset('img/search.svg')); ?>"  alt="" ></button/>
                  
                </form>
                
                <span class="d-none"><?php echo e($numAciertos=0, $contador=0); ?></span>

                <table class="table table-hover table-responsive ">
                  <thead>
                    <tr class="fixed-table">
                      
                      <th scope="col">Certificado</th>
                      <th scope="col">Subgrupo</th>
                      <th scope="col">Categoría</th>
                      <th scope="col">Nombre</th>
                      <th scope="col">Antiguedad</th>
                      <th scope="col">Edad</th>
                      <th scope="col">Sexo</th>
                      <th scope="col">Fecha Alta/Baja</th>
                      <span class="d-none"><?php echo e($numColumnas=6); ?></span>
                    </tr>
                  </thead>
                  <tbody id="tbody-listado_asegurados">
                    <?php $__currentLoopData = $listado_asegurados; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $listado_asegurado): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                      
                      <td class="tr-td-certificado-listado_asegurados"><?php echo e($listado_asegurado->certificado); ?></td>
                      <td><?php echo e($listado_asegurado->subgrupo); ?></td>
                      <td>
                        <?php if($listado_asegurado->categoria == 1): ?>
                        <span class="d-none"><?php echo e($numAciertos++); ?></span>
                        <div class="checkdiv"><input disabled checked type="checkbox" class="le-checkbox"/></div>
                        <?php elseif($listado_asegurado->categoria == 0): ?>
                        <div class="checkdiv"><input disabled  type="checkbox" class="le-checkbox"/></div>
                        <?php else: ?>
                        <img src="<?php echo e(asset('img/unknown.png')); ?>" alt="" width="32">
                        <?php endif; ?>
                      </td>
                      <td>
                        <?php if($listado_asegurado->nombre == 1): ?>
                        <span class="d-none"><?php echo e($numAciertos++); ?></span>
                        <div class="checkdiv"><input disabled checked type="checkbox" class="le-checkbox"/></div>
                        <?php elseif($listado_asegurado->nombre == 0): ?>
                        <div class="checkdiv"><input disabled  type="checkbox" class="le-checkbox"/></div>
                        <?php else: ?>
                        <img src="<?php echo e(asset('img/unknown.png')); ?>" alt="" width="32">
                        <?php endif; ?>
                      </td>
                      <td>
                        <?php if($listado_asegurado->antiguedad == 1): ?>
                        <span class="d-none"><?php echo e($numAciertos++); ?></span>
                        <div class="checkdiv"><input disabled checked type="checkbox" class="le-checkbox"/></div>
                        <?php elseif($listado_asegurado->antiguedad == 0): ?>
                        <div class="checkdiv"><input disabled  type="checkbox" class="le-checkbox"/></div>
                        <?php else: ?>
                        <img src="<?php echo e(asset('img/unknown.png')); ?>" alt="" width="32">
                        <?php endif; ?>
                      </td>
                      <td>
                        <?php if($listado_asegurado->edad == 1): ?>
                        <span class="d-none"><?php echo e($numAciertos++); ?></span>
                        <div class="checkdiv"><input disabled checked type="checkbox" class="le-checkbox"/></div>
                        <?php elseif($listado_asegurado->edad == 0): ?>
                        <div class="checkdiv"><input disabled  type="checkbox" class="le-checkbox"/></div>
                        <?php else: ?>
                        <img src="<?php echo e(asset('img/unknown.png')); ?>" alt="" width="32">
                        <?php endif; ?>
                      </td>
                      <td>
                        <?php if($listado_asegurado->sexo == 1): ?>
                        <span class="d-none"><?php echo e($numAciertos++); ?></span>
                        <div class="checkdiv"><input disabled checked type="checkbox" class="le-checkbox"/></div>
                        <?php elseif($listado_asegurado->sexo == 0): ?>
                        <div class="checkdiv"><input disabled  type="checkbox" class="le-checkbox"/></div>
                        <?php else: ?>
                        <img src="<?php echo e(asset('img/unknown.png')); ?>" alt="" width="32">
                        <?php endif; ?>
                      </td>
                      <td>
                        <?php if($listado_asegurado->fechaAltaBaja == 1): ?>
                        <span class="d-none"><?php echo e($numAciertos++); ?></span>
                        <div class="checkdiv"><input disabled checked type="checkbox" class="le-checkbox"/></div>
                        <?php elseif($listado_asegurado->fechaAltaBaja == 0): ?>
                        <div class="checkdiv"><input disabled  type="checkbox" class="le-checkbox"/></div>
                        <?php else: ?>
                        <img src="<?php echo e(asset('img/unknown.png')); ?>" alt="" width="32">
                        <?php endif; ?>
                      </td>
                      <span class="d-none"><?php echo e($contador++); ?></span>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <div class="btn-success d-none">Aciertos Coberturas = <?php echo e($numAciertos); ?>/<?php echo e($numColumnas*$contador); ?></div>
                  </tbody>
                </table>
              </div>
         </div>
       <!-- End Tabs -->

     </section>
    </main>
  </div>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\inter\resources\views/tabs.blade.php ENDPATH**/ ?>