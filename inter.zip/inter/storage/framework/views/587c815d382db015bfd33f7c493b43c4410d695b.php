<?php $__env->startSection('content'); ?>
<!--PreLoader style.css-->
  <div class="loader">
    <div class="loader-inner">
      <div class="cssload-loader"></div>
    </div>
  </div>
  <!--PreLoader Ends-->



<main class="main-inter">
  <h2>Interprotección</h2>
  <section class="container inter-main_table">
    <table class="table table-hover">
      <thead>
        <tr>
          <th scope="col">No. de Poliza</th>
          <th scope="col">Aciertos</th>
          <th></th>
        </tr>
      </thead>
      <tbody>
        <tr>
          <th scope="row">1</th>
          <td>11/100</td>
          <td><a class="table-td_hover" href="<?php echo e(route('coincidencias.index')); ?>">Ver detalles</a></td>
        </tr>
        <tr>
          <th scope="row">2</th>
          <td>74/100</td>
          <td><a class="table-td_hover" href="<?php echo e(route('coincidencias.index')); ?>">Ver detalles</a></td>
        </tr>
        <tr>
          <th scope="row">3</th>
          <td>100/100</td>
          <td><a class="table-td_hover" href="<?php echo e(route('coincidencias.index')); ?>">Ver detalles</a></td>
        </tr>
      </tbody>
    </table>
  </section>

</main>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\inter\resources\views/welcome.blade.php ENDPATH**/ ?>