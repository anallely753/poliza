<?php $__env->startSection('content'); ?>


<div class="body-home_inter">
  <main class="main-inter">
    <div class="logos">
      <img src="img/logos-completo.svg" alt="">
    </div>
    <section class="container inter-main_table">
      <table class="table">
        <thead>
          <tr>
            <th scope="col">No. de Poliza</th>
            <th scope="col">Aciertos</th>
            <th></th>
          </tr>
        </thead>
        <tbody>
          <tr>
            <td class="d-none">
              <div class="tab-content">
                 
                   <div class="tab-pane fade show active" id="tabA">
                     
                     <h3 class="main-inter_h3">Datos</h3>
                     <table class="table table-hover table-striped table-responsive table-bordered">
                       <thead>
                         <tr class="fixed-table">
                           
                           <th scope="col">Pagina</th>
                           <th scope="col">Plazo</th>
                           <th scope="col">Forma de Pago</th>
                           <th scope="col">Contributorio</th>
                           <th scope="col">inicio Vigencia</th>
                           <th scope="col">fin Vigencia</th>
                           <th scope="col">tipoDeAdministracion</th>
                           <th scope="col">Datos del contratante</th>
                           <th scope="col">Prima Neta</th>
                           <th scope="col">Recargos</th>
                           <th scope="col">Gastos expedición</th>
                           <th scope="col">IVA</th>
                           <th scope="col">Prima Total</th>
                           <th scope="col">Moneda</th>
                           <span class="d-none"><?php echo e($numColumnas=13); ?></span>
                         </tr>
                       </thead>
                       <tbody>
                         <?php $__currentLoopData = $caratula_datos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $caratula_dato): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                         <tr>
                           
                           <td><?php echo e($caratula_dato->pagina); ?></td>
                           <td>
                             <?php if($caratula_dato->plazo == 1): ?>
                             <div class="checkdiv"><input disabled checked type="checkbox" class="le-checkbox"/></div>
                             <span class="d-none"><?php echo e($numAciertos++); ?></span>
                             <?php elseif($caratula_dato->plazo == 0): ?>
                             <div class="checkdiv"><input disabled  type="checkbox" class="le-checkbox"/></div>
                             <?php else: ?>
                             <img src="<?php echo e(asset('img/unknown.png')); ?>" alt="" width="32">
                             <?php endif; ?>
                           </td>
                           <td>
                             <?php if($caratula_dato->formaDePago == 1): ?>
                             <span class="d-none"><?php echo e($numAciertos++); ?></span>
                             <div class="checkdiv"><input disabled checked type="checkbox" class="le-checkbox"/></div>
                             <?php elseif($caratula_dato->formaDePago == 0): ?>
                             <div class="checkdiv"><input disabled  type="checkbox" class="le-checkbox"/></div>
                             <?php else: ?>
                             <img src="<?php echo e(asset('img/unknown.png')); ?>" alt="" width="32">
                             <?php endif; ?>
                           </td>
                           <td>
                             <?php if($caratula_dato->contributorio == 1): ?>
                             <span class="d-none"><?php echo e($numAciertos++); ?></span>
                             <div class="checkdiv"><input disabled checked type="checkbox" class="le-checkbox"/></div>
                             <?php elseif($caratula_dato->contributorio == 0): ?>
                             <div class="checkdiv"><input disabled  type="checkbox" class="le-checkbox"/></div>
                             <?php else: ?>
                             <img src="<?php echo e(asset('img/unknown.png')); ?>" alt="" width="32">
                             <?php endif; ?>
                           </td>
                           <td>
                             <?php if($caratula_dato->inicioVigencia == 1): ?>
                             <span class="d-none"><?php echo e($numAciertos++); ?></span>
                             <div class="checkdiv"><input disabled checked type="checkbox" class="le-checkbox"/></div>
                             <?php elseif($caratula_dato->inicioVigencia == 0): ?>
                             <div class="checkdiv"><input disabled  type="checkbox" class="le-checkbox"/></div>
                             <?php else: ?>
                             <img src="<?php echo e(asset('img/unknown.png')); ?>" alt="" width="32">
                             <?php endif; ?>
                           </td>
                           <td>
                             <?php if($caratula_dato->finVigencia == 1): ?>
                             <span class="d-none"><?php echo e($numAciertos++); ?></span>
                             <div class="checkdiv"><input disabled checked type="checkbox" class="le-checkbox"/></div>
                             <?php elseif($caratula_dato->finVigencia == 0): ?>
                             <div class="checkdiv"><input disabled  type="checkbox" class="le-checkbox"/></div>
                             <?php else: ?>
                             <img src="<?php echo e(asset('img/unknown.png')); ?>" alt="" width="32">
                             <?php endif; ?>
                           </td>
                           <td>
                             <?php if($caratula_dato->tipoDeAdministracion == 1): ?>
                             <span class="d-none"><?php echo e($numAciertos++); ?></span>
                             <div class="checkdiv"><input disabled checked type="checkbox" class="le-checkbox"/></div>
                             <?php elseif($caratula_dato->tipoDeAdministracion == 0): ?>
                             <div class="checkdiv"><input disabled  type="checkbox" class="le-checkbox"/></div>
                             <?php else: ?>
                             <img src="<?php echo e(asset('img/unknown.png')); ?>" alt="" width="32">
                             <?php endif; ?>
                           </td>
                           <td>
                             <?php if($caratula_dato->datosDelContratante == 1): ?>
                             <span class="d-none"><?php echo e($numAciertos++); ?></span>
                             <div class="checkdiv"><input disabled checked type="checkbox" class="le-checkbox"/></div>
                             <?php elseif($caratula_dato->datosDelContratante == 0): ?>
                             <div class="checkdiv"><input disabled  type="checkbox" class="le-checkbox"/></div>
                             <?php else: ?>
                             <img src="<?php echo e(asset('img/unknown.png')); ?>" alt="" width="32">
                             <?php endif; ?>
                           </td>
                           <td>
                             <?php if($caratula_dato->primaNeta == 1): ?>
                             <span class="d-none"><?php echo e($numAciertos++); ?></span>
                             <div class="checkdiv"><input disabled checked type="checkbox" class="le-checkbox"/></div>
                             <?php elseif($caratula_dato->primaNeta == 0): ?>
                             <div class="checkdiv"><input disabled  type="checkbox" class="le-checkbox"/></div>
                             <?php else: ?>
                             <img src="<?php echo e(asset('img/unknown.png')); ?>" alt="" width="32">
                             <?php endif; ?>
                           </td>
                           <td>
                             <?php if($caratula_dato->recargos == 1): ?>
                             <span class="d-none"><?php echo e($numAciertos++); ?></span>
                             <div class="checkdiv"><input disabled checked type="checkbox" class="le-checkbox"/></div>
                             <?php elseif($caratula_dato->recargos == 0): ?>
                             <div class="checkdiv"><input disabled  type="checkbox" class="le-checkbox"/></div>
                             <?php else: ?>
                             <img src="<?php echo e(asset('img/unknown.png')); ?>" alt="" width="32">
                             <?php endif; ?>
                           </td>
                           <td>
                             <?php if($caratula_dato->gtosExpedicion == 1): ?>
                             <span class="d-none"><?php echo e($numAciertos++); ?></span>
                             <div class="checkdiv"><input disabled checked type="checkbox" class="le-checkbox"/></div>
                             <?php elseif($caratula_dato->gtosExpedicion == 0): ?>
                             <div class="checkdiv"><input disabled  type="checkbox" class="le-checkbox"/></div>
                             <?php else: ?>
                             <img src="<?php echo e(asset('img/unknown.png')); ?>" alt="" width="32">
                             <?php endif; ?>
                           </td>
                           <td>
                             <?php if($caratula_dato->IVA == 1): ?>
                             <span class="d-none"><?php echo e($numAciertos++); ?></span>
                             <div class="checkdiv"><input disabled checked type="checkbox" class="le-checkbox"/></div>
                             <?php elseif($caratula_dato->IVA == 0): ?>
                             <div class="checkdiv"><input disabled  type="checkbox" class="le-checkbox"/></div>
                             <?php else: ?>
                             <img src="<?php echo e(asset('img/unknown.png')); ?>" alt="" width="32">
                             <?php endif; ?>
                           </td>
                           <td>
                             <?php if($caratula_dato->primaTotal == 1): ?>
                             <span class="d-none"><?php echo e($numAciertos++); ?></span>
                             <div class="checkdiv"><input disabled checked type="checkbox" class="le-checkbox"/></div>
                             <?php elseif($caratula_dato->primaTotal == 0): ?>
                             <div class="checkdiv"><input disabled  type="checkbox" class="le-checkbox"/></div>
                             <?php else: ?>
                             <img src="<?php echo e(asset('img/unknown.png')); ?>" alt="" width="32">
                             <?php endif; ?>
                           </td>
                           <td>
                             <?php if($caratula_dato->moneda == 1): ?>
                             <span class="d-none"><?php echo e($numAciertos++); ?></span>
                             <div class="checkdiv"><input disabled checked type="checkbox" class="le-checkbox"/></div>
                             <?php elseif($caratula_dato->moneda == 0): ?>
                             <div class="checkdiv"><input disabled  type="checkbox" class="le-checkbox"/></div>
                             <?php else: ?>
                             <img src="<?php echo e(asset('img/unknown.png')); ?>" alt="" width="32">
                             <?php endif; ?>
                           </td>
                         </tr>
                         <span class="d-none"><?php echo e($contador++); ?></span>
                         <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                         <div class="btn-success">Aciertos Datos= <?php echo e($numAciertos); ?>/<?php echo e($numColumnas*$contador); ?></div>
                       </tbody>
                     </table>
                     
                     <span class="d-none"><?php echo e($guardarAciertos=$numAciertos, $guardarColumnas=$numColumnas*$contador); ?></span>
                     <?php echo e($guardarAciertos); ?>

                     <?php echo e($guardarColumnas); ?>

                      <span class="d-none"><?php echo e($totalAciertos=$totalAciertos+$numAciertos, $totalColumnas=$totalColumnas+($numColumnas*$contador)); ?></span>

                     
                     <h3 class="main-inter_h3">Coberturas</h3>
                     <span class="d-none"><?php echo e($numAciertos=0, $numColumnas=0, $contador=0); ?></span>
                     <table class="table table-hover table-striped table-responsive table-bordered">
                       <thead>
                         <tr class="fixed-table">
                           
                           <th scope="col">Pagina</th>
                           <th scope="col">Cobertura</th>
                           <th scope="col">Suma Asegurada</th>
                           <th scope="col">Prima Neta</th>
                           <span class="d-none"><?php echo e($numColumnas=2); ?></span>
                         </tr>
                       </thead>
                         <span class="d-none"><?php echo e($caratulaI=0); ?></span>
                       <tbody>
                         <?php $__currentLoopData = $caratula_coberturas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $caratula_cobertura): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                         <tr>
                           
                           <td><?php echo e($caratula_cobertura->pagina); ?></td>
                           <td>
                             <?php echo e($caratula_cobertura->cobertura); ?>

                           </td>
                           <td>
                             <?php if($caratula_cobertura->sumaAsegurada == 1): ?>
                             <div class="checkdiv"><input disabled checked type="checkbox" class="le-checkbox"/></div>
                             <span class="d-none"><?php echo e($numAciertos++); ?></span>

                             <?php elseif($caratula_cobertura->sumaAsegurada == 0): ?>
                             <div class="checkdiv"><input disabled  type="checkbox" class="le-checkbox"/></div>
                             <?php else: ?>
                             <img src="<?php echo e(asset('img/unknown.png')); ?>" alt="" width="32">
                             <?php endif; ?>
                           </td>
                           <td>
                             <?php if($caratula_cobertura->primaNeta == 1): ?>
                             <span class="d-none"><?php echo e($numAciertos++); ?></span>
                             <div class="checkdiv"><input disabled checked type="checkbox" class="le-checkbox"/></div>
                             <?php elseif($caratula_cobertura->primaNeta == 0): ?>
                             <div class="checkdiv"><input disabled  type="checkbox" class="le-checkbox"/></div>
                             <?php else: ?>
                             <img src="<?php echo e(asset('img/unknown.png')); ?>" alt="" width="32">
                             <?php endif; ?>
                           </td>
                         </tr>
                         <span class="d-none"><?php echo e($contador++); ?></span>
                         <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                         <div class="btn-success">Aciertos Coberturas = <?php echo e($numAciertos); ?>/<?php echo e($numColumnas*$contador); ?></div>
                       </tbody>
                     </table>
                     <span class="d-none"><?php echo e($guardarAciertos=$guardarAciertos+$numAciertos, $guardarColumnas=$guardarColumnas+($numColumnas*$contador)); ?></span>

                     
                     <div class="btn-success position-absolute"><?php echo e($guardarAciertos); ?>/<?php echo e($guardarColumnas); ?></div>
                     <div class="btn-success position-absolute"><?php echo e($totalAciertos=$guardarAciertos); ?>/<?php echo e($totalColumnas=$guardarColumnas); ?></div>
                     <?php echo e($paraTabsA=$totalAciertos, $paraTabsC=$totalColumnas); ?>




                        
                   </div>

                 
                   <div class="tab-pane fade" id="tabB">
                     <form class="d-flex w-25" id="searchform" onkeyup="filterConsentimientos()">
                       <input class="form-control me-2" type="text" placeholder="Busca por # de certificado " id="searchConsentimientos">
                       
                     </form>
                     <span class="d-none"><?php echo e($numAciertos=0, $contador=0); ?></span>
                     <table class="table table-hover table-striped table-responsive table-bordered">
                       <thead>
                         <tr class="fixed-table">
                           
                           <th scope="col">Certificado</th>
                           <th scope="col">Nombre</th>
                           <th scope="col">Sexo</th>
                           <th scope="col">Edad</th>
                           <th scope="col">Fecha de Nacimiento</th>
                           <th scope="col">Datos del contratante</th>
                           <th scope="col">Plazo</th>
                           <th scope="col">Forma de Pago</th>
                           <th scope="col">Contributorio</th>
                           <th scope="col">Inicio Vigencia</th>
                           <th scope="col">Fin Vigencia</th>
                           <th scope="col">Moneda</th>
                           <span class="d-none"><?php echo e($numColumnas=11); ?></span>
                         </tr>
                       </thead>
                       <tbody id="tbody-consentimientos_vida_datos">
                         <?php $__currentLoopData = $consentimientos_vida_datos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $consentimientos_vida_dato): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                         <tr class="tr-consentimientos_vida_datos">
                           <td class="tr-td-certificado-consentimientos_vida_datos"><?php echo e($consentimientos_vida_dato->certificado); ?></td>
                           <td>
                             <?php if($consentimientos_vida_dato->nombre == 1): ?>
                             <span class="d-none"><?php echo e($numAciertos++); ?></span>
                             <div class="checkdiv"><input disabled checked type="checkbox" class="le-checkbox"/></div>
                             <?php elseif($consentimientos_vida_dato->nombre == 0): ?>
                             <div class="checkdiv"><input disabled  type="checkbox" class="le-checkbox"/></div>
                             <?php else: ?>
                             <img src="<?php echo e(asset('img/unknown.png')); ?>" alt="" width="32">
                             <?php endif; ?>
                           </td>
                           <td>
                             <?php if($consentimientos_vida_dato->sexo == 1): ?>
                             <span class="d-none"><?php echo e($numAciertos++); ?></span>
                             <div class="checkdiv"><input disabled checked type="checkbox" class="le-checkbox"/></div>
                             <?php elseif($consentimientos_vida_dato->nombre == 0): ?>
                             <div class="checkdiv"><input disabled  type="checkbox" class="le-checkbox"/></div>
                             <?php else: ?>
                             <img src="<?php echo e(asset('img/unknown.png')); ?>" alt="" width="32">
                             <?php endif; ?>
                           </td>
                           <td>
                             <?php if($consentimientos_vida_dato->edad == 1): ?>
                             <span class="d-none"><?php echo e($numAciertos++); ?></span>
                             <div class="checkdiv"><input disabled checked type="checkbox" class="le-checkbox"/></div>
                             <?php elseif($consentimientos_vida_dato->edad == 0): ?>
                             <div class="checkdiv"><input disabled  type="checkbox" class="le-checkbox"/></div>
                             <?php else: ?>
                             <img src="<?php echo e(asset('img/unknown.png')); ?>" alt="" width="32">
                             <?php endif; ?>
                           </td>
                           <td>
                             <?php if($consentimientos_vida_dato->fechaDeNacimiento == 1): ?>
                             <span class="d-none"><?php echo e($numAciertos++); ?></span>
                             <div class="checkdiv"><input disabled checked type="checkbox" class="le-checkbox"/></div>
                             <?php elseif($consentimientos_vida_dato->fechaDeNacimiento == 0): ?>
                             <div class="checkdiv"><input disabled  type="checkbox" class="le-checkbox"/></div>
                             <?php else: ?>
                             <img src="<?php echo e(asset('img/unknown.png')); ?>" alt="" width="32">
                             <?php endif; ?>
                           </td>
                           <td>
                             <?php if($consentimientos_vida_dato->datosDelContratante == 1): ?>
                             <span class="d-none"><?php echo e($numAciertos++); ?></span>
                             <div class="checkdiv"><input disabled checked type="checkbox" class="le-checkbox"/></div>
                             <?php elseif($consentimientos_vida_dato->datosDelContratante == 0): ?>
                             <div class="checkdiv"><input disabled  type="checkbox" class="le-checkbox"/></div>
                             <?php else: ?>
                             <img src="<?php echo e(asset('img/unknown.png')); ?>" alt="" width="32">
                             <?php endif; ?>
                           </td>
                           <td>
                             <?php if($consentimientos_vida_dato->plazo == 1): ?>
                             <span class="d-none"><?php echo e($numAciertos++); ?></span>
                             <div class="checkdiv"><input disabled checked type="checkbox" class="le-checkbox"/></div>
                             <?php elseif($consentimientos_vida_dato->plazo == 0): ?>
                             <div class="checkdiv"><input disabled  type="checkbox" class="le-checkbox"/></div>
                             <?php else: ?>
                             <img src="<?php echo e(asset('img/unknown.png')); ?>" alt="" width="32">
                             <?php endif; ?>
                           </td>
                           <td>
                             <?php if($consentimientos_vida_dato->formaDePago == 1): ?>
                             <span class="d-none"><?php echo e($numAciertos++); ?></span>
                             <div class="checkdiv"><input disabled checked type="checkbox" class="le-checkbox"/></div>
                             <?php elseif($consentimientos_vida_dato->formaDePago == 0): ?>
                             <div class="checkdiv"><input disabled  type="checkbox" class="le-checkbox"/></div>
                             <?php else: ?>
                             <img src="<?php echo e(asset('img/unknown.png')); ?>" alt="" width="32">
                             <?php endif; ?>
                           </td>
                           <td>
                             <?php if($consentimientos_vida_dato->contributorio == 1): ?>
                             <span class="d-none"><?php echo e($numAciertos++); ?></span>
                             <div class="checkdiv"><input disabled checked type="checkbox" class="le-checkbox"/></div>
                             <?php elseif($consentimientos_vida_dato->contributorio == 0): ?>
                             <div class="checkdiv"><input disabled  type="checkbox" class="le-checkbox"/></div>
                             <?php else: ?>
                             <img src="<?php echo e(asset('img/unknown.png')); ?>" alt="" width="32">
                             <?php endif; ?>
                           </td>
                           <td>
                             <?php if($consentimientos_vida_dato->inicioVigencia == 1): ?>
                             <span class="d-none"><?php echo e($numAciertos++); ?></span>
                             <div class="checkdiv"><input disabled checked type="checkbox" class="le-checkbox"/></div>
                             <?php elseif($consentimientos_vida_dato->inicioVigencia == 0): ?>
                             <div class="checkdiv"><input disabled  type="checkbox" class="le-checkbox"/></div>
                             <?php else: ?>
                             <img src="<?php echo e(asset('img/unknown.png')); ?>" alt="" width="32">
                             <?php endif; ?>
                           </td>
                           <td>
                             <?php if($consentimientos_vida_dato->finVigencia == 1): ?>
                             <span class="d-none"><?php echo e($numAciertos++); ?></span>
                             <div class="checkdiv"><input disabled checked type="checkbox" class="le-checkbox"/></div>
                             <?php elseif($consentimientos_vida_dato->finVigencia == 0): ?>
                             <div class="checkdiv"><input disabled  type="checkbox" class="le-checkbox"/></div>
                             <?php else: ?>
                             <img src="<?php echo e(asset('img/unknown.png')); ?>" alt="" width="32">
                             <?php endif; ?>
                           </td>
                           <td>
                             <?php if($consentimientos_vida_dato->moneda == 1): ?>
                             <span class="d-none"><?php echo e($numAciertos++); ?></span>
                             <div class="checkdiv"><input disabled checked type="checkbox" class="le-checkbox"/></div>
                             <?php elseif($consentimientos_vida_dato->moneda == 0): ?>
                             <div class="checkdiv"><input disabled  type="checkbox" class="le-checkbox"/></div>
                             <?php else: ?>
                             <img src="<?php echo e(asset('img/unknown.png')); ?>" alt="" width="32">
                             <?php endif; ?>
                           </td>
                           <span class="d-none"><?php echo e($contador++); ?></span>
                         </tr>
                           
                         <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                         <div class="btn-success">Aciertos Coberturas = <?php echo e($numAciertos); ?>/<?php echo e($numColumnas*$contador); ?></div>
                         <span class="d-none"><?php echo e($totalAciertos=$totalAciertos+$numAciertos, $totalColumnas=$totalColumnas+($numColumnas*$contador)); ?></span>
                       </tbody>
                     </table>
                   </div>
                 
                   <div class="tab-pane fade" id="tabC">
                     
                     <h3 class="main-inter_h3">Datos</h3>
                     <span class="d-none"><?php echo e($numAciertos=0, $contador=0); ?></span>
                     <table class="table table-hover table-striped table-responsive table-bordered">
                       <thead>
                         <tr class="fixed-table">
                           
                           <th scope="col">Pagina</th>
                           <th scope="col">Plazo</th>
                           <th scope="col">Forma de Pago</th>
                           <th scope="col">Contributorio</th>
                           <th scope="col">inicio Vigencia</th>
                           <th scope="col">fin Vigencia</th>
                           <th scope="col">asegurados</th>
                           <th scope="col">Datos del contratante</th>
                           <th scope="col">Prima Neta</th>
                           <th scope="col">Recargos</th>
                           <th scope="col">Gastos expedición</th>
                           <th scope="col">IVA</th>
                           <th scope="col">Prima Total</th>
                           <th scope="col">Moneda</th>
                           <span class="d-none"><?php echo e($numColumnas=13); ?></span>
                         </tr>
                       </thead>
                       <tbody>
                         <?php $__currentLoopData = $detalle_cobertura_datos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $detalle_cobertura_dato): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                         <tr>
                           
                           <td><?php echo e($detalle_cobertura_dato->pagina); ?></td>
                           <td>
                             <?php if($detalle_cobertura_dato->plazo == 1): ?>
                             <div class="checkdiv"><input disabled checked type="checkbox" class="le-checkbox"/></div>
                             <span class="d-none"><?php echo e($numAciertos++); ?></span>
                             <?php elseif($detalle_cobertura_dato->plazo == 0): ?>
                             <div class="checkdiv"><input disabled  type="checkbox" class="le-checkbox"/></div>
                             <?php else: ?>
                             <img src="<?php echo e(asset('img/unknown.png')); ?>" alt="" width="32">
                             <?php endif; ?>
                           </td>
                           <td>
                             <?php if($detalle_cobertura_dato->formaDePago == 1): ?>
                             <span class="d-none"><?php echo e($numAciertos++); ?></span>
                             <div class="checkdiv"><input disabled checked type="checkbox" class="le-checkbox"/></div>
                             <?php elseif($detalle_cobertura_dato->formaDePago == 0): ?>
                             <div class="checkdiv"><input disabled  type="checkbox" class="le-checkbox"/></div>
                             <?php else: ?>
                             <img src="<?php echo e(asset('img/unknown.png')); ?>" alt="" width="32">
                             <?php endif; ?>
                           </td>
                           <td>
                             <?php if($detalle_cobertura_dato->contributorio == 1): ?>
                             <span class="d-none"><?php echo e($numAciertos++); ?></span>
                             <div class="checkdiv"><input disabled checked type="checkbox" class="le-checkbox"/></div>
                             <?php elseif($detalle_cobertura_dato->contributorio == 0): ?>
                             <div class="checkdiv"><input disabled  type="checkbox" class="le-checkbox"/></div>
                             <?php else: ?>
                             <img src="<?php echo e(asset('img/unknown.png')); ?>" alt="" width="32">
                             <?php endif; ?>
                           </td>
                           <td>
                             <?php if($detalle_cobertura_dato->inicioVigencia == 1): ?>
                             <span class="d-none"><?php echo e($numAciertos++); ?></span>
                             <div class="checkdiv"><input disabled checked type="checkbox" class="le-checkbox"/></div>
                             <?php elseif($detalle_cobertura_dato->inicioVigencia == 0): ?>
                             <div class="checkdiv"><input disabled  type="checkbox" class="le-checkbox"/></div>
                             <?php else: ?>
                             <img src="<?php echo e(asset('img/unknown.png')); ?>" alt="" width="32">
                             <?php endif; ?>
                           </td>
                           <td>
                             <?php if($detalle_cobertura_dato->finVigencia == 1): ?>
                             <span class="d-none"><?php echo e($numAciertos++); ?></span>
                             <div class="checkdiv"><input disabled checked type="checkbox" class="le-checkbox"/></div>
                             <?php elseif($detalle_cobertura_dato->finVigencia == 0): ?>
                             <div class="checkdiv"><input disabled  type="checkbox" class="le-checkbox"/></div>
                             <?php else: ?>
                             <img src="<?php echo e(asset('img/unknown.png')); ?>" alt="" width="32">
                             <?php endif; ?>
                           </td>
                           <td>
                             <?php if($detalle_cobertura_dato->asegurados == 1): ?>
                             <span class="d-none"><?php echo e($numAciertos++); ?></span>
                             <div class="checkdiv"><input disabled checked type="checkbox" class="le-checkbox"/></div>
                             <?php elseif($detalle_cobertura_dato->asegurados == 0): ?>
                             <div class="checkdiv"><input disabled  type="checkbox" class="le-checkbox"/></div>
                             <?php else: ?>
                             <img src="<?php echo e(asset('img/unknown.png')); ?>" alt="" width="32">
                             <?php endif; ?>
                           </td>
                           <td>
                             <?php if($detalle_cobertura_dato->datosDelContratante == 1): ?>
                             <span class="d-none"><?php echo e($numAciertos++); ?></span>
                             <div class="checkdiv"><input disabled checked type="checkbox" class="le-checkbox"/></div>
                             <?php elseif($detalle_cobertura_dato->datosDelContratante == 0): ?>
                             <div class="checkdiv"><input disabled  type="checkbox" class="le-checkbox"/></div>
                             <?php else: ?>
                             <img src="<?php echo e(asset('img/unknown.png')); ?>" alt="" width="32">
                             <?php endif; ?>
                           </td>
                           <td>
                             <?php if($detalle_cobertura_dato->primaNeta == 1): ?>
                             <span class="d-none"><?php echo e($numAciertos++); ?></span>
                             <div class="checkdiv"><input disabled checked type="checkbox" class="le-checkbox"/></div>
                             <?php elseif($detalle_cobertura_dato->primaNeta == 0): ?>
                             <div class="checkdiv"><input disabled  type="checkbox" class="le-checkbox"/></div>
                             <?php else: ?>
                             <img src="<?php echo e(asset('img/unknown.png')); ?>" alt="" width="32">
                             <?php endif; ?>
                           </td>
                           <td>
                             <?php if($detalle_cobertura_dato->recargos == 1): ?>
                             <span class="d-none"><?php echo e($numAciertos++); ?></span>
                             <div class="checkdiv"><input disabled checked type="checkbox" class="le-checkbox"/></div>
                             <?php elseif($detalle_cobertura_dato->recargos == 0): ?>
                             <div class="checkdiv"><input disabled  type="checkbox" class="le-checkbox"/></div>
                             <?php else: ?>
                             <img src="<?php echo e(asset('img/unknown.png')); ?>" alt="" width="32">
                             <?php endif; ?>
                           </td>
                           <td>
                             <?php if($detalle_cobertura_dato->gtosExpedicion == 1): ?>
                             <span class="d-none"><?php echo e($numAciertos++); ?></span>
                             <div class="checkdiv"><input disabled checked type="checkbox" class="le-checkbox"/></div>
                             <?php elseif($detalle_cobertura_dato->gtosExpedicion == 0): ?>
                             <div class="checkdiv"><input disabled  type="checkbox" class="le-checkbox"/></div>
                             <?php else: ?>
                             <img src="<?php echo e(asset('img/unknown.png')); ?>" alt="" width="32">
                             <?php endif; ?>
                           </td>
                           <td>
                             <?php if($detalle_cobertura_dato->IVA == 1): ?>
                             <span class="d-none"><?php echo e($numAciertos++); ?></span>
                             <div class="checkdiv"><input disabled checked type="checkbox" class="le-checkbox"/></div>
                             <?php elseif($detalle_cobertura_dato->IVA == 0): ?>
                             <div class="checkdiv"><input disabled  type="checkbox" class="le-checkbox"/></div>
                             <?php else: ?>
                             <img src="<?php echo e(asset('img/unknown.png')); ?>" alt="" width="32">
                             <?php endif; ?>
                           </td>
                           <td>
                             <?php if($detalle_cobertura_dato->primaTotal == 1): ?>
                             <span class="d-none"><?php echo e($numAciertos++); ?></span>
                             <div class="checkdiv"><input disabled checked type="checkbox" class="le-checkbox"/></div>
                             <?php elseif($detalle_cobertura_dato->primaTotal == 0): ?>
                             <div class="checkdiv"><input disabled  type="checkbox" class="le-checkbox"/></div>
                             <?php else: ?>
                             <img src="<?php echo e(asset('img/unknown.png')); ?>" alt="" width="32">
                             <?php endif; ?>
                           </td>
                           <td>
                             <?php if($detalle_cobertura_dato->moneda == 1): ?>
                             <span class="d-none"><?php echo e($numAciertos++); ?></span>
                             <div class="checkdiv"><input disabled checked type="checkbox" class="le-checkbox"/></div>
                             <?php elseif($detalle_cobertura_dato->moneda == 0): ?>
                             <div class="checkdiv"><input disabled  type="checkbox" class="le-checkbox"/></div>
                             <?php else: ?>
                             <img src="<?php echo e(asset('img/unknown.png')); ?>" alt="" width="32">
                             <?php endif; ?>
                           </td>
                         </tr>
                         <span class="d-none"><?php echo e($contador++); ?></span>
                         <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                         <div class="btn-success">Aciertos Datos= <?php echo e($numAciertos); ?>/<?php echo e($numColumnas*$contador); ?></div>
                       </tbody>
                     </table>
                     
                     <span class="d-none"><?php echo e($guardarAciertos=$numAciertos, $guardarColumnas=$numColumnas*$contador); ?></span>
                     <span class="d-none"><?php echo e($totalAciertos=$totalAciertos+$numAciertos, $totalColumnas=$totalColumnas+($numColumnas*$contador)); ?></span>

                     <?php echo e($guardarAciertos); ?>

                     <?php echo e($guardarColumnas); ?>

                     
                     <h3 class="main-inter_h3">Coberturas</h3>
                     <span class="d-none"><?php echo e($numAciertos=0, $numColumnas=0, $contador=0); ?></span>
                     <table class="table table-hover table-striped table-responsive table-bordered">
                       <thead>
                         <tr class="fixed-table">
                           <th scope="col">Pagina</th>
                           <th scope="col">Cobertura</th>
                           <th scope="col">Prima Neta</th>
                           <span class="d-none"><?php echo e($numColumnas=1); ?></span>
                         </tr>
                       </thead>
                       <tbody>
                         <?php $__currentLoopData = $detalle_cobertura_coberturas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $detalle_cobertura_cobertura): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                         <tr>
                           
                           <td><?php echo e($detalle_cobertura_cobertura->pagina); ?></td>
                           <td>
                             <?php echo e($detalle_cobertura_cobertura->cobertura); ?>

                           </td>
                           <td>
                             <?php if($detalle_cobertura_cobertura->primaNeta == 1): ?>
                             <span class="d-none"><?php echo e($numAciertos++); ?></span>
                             <div class="checkdiv"><input disabled checked type="checkbox" class="le-checkbox"/></div>
                             <?php elseif($detalle_cobertura_cobertura->primaNeta == 0): ?>
                             <div class="checkdiv"><input disabled  type="checkbox" class="le-checkbox"/></div>
                             <?php else: ?>
                             <img src="<?php echo e(asset('img/unknown.png')); ?>" alt="" width="32">
                             <?php endif; ?>
                           </td>
                         </tr>
                         <span class="d-none"><?php echo e($contador++); ?></span>
                         <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                         <div class="btn-success">Aciertos Coberturas = <?php echo e($numAciertos); ?>/<?php echo e($numColumnas*$contador); ?></div>
                       </tbody>
                     </table>
                     <span class="d-none"><?php echo e($guardarAciertos=$guardarAciertos+$numAciertos, $guardarColumnas=$guardarColumnas+($numColumnas*$contador)); ?></span>
                     <span class="d-none"><?php echo e($totalAciertos=$totalAciertos+$numAciertos, $totalColumnas=$totalColumnas+($numColumnas*$contador)); ?></span>
                     
                     <div class="btn-success position-absolute"><?php echo e($guardarAciertos); ?>/<?php echo e($guardarColumnas); ?></div>

                   </div>
                 
                   <div class="tab-pane fade" id="tabD">
                     <span class="d-none"><?php echo e($numAciertos=0, $contador=0); ?></span>
                     <table class="table table-hover table-striped table-responsive">
                       <thead>
                         <tr class="fixed-table">
                           
                           <th scope="col">Subgrupo</th>
                           <th scope="col">Categoría</th>
                           <th scope="col">Endoso</th>
                           <th scope="col">Valor</th>
                           <span class="d-none"><?php echo e($numColumnas=1); ?></span>
                         </tr>
                       </thead>
                       <tbody>
                         <?php $__currentLoopData = $endosos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $endoso): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                         <tr>
                           
                           <td><?php echo e($endoso->subgrupo); ?></td>
                           <td><?php echo e($endoso->categoria); ?></td>
                           <td><?php echo e($endoso->endoso); ?></td>
                           <td>
                             <?php if($endoso->valorEndoso == 1): ?>
                             <div class="checkdiv"><input disabled checked type="checkbox" class="le-checkbox"/></div>
                             <span class="d-none"><?php echo e($numAciertos++); ?></span>
                             <?php elseif($endoso->valorEndoso == 0): ?>
                             <div class="checkdiv"><input disabled  type="checkbox" class="le-checkbox"/></div>
                             <?php else: ?>
                             <img src="<?php echo e(asset('img/unknown.png')); ?>" alt="" width="32">
                             <?php endif; ?>
                           </td>
                           <span class="d-none"><?php echo e($contador++); ?></span>
                         </tr>
                         <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                         <div class="btn-success">Aciertos Coberturas = <?php echo e($numAciertos); ?>/<?php echo e($numColumnas*$contador); ?></div>
                         <span class="d-none"><?php echo e($totalAciertos=$totalAciertos+$numAciertos, $totalColumnas=$totalColumnas+($numColumnas*$contador)); ?></span>
                       </tbody>
                     </table>
                   </div>
                 
                   <div class="tab-pane fade" id="tabE">
                     <form class="d-flex w-25" id="searchform" onkeyup="filterListado()">
                       <input class="form-control me-2" type="text" placeholder="Busca por # de certificado " id="searchListado">
                       
                     </form>
                     <span class="d-none"><?php echo e($numAciertos=0, $contador=0); ?></span>

                     <table class="table table-hover table-striped table-responsive table-bordered">
                       <thead>
                         <tr class="fixed-table">
                           
                           <th scope="col">Certificado</th>
                           <th scope="col">Subgrupo</th>
                           <th scope="col">Categoría</th>
                           <th scope="col">Nombre</th>
                           <th scope="col">Antiguedad</th>
                           <th scope="col">Edad</th>
                           <th scope="col">Sexo</th>
                           <th scope="col">FechaAltaBaja</th>
                           <span class="d-none"><?php echo e($numColumnas=6); ?></span>
                         </tr>
                       </thead>
                       <tbody id="tbody-listado_asegurados">
                         <?php $__currentLoopData = $listado_asegurados; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $listado_asegurado): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                         <tr>
                           
                           <td class="tr-td-certificado-listado_asegurados"><?php echo e($listado_asegurado->certificado); ?></td>
                           <td><?php echo e($listado_asegurado->subgrupo); ?></td>
                           <td>
                             <?php if($listado_asegurado->categoria == 1): ?>
                             <span class="d-none"><?php echo e($numAciertos++); ?></span>
                             <div class="checkdiv"><input disabled checked type="checkbox" class="le-checkbox"/></div>
                             <?php elseif($listado_asegurado->categoria == 0): ?>
                             <div class="checkdiv"><input disabled  type="checkbox" class="le-checkbox"/></div>
                             <?php else: ?>
                             <img src="<?php echo e(asset('img/unknown.png')); ?>" alt="" width="32">
                             <?php endif; ?>
                           </td>
                           <td>
                             <?php if($listado_asegurado->nombre == 1): ?>
                             <span class="d-none"><?php echo e($numAciertos++); ?></span>
                             <div class="checkdiv"><input disabled checked type="checkbox" class="le-checkbox"/></div>
                             <?php elseif($listado_asegurado->nombre == 0): ?>
                             <div class="checkdiv"><input disabled  type="checkbox" class="le-checkbox"/></div>
                             <?php else: ?>
                             <img src="<?php echo e(asset('img/unknown.png')); ?>" alt="" width="32">
                             <?php endif; ?>
                           </td>
                           <td>
                             <?php if($listado_asegurado->antiguedad == 1): ?>
                             <span class="d-none"><?php echo e($numAciertos++); ?></span>
                             <div class="checkdiv"><input disabled checked type="checkbox" class="le-checkbox"/></div>
                             <?php elseif($listado_asegurado->antiguedad == 0): ?>
                             <div class="checkdiv"><input disabled  type="checkbox" class="le-checkbox"/></div>
                             <?php else: ?>
                             <img src="<?php echo e(asset('img/unknown.png')); ?>" alt="" width="32">
                             <?php endif; ?>
                           </td>
                           <td>
                             <?php if($listado_asegurado->edad == 1): ?>
                             <span class="d-none"><?php echo e($numAciertos++); ?></span>
                             <div class="checkdiv"><input disabled checked type="checkbox" class="le-checkbox"/></div>
                             <?php elseif($listado_asegurado->edad == 0): ?>
                             <div class="checkdiv"><input disabled  type="checkbox" class="le-checkbox"/></div>
                             <?php else: ?>
                             <img src="<?php echo e(asset('img/unknown.png')); ?>" alt="" width="32">
                             <?php endif; ?>
                           </td>
                           <td>
                             <?php if($listado_asegurado->sexo == 1): ?>
                             <span class="d-none"><?php echo e($numAciertos++); ?></span>
                             <div class="checkdiv"><input disabled checked type="checkbox" class="le-checkbox"/></div>
                             <?php elseif($listado_asegurado->sexo == 0): ?>
                             <div class="checkdiv"><input disabled  type="checkbox" class="le-checkbox"/></div>
                             <?php else: ?>
                             <img src="<?php echo e(asset('img/unknown.png')); ?>" alt="" width="32">
                             <?php endif; ?>
                           </td>
                           <td>
                             <?php if($listado_asegurado->fechaAltaBaja == 1): ?>
                             <span class="d-none"><?php echo e($numAciertos++); ?></span>
                             <div class="checkdiv"><input disabled checked type="checkbox" class="le-checkbox"/></div>
                             <?php elseif($listado_asegurado->fechaAltaBaja == 0): ?>
                             <div class="checkdiv"><input disabled  type="checkbox" class="le-checkbox"/></div>
                             <?php else: ?>
                             <img src="<?php echo e(asset('img/unknown.png')); ?>" alt="" width="32">
                             <?php endif; ?>
                           </td>
                           <span class="d-none"><?php echo e($contador++); ?></span>
                         </tr>
                         <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                         <div class="btn-success">Aciertos Coberturas = <?php echo e($numAciertos); ?>/<?php echo e($numColumnas*$contador); ?></div>
                         <span class="d-none"><?php echo e($totalAciertos=$totalAciertos+$numAciertos, $totalColumnas=$totalColumnas+($numColumnas*$contador)); ?></span>

                       </tbody>
                     </table>
                   </div>
              </div>
            </td>
            <th scope="row"><?php echo e($noPoliza); ?></th>
            <td><?php echo e($totalAciertos); ?>/<?php echo e($totalColumnas); ?></td>
            <td><a class="table-td_hover" href="<?php echo e(route('coincidencias.show',  $noPoliza)); ?>">Ver detalles</a></td>
            <td class="d-none"><?php echo e($totalAciertos=0); ?>/<?php echo e($totalColumnas=0); ?></td>
          </tr>
          <tr>
            <td class="d-none">
              <div class="tab-content">
                 
                   <div class="tab-pane fade show active" id="tabA">
                     
                     <h3 class="main-inter_h3">Datos</h3>
                     <table class="table table-hover table-striped table-responsive table-bordered">
                       <thead>
                         <tr class="fixed-table">
                           
                           <th scope="col">Pagina</th>
                           <th scope="col">Plazo</th>
                           <th scope="col">Forma de Pago</th>
                           <th scope="col">Contributorio</th>
                           <th scope="col">inicio Vigencia</th>
                           <th scope="col">fin Vigencia</th>
                           <th scope="col">tipoDeAdministracion</th>
                           <th scope="col">Datos del contratante</th>
                           <th scope="col">Prima Neta</th>
                           <th scope="col">Recargos</th>
                           <th scope="col">Gastos expedición</th>
                           <th scope="col">IVA</th>
                           <th scope="col">Prima Total</th>
                           <th scope="col">Moneda</th>
                           <span class="d-none"><?php echo e($numColumnas2=13); ?></span>
                         </tr>
                       </thead>
                       <tbody>
                         <?php $__currentLoopData = $caratula_datos2; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $caratula_dato): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                         <tr>
                           
                           <td><?php echo e($caratula_dato->pagina); ?></td>
                           <td>
                             <?php if($caratula_dato->plazo == 1): ?>
                             <div class="checkdiv"><input disabled checked type="checkbox" class="le-checkbox"/></div>
                             <span class="d-none"><?php echo e($numAciertos2++); ?></span>
                             <?php elseif($caratula_dato->plazo == 0): ?>
                             <div class="checkdiv"><input disabled  type="checkbox" class="le-checkbox"/></div>
                             <?php else: ?>
                             <img src="<?php echo e(asset('img/unknown.png')); ?>" alt="" width="32">
                             <?php endif; ?>
                           </td>
                           <td>
                             <?php if($caratula_dato->formaDePago == 1): ?>
                             <span class="d-none"><?php echo e($numAciertos2++); ?></span>
                             <div class="checkdiv"><input disabled checked type="checkbox" class="le-checkbox"/></div>
                             <?php elseif($caratula_dato->formaDePago == 0): ?>
                             <div class="checkdiv"><input disabled  type="checkbox" class="le-checkbox"/></div>
                             <?php else: ?>
                             <img src="<?php echo e(asset('img/unknown.png')); ?>" alt="" width="32">
                             <?php endif; ?>
                           </td>
                           <td>
                             <?php if($caratula_dato->contributorio == 1): ?>
                             <span class="d-none"><?php echo e($numAciertos2++); ?></span>
                             <div class="checkdiv"><input disabled checked type="checkbox" class="le-checkbox"/></div>
                             <?php elseif($caratula_dato->contributorio == 0): ?>
                             <div class="checkdiv"><input disabled  type="checkbox" class="le-checkbox"/></div>
                             <?php else: ?>
                             <img src="<?php echo e(asset('img/unknown.png')); ?>" alt="" width="32">
                             <?php endif; ?>
                           </td>
                           <td>
                             <?php if($caratula_dato->inicioVigencia == 1): ?>
                             <span class="d-none"><?php echo e($numAciertos2++); ?></span>
                             <div class="checkdiv"><input disabled checked type="checkbox" class="le-checkbox"/></div>
                             <?php elseif($caratula_dato->inicioVigencia == 0): ?>
                             <div class="checkdiv"><input disabled  type="checkbox" class="le-checkbox"/></div>
                             <?php else: ?>
                             <img src="<?php echo e(asset('img/unknown.png')); ?>" alt="" width="32">
                             <?php endif; ?>
                           </td>
                           <td>
                             <?php if($caratula_dato->finVigencia == 1): ?>
                             <span class="d-none"><?php echo e($numAciertos2++); ?></span>
                             <div class="checkdiv"><input disabled checked type="checkbox" class="le-checkbox"/></div>
                             <?php elseif($caratula_dato->finVigencia == 0): ?>
                             <div class="checkdiv"><input disabled  type="checkbox" class="le-checkbox"/></div>
                             <?php else: ?>
                             <img src="<?php echo e(asset('img/unknown.png')); ?>" alt="" width="32">
                             <?php endif; ?>
                           </td>
                           <td>
                             <?php if($caratula_dato->tipoDeAdministracion == 1): ?>
                             <span class="d-none"><?php echo e($numAciertos2++); ?></span>
                             <div class="checkdiv"><input disabled checked type="checkbox" class="le-checkbox"/></div>
                             <?php elseif($caratula_dato->tipoDeAdministracion == 0): ?>
                             <div class="checkdiv"><input disabled  type="checkbox" class="le-checkbox"/></div>
                             <?php else: ?>
                             <img src="<?php echo e(asset('img/unknown.png')); ?>" alt="" width="32">
                             <?php endif; ?>
                           </td>
                           <td>
                             <?php if($caratula_dato->datosDelContratante == 1): ?>
                             <span class="d-none"><?php echo e($numAciertos2++); ?></span>
                             <div class="checkdiv"><input disabled checked type="checkbox" class="le-checkbox"/></div>
                             <?php elseif($caratula_dato->datosDelContratante == 0): ?>
                             <div class="checkdiv"><input disabled  type="checkbox" class="le-checkbox"/></div>
                             <?php else: ?>
                             <img src="<?php echo e(asset('img/unknown.png')); ?>" alt="" width="32">
                             <?php endif; ?>
                           </td>
                           <td>
                             <?php if($caratula_dato->primaNeta == 1): ?>
                             <span class="d-none"><?php echo e($numAciertos2++); ?></span>
                             <div class="checkdiv"><input disabled checked type="checkbox" class="le-checkbox"/></div>
                             <?php elseif($caratula_dato->primaNeta == 0): ?>
                             <div class="checkdiv"><input disabled  type="checkbox" class="le-checkbox"/></div>
                             <?php else: ?>
                             <img src="<?php echo e(asset('img/unknown.png')); ?>" alt="" width="32">
                             <?php endif; ?>
                           </td>
                           <td>
                             <?php if($caratula_dato->recargos == 1): ?>
                             <span class="d-none"><?php echo e($numAciertos2++); ?></span>
                             <div class="checkdiv"><input disabled checked type="checkbox" class="le-checkbox"/></div>
                             <?php elseif($caratula_dato->recargos == 0): ?>
                             <div class="checkdiv"><input disabled  type="checkbox" class="le-checkbox"/></div>
                             <?php else: ?>
                             <img src="<?php echo e(asset('img/unknown.png')); ?>" alt="" width="32">
                             <?php endif; ?>
                           </td>
                           <td>
                             <?php if($caratula_dato->gtosExpedicion == 1): ?>
                             <span class="d-none"><?php echo e($numAciertos2++); ?></span>
                             <div class="checkdiv"><input disabled checked type="checkbox" class="le-checkbox"/></div>
                             <?php elseif($caratula_dato->gtosExpedicion == 0): ?>
                             <div class="checkdiv"><input disabled  type="checkbox" class="le-checkbox"/></div>
                             <?php else: ?>
                             <img src="<?php echo e(asset('img/unknown.png')); ?>" alt="" width="32">
                             <?php endif; ?>
                           </td>
                           <td>
                             <?php if($caratula_dato->IVA == 1): ?>
                             <span class="d-none"><?php echo e($numAciertos2++); ?></span>
                             <div class="checkdiv"><input disabled checked type="checkbox" class="le-checkbox"/></div>
                             <?php elseif($caratula_dato->IVA == 0): ?>
                             <div class="checkdiv"><input disabled  type="checkbox" class="le-checkbox"/></div>
                             <?php else: ?>
                             <img src="<?php echo e(asset('img/unknown.png')); ?>" alt="" width="32">
                             <?php endif; ?>
                           </td>
                           <td>
                             <?php if($caratula_dato->primaTotal == 1): ?>
                             <span class="d-none"><?php echo e($numAciertos2++); ?></span>
                             <div class="checkdiv"><input disabled checked type="checkbox" class="le-checkbox"/></div>
                             <?php elseif($caratula_dato->primaTotal == 0): ?>
                             <div class="checkdiv"><input disabled  type="checkbox" class="le-checkbox"/></div>
                             <?php else: ?>
                             <img src="<?php echo e(asset('img/unknown.png')); ?>" alt="" width="32">
                             <?php endif; ?>
                           </td>
                           <td>
                             <?php if($caratula_dato->moneda == 1): ?>
                             <span class="d-none"><?php echo e($numAciertos2++); ?></span>
                             <div class="checkdiv"><input disabled checked type="checkbox" class="le-checkbox"/></div>
                             <?php elseif($caratula_dato->moneda == 0): ?>
                             <div class="checkdiv"><input disabled  type="checkbox" class="le-checkbox"/></div>
                             <?php else: ?>
                             <img src="<?php echo e(asset('img/unknown.png')); ?>" alt="" width="32">
                             <?php endif; ?>
                           </td>
                         </tr>
                         <span class="d-none"><?php echo e($contador2++); ?></span>
                         <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                         <div class="btn-success">Aciertos Datos= <?php echo e($numAciertos2); ?>/<?php echo e($numColumnas2*$contador2); ?></div>
                       </tbody>
                     </table>
                     
                     <span class="d-none"><?php echo e($guardarAciertos2=$numAciertos2, $guardarColumnas2=$numColumnas2*$contador2); ?></span>
                     <?php echo e($guardarAciertos2); ?>

                     <?php echo e($guardarColumnas2); ?>

                      <span class="d-none"><?php echo e($totalAciertos=$totalAciertos+$numAciertos2, $totalColumnas=$totalColumnas+($numColumnas2*$contador2)); ?></span>

                     
                     <h3 class="main-inter_h3">Coberturas</h3>
                     <span class="d-none"><?php echo e($numAciertos2=0, $numColumnas2=0, $contador2=0); ?></span>
                     <table class="table table-hover table-striped table-responsive table-bordered">
                       <thead>
                         <tr class="fixed-table">
                           
                           <th scope="col">Pagina</th>
                           <th scope="col">Cobertura</th>
                           <th scope="col">Suma Asegurada</th>
                           <th scope="col">Prima Neta</th>
                           <span class="d-none"><?php echo e($numColumnas2=2); ?></span>
                         </tr>
                       </thead>
                         
                       <tbody>
                         <?php $__currentLoopData = $caratula_coberturas2; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $caratula_cobertura): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                         <tr>
                           
                           <td><?php echo e($caratula_cobertura->pagina); ?></td>
                           <td>
                             <?php echo e($caratula_cobertura->cobertura); ?>

                           </td>
                           <td>
                             <?php if($caratula_cobertura->sumaAsegurada == 1): ?>
                             <div class="checkdiv"><input disabled checked type="checkbox" class="le-checkbox"/></div>
                             <span class="d-none"><?php echo e($numAciertos2++); ?></span>

                             <?php elseif($caratula_cobertura->sumaAsegurada == 0): ?>
                             <div class="checkdiv"><input disabled  type="checkbox" class="le-checkbox"/></div>
                             <?php else: ?>
                             <img src="<?php echo e(asset('img/unknown.png')); ?>" alt="" width="32">
                             <?php endif; ?>
                           </td>
                           <td>
                             <?php if($caratula_cobertura->primaNeta == 1): ?>
                             <span class="d-none"><?php echo e($numAciertos2++); ?></span>
                             <div class="checkdiv"><input disabled checked type="checkbox" class="le-checkbox"/></div>
                             <?php elseif($caratula_cobertura->primaNeta == 0): ?>
                             <div class="checkdiv"><input disabled  type="checkbox" class="le-checkbox"/></div>
                             <?php else: ?>
                             <img src="<?php echo e(asset('img/unknown.png')); ?>" alt="" width="32">
                             <?php endif; ?>
                           </td>
                         </tr>
                         <span class="d-none"><?php echo e($contador2++); ?></span>
                         <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                         <div class="btn-success">Aciertos Coberturas = <?php echo e($numAciertos2); ?>/<?php echo e($numColumnas2*$contador2); ?></div>
                       </tbody>
                     </table>
                     <span class="d-none"><?php echo e($guardarAciertos2=$guardarAciertos2+$numAciertos2, $guardarColumnas2=$guardarColumnas2+($numColumnas2*$contador2)); ?></span>

                     
                     <div class="btn-success position-absolute"><?php echo e($guardarAciertos2); ?>/<?php echo e($guardarColumnas2); ?></div>
                     <div class="btn-success position-absolute"><?php echo e($totalAciertos=$guardarAciertos2); ?>/<?php echo e($totalColumnas=$guardarColumnas2); ?></div>


                        
                   </div>

                 
                   <div class="tab-pane fade" id="tabB">
                     <form class="d-flex w-25" id="searchform" onkeyup="filterConsentimientos()">
                       <input class="form-control me-2" type="text" placeholder="Busca por # de certificado " id="searchConsentimientos">
                       
                     </form>
                     <span class="d-none"><?php echo e($numAciertos2=0, $contador2=0); ?></span>
                     <table class="table table-hover table-striped table-responsive table-bordered">
                       <thead>
                         <tr class="fixed-table">
                           
                           <th scope="col">Certificado</th>
                           <th scope="col">Nombre</th>
                           <th scope="col">Sexo</th>
                           <th scope="col">Edad</th>
                           <th scope="col">Fecha de Nacimiento</th>
                           <th scope="col">Datos del contratante</th>
                           <th scope="col">Plazo</th>
                           <th scope="col">Forma de Pago</th>
                           <th scope="col">Contributorio</th>
                           <th scope="col">Inicio Vigencia</th>
                           <th scope="col">Fin Vigencia</th>
                           <th scope="col">Moneda</th>
                           <span class="d-none"><?php echo e($numColumnas2=11); ?></span>
                         </tr>
                       </thead>
                       <tbody id="tbody-consentimientos_vida_datos2">
                         <?php $__currentLoopData = $consentimientos_vida_datos2; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $consentimientos_vida_dato): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                         <tr class="tr-consentimientos_vida_datos2">
                           <td class="tr-td-certificado-consentimientos_vida_datos2"><?php echo e($consentimientos_vida_dato->certificado); ?></td>
                           <td>
                             <?php if($consentimientos_vida_dato->nombre == 1): ?>
                             <span class="d-none"><?php echo e($numAciertos2++); ?></span>
                             <div class="checkdiv"><input disabled checked type="checkbox" class="le-checkbox"/></div>
                             <?php elseif($consentimientos_vida_dato->nombre == 0): ?>
                             <div class="checkdiv"><input disabled  type="checkbox" class="le-checkbox"/></div>
                             <?php else: ?>
                             <img src="<?php echo e(asset('img/unknown.png')); ?>" alt="" width="32">
                             <?php endif; ?>
                           </td>
                           <td>
                             <?php if($consentimientos_vida_dato->sexo == 1): ?>
                             <span class="d-none"><?php echo e($numAciertos2++); ?></span>
                             <div class="checkdiv"><input disabled checked type="checkbox" class="le-checkbox"/></div>
                             <?php elseif($consentimientos_vida_dato->nombre == 0): ?>
                             <div class="checkdiv"><input disabled  type="checkbox" class="le-checkbox"/></div>
                             <?php else: ?>
                             <img src="<?php echo e(asset('img/unknown.png')); ?>" alt="" width="32">
                             <?php endif; ?>
                           </td>
                           <td>
                             <?php if($consentimientos_vida_dato->edad == 1): ?>
                             <span class="d-none"><?php echo e($numAciertos2++); ?></span>
                             <div class="checkdiv"><input disabled checked type="checkbox" class="le-checkbox"/></div>
                             <?php elseif($consentimientos_vida_dato->edad == 0): ?>
                             <div class="checkdiv"><input disabled  type="checkbox" class="le-checkbox"/></div>
                             <?php else: ?>
                             <img src="<?php echo e(asset('img/unknown.png')); ?>" alt="" width="32">
                             <?php endif; ?>
                           </td>
                           <td>
                             <?php if($consentimientos_vida_dato->fechaDeNacimiento == 1): ?>
                             <span class="d-none"><?php echo e($numAciertos2++); ?></span>
                             <div class="checkdiv"><input disabled checked type="checkbox" class="le-checkbox"/></div>
                             <?php elseif($consentimientos_vida_dato->fechaDeNacimiento == 0): ?>
                             <div class="checkdiv"><input disabled  type="checkbox" class="le-checkbox"/></div>
                             <?php else: ?>
                             <img src="<?php echo e(asset('img/unknown.png')); ?>" alt="" width="32">
                             <?php endif; ?>
                           </td>
                           <td>
                             <?php if($consentimientos_vida_dato->datosDelContratante == 1): ?>
                             <span class="d-none"><?php echo e($numAciertos2++); ?></span>
                             <div class="checkdiv"><input disabled checked type="checkbox" class="le-checkbox"/></div>
                             <?php elseif($consentimientos_vida_dato->datosDelContratante == 0): ?>
                             <div class="checkdiv"><input disabled  type="checkbox" class="le-checkbox"/></div>
                             <?php else: ?>
                             <img src="<?php echo e(asset('img/unknown.png')); ?>" alt="" width="32">
                             <?php endif; ?>
                           </td>
                           <td>
                             <?php if($consentimientos_vida_dato->plazo == 1): ?>
                             <span class="d-none"><?php echo e($numAciertos2++); ?></span>
                             <div class="checkdiv"><input disabled checked type="checkbox" class="le-checkbox"/></div>
                             <?php elseif($consentimientos_vida_dato->plazo == 0): ?>
                             <div class="checkdiv"><input disabled  type="checkbox" class="le-checkbox"/></div>
                             <?php else: ?>
                             <img src="<?php echo e(asset('img/unknown.png')); ?>" alt="" width="32">
                             <?php endif; ?>
                           </td>
                           <td>
                             <?php if($consentimientos_vida_dato->formaDePago == 1): ?>
                             <span class="d-none"><?php echo e($numAciertos2++); ?></span>
                             <div class="checkdiv"><input disabled checked type="checkbox" class="le-checkbox"/></div>
                             <?php elseif($consentimientos_vida_dato->formaDePago == 0): ?>
                             <div class="checkdiv"><input disabled  type="checkbox" class="le-checkbox"/></div>
                             <?php else: ?>
                             <img src="<?php echo e(asset('img/unknown.png')); ?>" alt="" width="32">
                             <?php endif; ?>
                           </td>
                           <td>
                             <?php if($consentimientos_vida_dato->contributorio == 1): ?>
                             <span class="d-none"><?php echo e($numAciertos2++); ?></span>
                             <div class="checkdiv"><input disabled checked type="checkbox" class="le-checkbox"/></div>
                             <?php elseif($consentimientos_vida_dato->contributorio == 0): ?>
                             <div class="checkdiv"><input disabled  type="checkbox" class="le-checkbox"/></div>
                             <?php else: ?>
                             <img src="<?php echo e(asset('img/unknown.png')); ?>" alt="" width="32">
                             <?php endif; ?>
                           </td>
                           <td>
                             <?php if($consentimientos_vida_dato->inicioVigencia == 1): ?>
                             <span class="d-none"><?php echo e($numAciertos2++); ?></span>
                             <div class="checkdiv"><input disabled checked type="checkbox" class="le-checkbox"/></div>
                             <?php elseif($consentimientos_vida_dato->inicioVigencia == 0): ?>
                             <div class="checkdiv"><input disabled  type="checkbox" class="le-checkbox"/></div>
                             <?php else: ?>
                             <img src="<?php echo e(asset('img/unknown.png')); ?>" alt="" width="32">
                             <?php endif; ?>
                           </td>
                           <td>
                             <?php if($consentimientos_vida_dato->finVigencia == 1): ?>
                             <span class="d-none"><?php echo e($numAciertos2++); ?></span>
                             <div class="checkdiv"><input disabled checked type="checkbox" class="le-checkbox"/></div>
                             <?php elseif($consentimientos_vida_dato->finVigencia == 0): ?>
                             <div class="checkdiv"><input disabled  type="checkbox" class="le-checkbox"/></div>
                             <?php else: ?>
                             <img src="<?php echo e(asset('img/unknown.png')); ?>" alt="" width="32">
                             <?php endif; ?>
                           </td>
                           <td>
                             <?php if($consentimientos_vida_dato->moneda == 1): ?>
                             <span class="d-none"><?php echo e($numAciertos2++); ?></span>
                             <div class="checkdiv"><input disabled checked type="checkbox" class="le-checkbox"/></div>
                             <?php elseif($consentimientos_vida_dato->moneda == 0): ?>
                             <div class="checkdiv"><input disabled  type="checkbox" class="le-checkbox"/></div>
                             <?php else: ?>
                             <img src="<?php echo e(asset('img/unknown.png')); ?>" alt="" width="32">
                             <?php endif; ?>
                           </td>
                           <span class="d-none"><?php echo e($contador2++); ?></span>
                         </tr>
                           
                         <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                         <div class="btn-success">Aciertos Coberturas = <?php echo e($numAciertos2); ?>/<?php echo e($numColumnas2*$contador2); ?></div>
                         <span class="d-none"><?php echo e($totalAciertos=$totalAciertos+$numAciertos2, $totalColumnas=$totalColumnas+($numColumnas2*$contador2)); ?></span>
                       </tbody>
                     </table>
                   </div>
                 
                   <div class="tab-pane fade" id="tabC">
                     
                     <h3 class="main-inter_h3">Datos</h3>
                     <span class="d-none"><?php echo e($numAciertos2=0, $contador2=0); ?></span>
                     <table class="table table-hover table-striped table-responsive table-bordered">
                       <thead>
                         <tr class="fixed-table">
                           
                           <th scope="col">Pagina</th>
                           <th scope="col">Plazo</th>
                           <th scope="col">Forma de Pago</th>
                           <th scope="col">Contributorio</th>
                           <th scope="col">inicio Vigencia</th>
                           <th scope="col">fin Vigencia</th>
                           <th scope="col">asegurados</th>
                           <th scope="col">Datos del contratante</th>
                           <th scope="col">Prima Neta</th>
                           <th scope="col">Recargos</th>
                           <th scope="col">Gastos expedición</th>
                           <th scope="col">IVA</th>
                           <th scope="col">Prima Total</th>
                           <th scope="col">Moneda</th>
                           <span class="d-none"><?php echo e($numColumnas2=13); ?></span>
                         </tr>
                       </thead>
                       <tbody>
                         <?php $__currentLoopData = $detalle_cobertura_datos2; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $detalle_cobertura_dato): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                         <tr>
                           
                           <td><?php echo e($detalle_cobertura_dato->pagina); ?></td>
                           <td>
                             <?php if($detalle_cobertura_dato->plazo == 1): ?>
                             <div class="checkdiv"><input disabled checked type="checkbox" class="le-checkbox"/></div>
                             <span class="d-none"><?php echo e($numAciertos2++); ?></span>
                             <?php elseif($detalle_cobertura_dato->plazo == 0): ?>
                             <div class="checkdiv"><input disabled  type="checkbox" class="le-checkbox"/></div>
                             <?php else: ?>
                             <img src="<?php echo e(asset('img/unknown.png')); ?>" alt="" width="32">
                             <?php endif; ?>
                           </td>
                           <td>
                             <?php if($detalle_cobertura_dato->formaDePago == 1): ?>
                             <span class="d-none"><?php echo e($numAciertos2++); ?></span>
                             <div class="checkdiv"><input disabled checked type="checkbox" class="le-checkbox"/></div>
                             <?php elseif($detalle_cobertura_dato->formaDePago == 0): ?>
                             <div class="checkdiv"><input disabled  type="checkbox" class="le-checkbox"/></div>
                             <?php else: ?>
                             <img src="<?php echo e(asset('img/unknown.png')); ?>" alt="" width="32">
                             <?php endif; ?>
                           </td>
                           <td>
                             <?php if($detalle_cobertura_dato->contributorio == 1): ?>
                             <span class="d-none"><?php echo e($numAciertos2++); ?></span>
                             <div class="checkdiv"><input disabled checked type="checkbox" class="le-checkbox"/></div>
                             <?php elseif($detalle_cobertura_dato->contributorio == 0): ?>
                             <div class="checkdiv"><input disabled  type="checkbox" class="le-checkbox"/></div>
                             <?php else: ?>
                             <img src="<?php echo e(asset('img/unknown.png')); ?>" alt="" width="32">
                             <?php endif; ?>
                           </td>
                           <td>
                             <?php if($detalle_cobertura_dato->inicioVigencia == 1): ?>
                             <span class="d-none"><?php echo e($numAciertos2++); ?></span>
                             <div class="checkdiv"><input disabled checked type="checkbox" class="le-checkbox"/></div>
                             <?php elseif($detalle_cobertura_dato->inicioVigencia == 0): ?>
                             <div class="checkdiv"><input disabled  type="checkbox" class="le-checkbox"/></div>
                             <?php else: ?>
                             <img src="<?php echo e(asset('img/unknown.png')); ?>" alt="" width="32">
                             <?php endif; ?>
                           </td>
                           <td>
                             <?php if($detalle_cobertura_dato->finVigencia == 1): ?>
                             <span class="d-none"><?php echo e($numAciertos2++); ?></span>
                             <div class="checkdiv"><input disabled checked type="checkbox" class="le-checkbox"/></div>
                             <?php elseif($detalle_cobertura_dato->finVigencia == 0): ?>
                             <div class="checkdiv"><input disabled  type="checkbox" class="le-checkbox"/></div>
                             <?php else: ?>
                             <img src="<?php echo e(asset('img/unknown.png')); ?>" alt="" width="32">
                             <?php endif; ?>
                           </td>
                           <td>
                             <?php if($detalle_cobertura_dato->asegurados == 1): ?>
                             <span class="d-none"><?php echo e($numAciertos2++); ?></span>
                             <div class="checkdiv"><input disabled checked type="checkbox" class="le-checkbox"/></div>
                             <?php elseif($detalle_cobertura_dato->asegurados == 0): ?>
                             <div class="checkdiv"><input disabled  type="checkbox" class="le-checkbox"/></div>
                             <?php else: ?>
                             <img src="<?php echo e(asset('img/unknown.png')); ?>" alt="" width="32">
                             <?php endif; ?>
                           </td>
                           <td>
                             <?php if($detalle_cobertura_dato->datosDelContratante == 1): ?>
                             <span class="d-none"><?php echo e($numAciertos2++); ?></span>
                             <div class="checkdiv"><input disabled checked type="checkbox" class="le-checkbox"/></div>
                             <?php elseif($detalle_cobertura_dato->datosDelContratante == 0): ?>
                             <div class="checkdiv"><input disabled  type="checkbox" class="le-checkbox"/></div>
                             <?php else: ?>
                             <img src="<?php echo e(asset('img/unknown.png')); ?>" alt="" width="32">
                             <?php endif; ?>
                           </td>
                           <td>
                             <?php if($detalle_cobertura_dato->primaNeta == 1): ?>
                             <span class="d-none"><?php echo e($numAciertos2++); ?></span>
                             <div class="checkdiv"><input disabled checked type="checkbox" class="le-checkbox"/></div>
                             <?php elseif($detalle_cobertura_dato->primaNeta == 0): ?>
                             <div class="checkdiv"><input disabled  type="checkbox" class="le-checkbox"/></div>
                             <?php else: ?>
                             <img src="<?php echo e(asset('img/unknown.png')); ?>" alt="" width="32">
                             <?php endif; ?>
                           </td>
                           <td>
                             <?php if($detalle_cobertura_dato->recargos == 1): ?>
                             <span class="d-none"><?php echo e($numAciertos2++); ?></span>
                             <div class="checkdiv"><input disabled checked type="checkbox" class="le-checkbox"/></div>
                             <?php elseif($detalle_cobertura_dato->recargos == 0): ?>
                             <div class="checkdiv"><input disabled  type="checkbox" class="le-checkbox"/></div>
                             <?php else: ?>
                             <img src="<?php echo e(asset('img/unknown.png')); ?>" alt="" width="32">
                             <?php endif; ?>
                           </td>
                           <td>
                             <?php if($detalle_cobertura_dato->gtosExpedicion == 1): ?>
                             <span class="d-none"><?php echo e($numAciertos2++); ?></span>
                             <div class="checkdiv"><input disabled checked type="checkbox" class="le-checkbox"/></div>
                             <?php elseif($detalle_cobertura_dato->gtosExpedicion == 0): ?>
                             <div class="checkdiv"><input disabled  type="checkbox" class="le-checkbox"/></div>
                             <?php else: ?>
                             <img src="<?php echo e(asset('img/unknown.png')); ?>" alt="" width="32">
                             <?php endif; ?>
                           </td>
                           <td>
                             <?php if($detalle_cobertura_dato->IVA == 1): ?>
                             <span class="d-none"><?php echo e($numAciertos2++); ?></span>
                             <div class="checkdiv"><input disabled checked type="checkbox" class="le-checkbox"/></div>
                             <?php elseif($detalle_cobertura_dato->IVA == 0): ?>
                             <div class="checkdiv"><input disabled  type="checkbox" class="le-checkbox"/></div>
                             <?php else: ?>
                             <img src="<?php echo e(asset('img/unknown.png')); ?>" alt="" width="32">
                             <?php endif; ?>
                           </td>
                           <td>
                             <?php if($detalle_cobertura_dato->primaTotal == 1): ?>
                             <span class="d-none"><?php echo e($numAciertos2++); ?></span>
                             <div class="checkdiv"><input disabled checked type="checkbox" class="le-checkbox"/></div>
                             <?php elseif($detalle_cobertura_dato->primaTotal == 0): ?>
                             <div class="checkdiv"><input disabled  type="checkbox" class="le-checkbox"/></div>
                             <?php else: ?>
                             <img src="<?php echo e(asset('img/unknown.png')); ?>" alt="" width="32">
                             <?php endif; ?>
                           </td>
                           <td>
                             <?php if($detalle_cobertura_dato->moneda == 1): ?>
                             <span class="d-none"><?php echo e($numAciertos2++); ?></span>
                             <div class="checkdiv"><input disabled checked type="checkbox" class="le-checkbox"/></div>
                             <?php elseif($detalle_cobertura_dato->moneda == 0): ?>
                             <div class="checkdiv"><input disabled  type="checkbox" class="le-checkbox"/></div>
                             <?php else: ?>
                             <img src="<?php echo e(asset('img/unknown.png')); ?>" alt="" width="32">
                             <?php endif; ?>
                           </td>
                         </tr>
                         <span class="d-none"><?php echo e($contador2++); ?></span>
                         <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                         <div class="btn-success">Aciertos Datos= <?php echo e($numAciertos2); ?>/<?php echo e($numColumnas2*$contador2); ?></div>
                       </tbody>
                     </table>
                     
                     <span class="d-none"><?php echo e($guardarAciertos2=$numAciertos2, $guardarColumnas2=$numColumnas2*$contador2); ?></span>
                     <span class="d-none"><?php echo e($totalAciertos=$totalAciertos+$numAciertos2, $totalColumnas=$totalColumnas+($numColumnas2*$contador2)); ?></span>

                     <?php echo e($guardarAciertos2); ?>

                     <?php echo e($guardarColumnas2); ?>

                     
                     <h3 class="main-inter_h3">Coberturas</h3>
                     <span class="d-none"><?php echo e($numAciertos2=0, $numColumnas2=0, $contador2=0); ?></span>
                     <table class="table table-hover table-striped table-responsive table-bordered">
                       <thead>
                         <tr class="fixed-table">
                           <th scope="col">Pagina</th>
                           <th scope="col">Cobertura</th>
                           <th scope="col">Prima Neta</th>
                           <span class="d-none"><?php echo e($numColumnas2=1); ?></span>
                         </tr>
                       </thead>
                       <tbody>
                         <?php $__currentLoopData = $detalle_cobertura_coberturas2; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $detalle_cobertura_cobertura): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                         <tr>
                           
                           <td><?php echo e($detalle_cobertura_cobertura->pagina); ?></td>
                           <td>
                             <?php echo e($detalle_cobertura_cobertura->cobertura); ?>

                           </td>
                           <td>
                             <?php if($detalle_cobertura_cobertura->primaNeta == 1): ?>
                             <span class="d-none"><?php echo e($numAciertos2++); ?></span>
                             <div class="checkdiv"><input disabled checked type="checkbox" class="le-checkbox"/></div>
                             <?php elseif($detalle_cobertura_cobertura->primaNeta == 0): ?>
                             <div class="checkdiv"><input disabled  type="checkbox" class="le-checkbox"/></div>
                             <?php else: ?>
                             <img src="<?php echo e(asset('img/unknown.png')); ?>" alt="" width="32">
                             <?php endif; ?>
                           </td>
                         </tr>
                         <span class="d-none"><?php echo e($contador2++); ?></span>
                         <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                         <div class="btn-success">Aciertos Coberturas = <?php echo e($numAciertos2); ?>/<?php echo e($numColumnas2*$contador2); ?></div>
                       </tbody>
                     </table>
                     <span class="d-none"><?php echo e($guardarAciertos2=$guardarAciertos2+$numAciertos2, $guardarColumnas2=$guardarColumnas2+($numColumnas2*$contador2)); ?></span>
                     <span class="d-none"><?php echo e($totalAciertos=$totalAciertos+$numAciertos2, $totalColumnas=$totalColumnas+($numColumnas2*$contador2)); ?></span>
                     
                     <div class="btn-success position-absolute"><?php echo e($guardarAciertos2); ?>/<?php echo e($guardarColumnas2); ?></div>

                   </div>
                 
                   <div class="tab-pane fade" id="tabD">
                     <span class="d-none"><?php echo e($numAciertos2=0, $contador2=0); ?></span>
                     <table class="table table-hover table-striped table-responsive">
                       <thead>
                         <tr class="fixed-table">
                           
                           <th scope="col">Subgrupo</th>
                           <th scope="col">Categoría</th>
                           <th scope="col">Endoso</th>
                           <th scope="col">Valor</th>
                           <span class="d-none"><?php echo e($numColumnas2=1); ?></span>
                         </tr>
                       </thead>
                       <tbody>
                         <?php $__currentLoopData = $endosos2; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $endoso): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                         <tr>
                           
                           <td><?php echo e($endoso->subgrupo); ?></td>
                           <td><?php echo e($endoso->categoria); ?></td>
                           <td><?php echo e($endoso->endoso); ?></td>
                           <td>
                             <?php if($endoso->valorEndoso == 1): ?>
                             <div class="checkdiv"><input disabled checked type="checkbox" class="le-checkbox"/></div>
                             <span class="d-none"><?php echo e($numAciertos2++); ?></span>
                             <?php elseif($endoso->valorEndoso == 0): ?>
                             <div class="checkdiv"><input disabled  type="checkbox" class="le-checkbox"/></div>
                             <?php else: ?>
                             <img src="<?php echo e(asset('img/unknown.png')); ?>" alt="" width="32">
                             <?php endif; ?>
                           </td>
                           <span class="d-none"><?php echo e($contador2++); ?></span>
                         </tr>
                         <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                         <div class="btn-success">Aciertos Coberturas = <?php echo e($numAciertos2); ?>/<?php echo e($numColumnas2*$contador2); ?></div>
                         <span class="d-none"><?php echo e($totalAciertos=$totalAciertos+$numAciertos2, $totalColumnas=$totalColumnas+($numColumnas2*$contador2)); ?></span>
                       </tbody>
                     </table>
                   </div>
                 
                   <div class="tab-pane fade" id="tabE">
                     <form class="d-flex w-25" id="searchform" onkeyup="filterListado()">
                       <input class="form-control me-2" type="text" placeholder="Busca por # de certificado " id="searchListado">
                       
                     </form>
                     <span class="d-none"><?php echo e($numAciertos2=0, $contador2=0); ?></span>

                     <table class="table table-hover table-striped table-responsive table-bordered">
                       <thead>
                         <tr class="fixed-table">
                           
                           <th scope="col">Certificado</th>
                           <th scope="col">Subgrupo</th>
                           <th scope="col">Categoría</th>
                           <th scope="col">Nombre</th>
                           <th scope="col">Antiguedad</th>
                           <th scope="col">Edad</th>
                           <th scope="col">Sexo</th>
                           <th scope="col">FechaAltaBaja</th>
                           <span class="d-none"><?php echo e($numColumnas2=6); ?></span>
                         </tr>
                       </thead>
                       <tbody id="tbody-listado_asegurados2">
                         <?php $__currentLoopData = $listado_asegurados2; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $listado_asegurado): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                         <tr>
                           
                           <td class="tr-td-certificado-listado_asegurados2"><?php echo e($listado_asegurado->certificado); ?></td>
                           <td><?php echo e($listado_asegurado->subgrupo); ?></td>
                           <td>
                             <?php if($listado_asegurado->categoria == 1): ?>
                             <span class="d-none"><?php echo e($numAciertos2++); ?></span>
                             <div class="checkdiv"><input disabled checked type="checkbox" class="le-checkbox"/></div>
                             <?php elseif($listado_asegurado->categoria == 0): ?>
                             <div class="checkdiv"><input disabled  type="checkbox" class="le-checkbox"/></div>
                             <?php else: ?>
                             <img src="<?php echo e(asset('img/unknown.png')); ?>" alt="" width="32">
                             <?php endif; ?>
                           </td>
                           <td>
                             <?php if($listado_asegurado->nombre == 1): ?>
                             <span class="d-none"><?php echo e($numAciertos2++); ?></span>
                             <div class="checkdiv"><input disabled checked type="checkbox" class="le-checkbox"/></div>
                             <?php elseif($listado_asegurado->nombre == 0): ?>
                             <div class="checkdiv"><input disabled  type="checkbox" class="le-checkbox"/></div>
                             <?php else: ?>
                             <img src="<?php echo e(asset('img/unknown.png')); ?>" alt="" width="32">
                             <?php endif; ?>
                           </td>
                           <td>
                             <?php if($listado_asegurado->antiguedad == 1): ?>
                             <span class="d-none"><?php echo e($numAciertos2++); ?></span>
                             <div class="checkdiv"><input disabled checked type="checkbox" class="le-checkbox"/></div>
                             <?php elseif($listado_asegurado->antiguedad == 0): ?>
                             <div class="checkdiv"><input disabled  type="checkbox" class="le-checkbox"/></div>
                             <?php else: ?>
                             <img src="<?php echo e(asset('img/unknown.png')); ?>" alt="" width="32">
                             <?php endif; ?>
                           </td>
                           <td>
                             <?php if($listado_asegurado->edad == 1): ?>
                             <span class="d-none"><?php echo e($numAciertos2++); ?></span>
                             <div class="checkdiv"><input disabled checked type="checkbox" class="le-checkbox"/></div>
                             <?php elseif($listado_asegurado->edad == 0): ?>
                             <div class="checkdiv"><input disabled  type="checkbox" class="le-checkbox"/></div>
                             <?php else: ?>
                             <img src="<?php echo e(asset('img/unknown.png')); ?>" alt="" width="32">
                             <?php endif; ?>
                           </td>
                           <td>
                             <?php if($listado_asegurado->sexo == 1): ?>
                             <span class="d-none"><?php echo e($numAciertos2++); ?></span>
                             <div class="checkdiv"><input disabled checked type="checkbox" class="le-checkbox"/></div>
                             <?php elseif($listado_asegurado->sexo == 0): ?>
                             <div class="checkdiv"><input disabled  type="checkbox" class="le-checkbox"/></div>
                             <?php else: ?>
                             <img src="<?php echo e(asset('img/unknown.png')); ?>" alt="" width="32">
                             <?php endif; ?>
                           </td>
                           <td>
                             <?php if($listado_asegurado->fechaAltaBaja == 1): ?>
                             <span class="d-none"><?php echo e($numAciertos2++); ?></span>
                             <div class="checkdiv"><input disabled checked type="checkbox" class="le-checkbox"/></div>
                             <?php elseif($listado_asegurado->fechaAltaBaja == 0): ?>
                             <div class="checkdiv"><input disabled  type="checkbox" class="le-checkbox"/></div>
                             <?php else: ?>
                             <img src="<?php echo e(asset('img/unknown.png')); ?>" alt="" width="32">
                             <?php endif; ?>
                           </td>
                           <span class="d-none"><?php echo e($contador2++); ?></span>
                         </tr>
                         <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                         <div class="btn-success">Aciertos Coberturas = <?php echo e($numAciertos2); ?>/<?php echo e($numColumnas2*$contador2); ?></div>
                         <span class="d-none"><?php echo e($totalAciertos=$totalAciertos+$numAciertos2, $totalColumnas=$totalColumnas+($numColumnas2*$contador2)); ?></span>

                       </tbody>
                     </table>
                   </div>
              </div>
            </td>
            <th scope="row"><?php echo e($noPoliza2); ?></th>
            <td><?php echo e($totalAciertos); ?>/<?php echo e($totalColumnas); ?></td>
            <td><a class="table-td_hover" href="<?php echo e(route('coincidencias.show', $noPoliza2)); ?>">Ver detalles</a></td>
            <td class="d-none"><?php echo e($totalAciertos=0); ?>/<?php echo e($totalColumnas=0); ?></td>
          </tr>
          <tr>
            <td class="d-none">
              <div class="tab-content">
                 
                   <div class="tab-pane fade show active" id="tabA">
                     
                     <h3 class="main-inter_h3">Datos</h3>
                     <table class="table table-hover table-striped table-responsive table-bordered">
                       <thead>
                         <tr class="fixed-table">
                           
                           <th scope="col">Pagina</th>
                           <th scope="col">Plazo</th>
                           <th scope="col">Forma de Pago</th>
                           <th scope="col">Contributorio</th>
                           <th scope="col">inicio Vigencia</th>
                           <th scope="col">fin Vigencia</th>
                           <th scope="col">tipoDeAdministracion</th>
                           <th scope="col">Datos del contratante</th>
                           <th scope="col">Prima Neta</th>
                           <th scope="col">Recargos</th>
                           <th scope="col">Gastos expedición</th>
                           <th scope="col">IVA</th>
                           <th scope="col">Prima Total</th>
                           <th scope="col">Moneda</th>
                           <span class="d-none"><?php echo e($numColumnas3=13); ?></span>
                         </tr>
                       </thead>
                       <tbody>
                         <?php $__currentLoopData = $caratula_datos3; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $caratula_dato): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                         <tr>
                           
                           <td><?php echo e($caratula_dato->pagina); ?></td>
                           <td>
                             <?php if($caratula_dato->plazo == 1): ?>
                             <div class="checkdiv"><input disabled checked type="checkbox" class="le-checkbox"/></div>
                             <span class="d-none"><?php echo e($numAciertos3++); ?></span>
                             <?php elseif($caratula_dato->plazo == 0): ?>
                             <div class="checkdiv"><input disabled  type="checkbox" class="le-checkbox"/></div>
                             <?php else: ?>
                             <img src="<?php echo e(asset('img/unknown.png')); ?>" alt="" width="32">
                             <?php endif; ?>
                           </td>
                           <td>
                             <?php if($caratula_dato->formaDePago == 1): ?>
                             <span class="d-none"><?php echo e($numAciertos3++); ?></span>
                             <div class="checkdiv"><input disabled checked type="checkbox" class="le-checkbox"/></div>
                             <?php elseif($caratula_dato->formaDePago == 0): ?>
                             <div class="checkdiv"><input disabled  type="checkbox" class="le-checkbox"/></div>
                             <?php else: ?>
                             <img src="<?php echo e(asset('img/unknown.png')); ?>" alt="" width="32">
                             <?php endif; ?>
                           </td>
                           <td>
                             <?php if($caratula_dato->contributorio == 1): ?>
                             <span class="d-none"><?php echo e($numAciertos3++); ?></span>
                             <div class="checkdiv"><input disabled checked type="checkbox" class="le-checkbox"/></div>
                             <?php elseif($caratula_dato->contributorio == 0): ?>
                             <div class="checkdiv"><input disabled  type="checkbox" class="le-checkbox"/></div>
                             <?php else: ?>
                             <img src="<?php echo e(asset('img/unknown.png')); ?>" alt="" width="32">
                             <?php endif; ?>
                           </td>
                           <td>
                             <?php if($caratula_dato->inicioVigencia == 1): ?>
                             <span class="d-none"><?php echo e($numAciertos3++); ?></span>
                             <div class="checkdiv"><input disabled checked type="checkbox" class="le-checkbox"/></div>
                             <?php elseif($caratula_dato->inicioVigencia == 0): ?>
                             <div class="checkdiv"><input disabled  type="checkbox" class="le-checkbox"/></div>
                             <?php else: ?>
                             <img src="<?php echo e(asset('img/unknown.png')); ?>" alt="" width="32">
                             <?php endif; ?>
                           </td>
                           <td>
                             <?php if($caratula_dato->finVigencia == 1): ?>
                             <span class="d-none"><?php echo e($numAciertos3++); ?></span>
                             <div class="checkdiv"><input disabled checked type="checkbox" class="le-checkbox"/></div>
                             <?php elseif($caratula_dato->finVigencia == 0): ?>
                             <div class="checkdiv"><input disabled  type="checkbox" class="le-checkbox"/></div>
                             <?php else: ?>
                             <img src="<?php echo e(asset('img/unknown.png')); ?>" alt="" width="32">
                             <?php endif; ?>
                           </td>
                           <td>
                             <?php if($caratula_dato->tipoDeAdministracion == 1): ?>
                             <span class="d-none"><?php echo e($numAciertos3++); ?></span>
                             <div class="checkdiv"><input disabled checked type="checkbox" class="le-checkbox"/></div>
                             <?php elseif($caratula_dato->tipoDeAdministracion == 0): ?>
                             <div class="checkdiv"><input disabled  type="checkbox" class="le-checkbox"/></div>
                             <?php else: ?>
                             <img src="<?php echo e(asset('img/unknown.png')); ?>" alt="" width="32">
                             <?php endif; ?>
                           </td>
                           <td>
                             <?php if($caratula_dato->datosDelContratante == 1): ?>
                             <span class="d-none"><?php echo e($numAciertos3++); ?></span>
                             <div class="checkdiv"><input disabled checked type="checkbox" class="le-checkbox"/></div>
                             <?php elseif($caratula_dato->datosDelContratante == 0): ?>
                             <div class="checkdiv"><input disabled  type="checkbox" class="le-checkbox"/></div>
                             <?php else: ?>
                             <img src="<?php echo e(asset('img/unknown.png')); ?>" alt="" width="32">
                             <?php endif; ?>
                           </td>
                           <td>
                             <?php if($caratula_dato->primaNeta == 1): ?>
                             <span class="d-none"><?php echo e($numAciertos3++); ?></span>
                             <div class="checkdiv"><input disabled checked type="checkbox" class="le-checkbox"/></div>
                             <?php elseif($caratula_dato->primaNeta == 0): ?>
                             <div class="checkdiv"><input disabled  type="checkbox" class="le-checkbox"/></div>
                             <?php else: ?>
                             <img src="<?php echo e(asset('img/unknown.png')); ?>" alt="" width="32">
                             <?php endif; ?>
                           </td>
                           <td>
                             <?php if($caratula_dato->recargos == 1): ?>
                             <span class="d-none"><?php echo e($numAciertos3++); ?></span>
                             <div class="checkdiv"><input disabled checked type="checkbox" class="le-checkbox"/></div>
                             <?php elseif($caratula_dato->recargos == 0): ?>
                             <div class="checkdiv"><input disabled  type="checkbox" class="le-checkbox"/></div>
                             <?php else: ?>
                             <img src="<?php echo e(asset('img/unknown.png')); ?>" alt="" width="32">
                             <?php endif; ?>
                           </td>
                           <td>
                             <?php if($caratula_dato->gtosExpedicion == 1): ?>
                             <span class="d-none"><?php echo e($numAciertos3++); ?></span>
                             <div class="checkdiv"><input disabled checked type="checkbox" class="le-checkbox"/></div>
                             <?php elseif($caratula_dato->gtosExpedicion == 0): ?>
                             <div class="checkdiv"><input disabled  type="checkbox" class="le-checkbox"/></div>
                             <?php else: ?>
                             <img src="<?php echo e(asset('img/unknown.png')); ?>" alt="" width="32">
                             <?php endif; ?>
                           </td>
                           <td>
                             <?php if($caratula_dato->IVA == 1): ?>
                             <span class="d-none"><?php echo e($numAciertos3++); ?></span>
                             <div class="checkdiv"><input disabled checked type="checkbox" class="le-checkbox"/></div>
                             <?php elseif($caratula_dato->IVA == 0): ?>
                             <div class="checkdiv"><input disabled  type="checkbox" class="le-checkbox"/></div>
                             <?php else: ?>
                             <img src="<?php echo e(asset('img/unknown.png')); ?>" alt="" width="32">
                             <?php endif; ?>
                           </td>
                           <td>
                             <?php if($caratula_dato->primaTotal == 1): ?>
                             <span class="d-none"><?php echo e($numAciertos3++); ?></span>
                             <div class="checkdiv"><input disabled checked type="checkbox" class="le-checkbox"/></div>
                             <?php elseif($caratula_dato->primaTotal == 0): ?>
                             <div class="checkdiv"><input disabled  type="checkbox" class="le-checkbox"/></div>
                             <?php else: ?>
                             <img src="<?php echo e(asset('img/unknown.png')); ?>" alt="" width="32">
                             <?php endif; ?>
                           </td>
                           <td>
                             <?php if($caratula_dato->moneda == 1): ?>
                             <span class="d-none"><?php echo e($numAciertos3++); ?></span>
                             <div class="checkdiv"><input disabled checked type="checkbox" class="le-checkbox"/></div>
                             <?php elseif($caratula_dato->moneda == 0): ?>
                             <div class="checkdiv"><input disabled  type="checkbox" class="le-checkbox"/></div>
                             <?php else: ?>
                             <img src="<?php echo e(asset('img/unknown.png')); ?>" alt="" width="32">
                             <?php endif; ?>
                           </td>
                         </tr>
                         <span class="d-none"><?php echo e($contador3++); ?></span>
                         <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                         <div class="btn-success">Aciertos Datos= <?php echo e($numAciertos3); ?>/<?php echo e($numColumnas3*$contador3); ?></div>
                       </tbody>
                     </table>
                     
                     <span class="d-none"><?php echo e($guardarAciertos3=$numAciertos3, $guardarColumnas3=$numColumnas3*$contador3); ?></span>
                     <?php echo e($guardarAciertos3); ?>

                     <?php echo e($guardarColumnas3); ?>

                      <span class="d-none"><?php echo e($totalAciertos=$totalAciertos+$numAciertos3, $totalColumnas=$totalColumnas+($numColumnas3*$contador3)); ?></span>

                     
                     <h3 class="main-inter_h3">Coberturas</h3>
                     <span class="d-none"><?php echo e($numAciertos3=0, $numColumnas3=0, $contador3=0); ?></span>
                     <table class="table table-hover table-striped table-responsive table-bordered">
                       <thead>
                         <tr class="fixed-table">
                           
                           <th scope="col">Pagina</th>
                           <th scope="col">Cobertura</th>
                           <th scope="col">Suma Asegurada</th>
                           <th scope="col">Prima Neta</th>
                           <span class="d-none"><?php echo e($numColumnas3=2); ?></span>
                         </tr>
                       </thead>
                         
                       <tbody>
                         <?php $__currentLoopData = $caratula_coberturas3; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $caratula_cobertura): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                         <tr>
                           
                           <td><?php echo e($caratula_cobertura->pagina); ?></td>
                           <td>
                             <?php echo e($caratula_cobertura->cobertura); ?>

                           </td>
                           <td>
                             <?php if($caratula_cobertura->sumaAsegurada == 1): ?>
                             <div class="checkdiv"><input disabled checked type="checkbox" class="le-checkbox"/></div>
                             <span class="d-none"><?php echo e($numAciertos3++); ?></span>

                             <?php elseif($caratula_cobertura->sumaAsegurada == 0): ?>
                             <div class="checkdiv"><input disabled  type="checkbox" class="le-checkbox"/></div>
                             <?php else: ?>
                             <img src="<?php echo e(asset('img/unknown.png')); ?>" alt="" width="32">
                             <?php endif; ?>
                           </td>
                           <td>
                             <?php if($caratula_cobertura->primaNeta == 1): ?>
                             <span class="d-none"><?php echo e($numAciertos3++); ?></span>
                             <div class="checkdiv"><input disabled checked type="checkbox" class="le-checkbox"/></div>
                             <?php elseif($caratula_cobertura->primaNeta == 0): ?>
                             <div class="checkdiv"><input disabled  type="checkbox" class="le-checkbox"/></div>
                             <?php else: ?>
                             <img src="<?php echo e(asset('img/unknown.png')); ?>" alt="" width="32">
                             <?php endif; ?>
                           </td>
                         </tr>
                         <span class="d-none"><?php echo e($contador3++); ?></span>
                         <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                         <div class="btn-success">Aciertos Coberturas = <?php echo e($numAciertos3); ?>/<?php echo e($numColumnas3*$contador3); ?></div>
                       </tbody>
                     </table>
                     <span class="d-none"><?php echo e($guardarAciertos3=$guardarAciertos3+$numAciertos3, $guardarColumnas3=$guardarColumnas3+($numColumnas3*$contador3)); ?></span>

                     
                     <div class="btn-success position-absolute"><?php echo e($guardarAciertos3); ?>/<?php echo e($guardarColumnas3); ?></div>
                     <div class="btn-success position-absolute"><?php echo e($totalAciertos=$guardarAciertos3); ?>/<?php echo e($totalColumnas=$guardarColumnas3); ?></div>


                        
                   </div>

                 
                   <div class="tab-pane fade" id="tabB">
                     <form class="d-flex w-25" id="searchform" onkeyup="filterConsentimientos()">
                       <input class="form-control me-2" type="text" placeholder="Busca por # de certificado " id="searchConsentimientos">
                       
                     </form>
                     <span class="d-none"><?php echo e($numAciertos3=0, $contador3=0); ?></span>
                     <table class="table table-hover table-striped table-responsive table-bordered">
                       <thead>
                         <tr class="fixed-table">
                           
                           <th scope="col">Certificado</th>
                           <th scope="col">Nombre</th>
                           <th scope="col">Sexo</th>
                           <th scope="col">Edad</th>
                           <th scope="col">Fecha de Nacimiento</th>
                           <th scope="col">Datos del contratante</th>
                           <th scope="col">Plazo</th>
                           <th scope="col">Forma de Pago</th>
                           <th scope="col">Contributorio</th>
                           <th scope="col">Inicio Vigencia</th>
                           <th scope="col">Fin Vigencia</th>
                           <th scope="col">Moneda</th>
                           <span class="d-none"><?php echo e($numColumnas3=11); ?></span>
                         </tr>
                       </thead>
                       <tbody id="tbody-consentimientos_vida_datos3">
                         <?php $__currentLoopData = $consentimientos_vida_datos3; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $consentimientos_vida_dato): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                         <tr class="tr-consentimientos_vida_datos3">
                           <td class="tr-td-certificado-consentimientos_vida_datos3"><?php echo e($consentimientos_vida_dato->certificado); ?></td>
                           <td>
                             <?php if($consentimientos_vida_dato->nombre == 1): ?>
                             <span class="d-none"><?php echo e($numAciertos3++); ?></span>
                             <div class="checkdiv"><input disabled checked type="checkbox" class="le-checkbox"/></div>
                             <?php elseif($consentimientos_vida_dato->nombre == 0): ?>
                             <div class="checkdiv"><input disabled  type="checkbox" class="le-checkbox"/></div>
                             <?php else: ?>
                             <img src="<?php echo e(asset('img/unknown.png')); ?>" alt="" width="32">
                             <?php endif; ?>
                           </td>
                           <td>
                             <?php if($consentimientos_vida_dato->sexo == 1): ?>
                             <span class="d-none"><?php echo e($numAciertos3++); ?></span>
                             <div class="checkdiv"><input disabled checked type="checkbox" class="le-checkbox"/></div>
                             <?php elseif($consentimientos_vida_dato->nombre == 0): ?>
                             <div class="checkdiv"><input disabled  type="checkbox" class="le-checkbox"/></div>
                             <?php else: ?>
                             <img src="<?php echo e(asset('img/unknown.png')); ?>" alt="" width="32">
                             <?php endif; ?>
                           </td>
                           <td>
                             <?php if($consentimientos_vida_dato->edad == 1): ?>
                             <span class="d-none"><?php echo e($numAciertos3++); ?></span>
                             <div class="checkdiv"><input disabled checked type="checkbox" class="le-checkbox"/></div>
                             <?php elseif($consentimientos_vida_dato->edad == 0): ?>
                             <div class="checkdiv"><input disabled  type="checkbox" class="le-checkbox"/></div>
                             <?php else: ?>
                             <img src="<?php echo e(asset('img/unknown.png')); ?>" alt="" width="32">
                             <?php endif; ?>
                           </td>
                           <td>
                             <?php if($consentimientos_vida_dato->fechaDeNacimiento == 1): ?>
                             <span class="d-none"><?php echo e($numAciertos3++); ?></span>
                             <div class="checkdiv"><input disabled checked type="checkbox" class="le-checkbox"/></div>
                             <?php elseif($consentimientos_vida_dato->fechaDeNacimiento == 0): ?>
                             <div class="checkdiv"><input disabled  type="checkbox" class="le-checkbox"/></div>
                             <?php else: ?>
                             <img src="<?php echo e(asset('img/unknown.png')); ?>" alt="" width="32">
                             <?php endif; ?>
                           </td>
                           <td>
                             <?php if($consentimientos_vida_dato->datosDelContratante == 1): ?>
                             <span class="d-none"><?php echo e($numAciertos3++); ?></span>
                             <div class="checkdiv"><input disabled checked type="checkbox" class="le-checkbox"/></div>
                             <?php elseif($consentimientos_vida_dato->datosDelContratante == 0): ?>
                             <div class="checkdiv"><input disabled  type="checkbox" class="le-checkbox"/></div>
                             <?php else: ?>
                             <img src="<?php echo e(asset('img/unknown.png')); ?>" alt="" width="32">
                             <?php endif; ?>
                           </td>
                           <td>
                             <?php if($consentimientos_vida_dato->plazo == 1): ?>
                             <span class="d-none"><?php echo e($numAciertos3++); ?></span>
                             <div class="checkdiv"><input disabled checked type="checkbox" class="le-checkbox"/></div>
                             <?php elseif($consentimientos_vida_dato->plazo == 0): ?>
                             <div class="checkdiv"><input disabled  type="checkbox" class="le-checkbox"/></div>
                             <?php else: ?>
                             <img src="<?php echo e(asset('img/unknown.png')); ?>" alt="" width="32">
                             <?php endif; ?>
                           </td>
                           <td>
                             <?php if($consentimientos_vida_dato->formaDePago == 1): ?>
                             <span class="d-none"><?php echo e($numAciertos3++); ?></span>
                             <div class="checkdiv"><input disabled checked type="checkbox" class="le-checkbox"/></div>
                             <?php elseif($consentimientos_vida_dato->formaDePago == 0): ?>
                             <div class="checkdiv"><input disabled  type="checkbox" class="le-checkbox"/></div>
                             <?php else: ?>
                             <img src="<?php echo e(asset('img/unknown.png')); ?>" alt="" width="32">
                             <?php endif; ?>
                           </td>
                           <td>
                             <?php if($consentimientos_vida_dato->contributorio == 1): ?>
                             <span class="d-none"><?php echo e($numAciertos3++); ?></span>
                             <div class="checkdiv"><input disabled checked type="checkbox" class="le-checkbox"/></div>
                             <?php elseif($consentimientos_vida_dato->contributorio == 0): ?>
                             <div class="checkdiv"><input disabled  type="checkbox" class="le-checkbox"/></div>
                             <?php else: ?>
                             <img src="<?php echo e(asset('img/unknown.png')); ?>" alt="" width="32">
                             <?php endif; ?>
                           </td>
                           <td>
                             <?php if($consentimientos_vida_dato->inicioVigencia == 1): ?>
                             <span class="d-none"><?php echo e($numAciertos3++); ?></span>
                             <div class="checkdiv"><input disabled checked type="checkbox" class="le-checkbox"/></div>
                             <?php elseif($consentimientos_vida_dato->inicioVigencia == 0): ?>
                             <div class="checkdiv"><input disabled  type="checkbox" class="le-checkbox"/></div>
                             <?php else: ?>
                             <img src="<?php echo e(asset('img/unknown.png')); ?>" alt="" width="32">
                             <?php endif; ?>
                           </td>
                           <td>
                             <?php if($consentimientos_vida_dato->finVigencia == 1): ?>
                             <span class="d-none"><?php echo e($numAciertos3++); ?></span>
                             <div class="checkdiv"><input disabled checked type="checkbox" class="le-checkbox"/></div>
                             <?php elseif($consentimientos_vida_dato->finVigencia == 0): ?>
                             <div class="checkdiv"><input disabled  type="checkbox" class="le-checkbox"/></div>
                             <?php else: ?>
                             <img src="<?php echo e(asset('img/unknown.png')); ?>" alt="" width="32">
                             <?php endif; ?>
                           </td>
                           <td>
                             <?php if($consentimientos_vida_dato->moneda == 1): ?>
                             <span class="d-none"><?php echo e($numAciertos3++); ?></span>
                             <div class="checkdiv"><input disabled checked type="checkbox" class="le-checkbox"/></div>
                             <?php elseif($consentimientos_vida_dato->moneda == 0): ?>
                             <div class="checkdiv"><input disabled  type="checkbox" class="le-checkbox"/></div>
                             <?php else: ?>
                             <img src="<?php echo e(asset('img/unknown.png')); ?>" alt="" width="32">
                             <?php endif; ?>
                           </td>
                           <span class="d-none"><?php echo e($contador3++); ?></span>
                         </tr>
                           
                         <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                         <div class="btn-success">Aciertos Coberturas = <?php echo e($numAciertos3); ?>/<?php echo e($numColumnas3*$contador3); ?></div>
                         <span class="d-none"><?php echo e($totalAciertos=$totalAciertos+$numAciertos3, $totalColumnas=$totalColumnas+($numColumnas3*$contador3)); ?></span>
                       </tbody>
                     </table>
                   </div>
                 
                   <div class="tab-pane fade" id="tabC">
                     
                     <h3 class="main-inter_h3">Datos</h3>
                     <span class="d-none"><?php echo e($numAciertos3=0, $contador3=0); ?></span>
                     <table class="table table-hover table-striped table-responsive table-bordered">
                       <thead>
                         <tr class="fixed-table">
                           
                           <th scope="col">Pagina</th>
                           <th scope="col">Plazo</th>
                           <th scope="col">Forma de Pago</th>
                           <th scope="col">Contributorio</th>
                           <th scope="col">inicio Vigencia</th>
                           <th scope="col">fin Vigencia</th>
                           <th scope="col">asegurados</th>
                           <th scope="col">Datos del contratante</th>
                           <th scope="col">Prima Neta</th>
                           <th scope="col">Recargos</th>
                           <th scope="col">Gastos expedición</th>
                           <th scope="col">IVA</th>
                           <th scope="col">Prima Total</th>
                           <th scope="col">Moneda</th>
                           <span class="d-none"><?php echo e($numColumnas3=13); ?></span>
                         </tr>
                       </thead>
                       <tbody>
                         <?php $__currentLoopData = $detalle_cobertura_datos3; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $detalle_cobertura_dato): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                         <tr>
                           
                           <td><?php echo e($detalle_cobertura_dato->pagina); ?></td>
                           <td>
                             <?php if($detalle_cobertura_dato->plazo == 1): ?>
                             <div class="checkdiv"><input disabled checked type="checkbox" class="le-checkbox"/></div>
                             <span class="d-none"><?php echo e($numAciertos3++); ?></span>
                             <?php elseif($detalle_cobertura_dato->plazo == 0): ?>
                             <div class="checkdiv"><input disabled  type="checkbox" class="le-checkbox"/></div>
                             <?php else: ?>
                             <img src="<?php echo e(asset('img/unknown.png')); ?>" alt="" width="32">
                             <?php endif; ?>
                           </td>
                           <td>
                             <?php if($detalle_cobertura_dato->formaDePago == 1): ?>
                             <span class="d-none"><?php echo e($numAciertos3++); ?></span>
                             <div class="checkdiv"><input disabled checked type="checkbox" class="le-checkbox"/></div>
                             <?php elseif($detalle_cobertura_dato->formaDePago == 0): ?>
                             <div class="checkdiv"><input disabled  type="checkbox" class="le-checkbox"/></div>
                             <?php else: ?>
                             <img src="<?php echo e(asset('img/unknown.png')); ?>" alt="" width="32">
                             <?php endif; ?>
                           </td>
                           <td>
                             <?php if($detalle_cobertura_dato->contributorio == 1): ?>
                             <span class="d-none"><?php echo e($numAciertos3++); ?></span>
                             <div class="checkdiv"><input disabled checked type="checkbox" class="le-checkbox"/></div>
                             <?php elseif($detalle_cobertura_dato->contributorio == 0): ?>
                             <div class="checkdiv"><input disabled  type="checkbox" class="le-checkbox"/></div>
                             <?php else: ?>
                             <img src="<?php echo e(asset('img/unknown.png')); ?>" alt="" width="32">
                             <?php endif; ?>
                           </td>
                           <td>
                             <?php if($detalle_cobertura_dato->inicioVigencia == 1): ?>
                             <span class="d-none"><?php echo e($numAciertos3++); ?></span>
                             <div class="checkdiv"><input disabled checked type="checkbox" class="le-checkbox"/></div>
                             <?php elseif($detalle_cobertura_dato->inicioVigencia == 0): ?>
                             <div class="checkdiv"><input disabled  type="checkbox" class="le-checkbox"/></div>
                             <?php else: ?>
                             <img src="<?php echo e(asset('img/unknown.png')); ?>" alt="" width="32">
                             <?php endif; ?>
                           </td>
                           <td>
                             <?php if($detalle_cobertura_dato->finVigencia == 1): ?>
                             <span class="d-none"><?php echo e($numAciertos3++); ?></span>
                             <div class="checkdiv"><input disabled checked type="checkbox" class="le-checkbox"/></div>
                             <?php elseif($detalle_cobertura_dato->finVigencia == 0): ?>
                             <div class="checkdiv"><input disabled  type="checkbox" class="le-checkbox"/></div>
                             <?php else: ?>
                             <img src="<?php echo e(asset('img/unknown.png')); ?>" alt="" width="32">
                             <?php endif; ?>
                           </td>
                           <td>
                             <?php if($detalle_cobertura_dato->asegurados == 1): ?>
                             <span class="d-none"><?php echo e($numAciertos3++); ?></span>
                             <div class="checkdiv"><input disabled checked type="checkbox" class="le-checkbox"/></div>
                             <?php elseif($detalle_cobertura_dato->asegurados == 0): ?>
                             <div class="checkdiv"><input disabled  type="checkbox" class="le-checkbox"/></div>
                             <?php else: ?>
                             <img src="<?php echo e(asset('img/unknown.png')); ?>" alt="" width="32">
                             <?php endif; ?>
                           </td>
                           <td>
                             <?php if($detalle_cobertura_dato->datosDelContratante == 1): ?>
                             <span class="d-none"><?php echo e($numAciertos3++); ?></span>
                             <div class="checkdiv"><input disabled checked type="checkbox" class="le-checkbox"/></div>
                             <?php elseif($detalle_cobertura_dato->datosDelContratante == 0): ?>
                             <div class="checkdiv"><input disabled  type="checkbox" class="le-checkbox"/></div>
                             <?php else: ?>
                             <img src="<?php echo e(asset('img/unknown.png')); ?>" alt="" width="32">
                             <?php endif; ?>
                           </td>
                           <td>
                             <?php if($detalle_cobertura_dato->primaNeta == 1): ?>
                             <span class="d-none"><?php echo e($numAciertos3++); ?></span>
                             <div class="checkdiv"><input disabled checked type="checkbox" class="le-checkbox"/></div>
                             <?php elseif($detalle_cobertura_dato->primaNeta == 0): ?>
                             <div class="checkdiv"><input disabled  type="checkbox" class="le-checkbox"/></div>
                             <?php else: ?>
                             <img src="<?php echo e(asset('img/unknown.png')); ?>" alt="" width="32">
                             <?php endif; ?>
                           </td>
                           <td>
                             <?php if($detalle_cobertura_dato->recargos == 1): ?>
                             <span class="d-none"><?php echo e($numAciertos3++); ?></span>
                             <div class="checkdiv"><input disabled checked type="checkbox" class="le-checkbox"/></div>
                             <?php elseif($detalle_cobertura_dato->recargos == 0): ?>
                             <div class="checkdiv"><input disabled  type="checkbox" class="le-checkbox"/></div>
                             <?php else: ?>
                             <img src="<?php echo e(asset('img/unknown.png')); ?>" alt="" width="32">
                             <?php endif; ?>
                           </td>
                           <td>
                             <?php if($detalle_cobertura_dato->gtosExpedicion == 1): ?>
                             <span class="d-none"><?php echo e($numAciertos3++); ?></span>
                             <div class="checkdiv"><input disabled checked type="checkbox" class="le-checkbox"/></div>
                             <?php elseif($detalle_cobertura_dato->gtosExpedicion == 0): ?>
                             <div class="checkdiv"><input disabled  type="checkbox" class="le-checkbox"/></div>
                             <?php else: ?>
                             <img src="<?php echo e(asset('img/unknown.png')); ?>" alt="" width="32">
                             <?php endif; ?>
                           </td>
                           <td>
                             <?php if($detalle_cobertura_dato->IVA == 1): ?>
                             <span class="d-none"><?php echo e($numAciertos3++); ?></span>
                             <div class="checkdiv"><input disabled checked type="checkbox" class="le-checkbox"/></div>
                             <?php elseif($detalle_cobertura_dato->IVA == 0): ?>
                             <div class="checkdiv"><input disabled  type="checkbox" class="le-checkbox"/></div>
                             <?php else: ?>
                             <img src="<?php echo e(asset('img/unknown.png')); ?>" alt="" width="32">
                             <?php endif; ?>
                           </td>
                           <td>
                             <?php if($detalle_cobertura_dato->primaTotal == 1): ?>
                             <span class="d-none"><?php echo e($numAciertos3++); ?></span>
                             <div class="checkdiv"><input disabled checked type="checkbox" class="le-checkbox"/></div>
                             <?php elseif($detalle_cobertura_dato->primaTotal == 0): ?>
                             <div class="checkdiv"><input disabled  type="checkbox" class="le-checkbox"/></div>
                             <?php else: ?>
                             <img src="<?php echo e(asset('img/unknown.png')); ?>" alt="" width="32">
                             <?php endif; ?>
                           </td>
                           <td>
                             <?php if($detalle_cobertura_dato->moneda == 1): ?>
                             <span class="d-none"><?php echo e($numAciertos3++); ?></span>
                             <div class="checkdiv"><input disabled checked type="checkbox" class="le-checkbox"/></div>
                             <?php elseif($detalle_cobertura_dato->moneda == 0): ?>
                             <div class="checkdiv"><input disabled  type="checkbox" class="le-checkbox"/></div>
                             <?php else: ?>
                             <img src="<?php echo e(asset('img/unknown.png')); ?>" alt="" width="32">
                             <?php endif; ?>
                           </td>
                         </tr>
                         <span class="d-none"><?php echo e($contador3++); ?></span>
                         <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                         <div class="btn-success">Aciertos Datos= <?php echo e($numAciertos3); ?>/<?php echo e($numColumnas3*$contador3); ?></div>
                       </tbody>
                     </table>
                     
                     <span class="d-none"><?php echo e($guardarAciertos3=$numAciertos3, $guardarColumnas3=$numColumnas3*$contador3); ?></span>
                     <span class="d-none"><?php echo e($totalAciertos=$totalAciertos+$numAciertos3, $totalColumnas=$totalColumnas+($numColumnas3*$contador3)); ?></span>

                     <?php echo e($guardarAciertos3); ?>

                     <?php echo e($guardarColumnas3); ?>

                     
                     <h3 class="main-inter_h3">Coberturas</h3>
                     <span class="d-none"><?php echo e($numAciertos3=0, $numColumnas3=0, $contador3=0); ?></span>
                     <table class="table table-hover table-striped table-responsive table-bordered">
                       <thead>
                         <tr class="fixed-table">
                           <th scope="col">Pagina</th>
                           <th scope="col">Cobertura</th>
                           <th scope="col">Prima Neta</th>
                           <span class="d-none"><?php echo e($numColumnas3=1); ?></span>
                         </tr>
                       </thead>
                       <tbody>
                         <?php $__currentLoopData = $detalle_cobertura_coberturas3; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $detalle_cobertura_cobertura): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                         <tr>
                           
                           <td><?php echo e($detalle_cobertura_cobertura->pagina); ?></td>
                           <td>
                             <?php echo e($detalle_cobertura_cobertura->cobertura); ?>

                           </td>
                           <td>
                             <?php if($detalle_cobertura_cobertura->primaNeta == 1): ?>
                             <span class="d-none"><?php echo e($numAciertos3++); ?></span>
                             <div class="checkdiv"><input disabled checked type="checkbox" class="le-checkbox"/></div>
                             <?php elseif($detalle_cobertura_cobertura->primaNeta == 0): ?>
                             <div class="checkdiv"><input disabled  type="checkbox" class="le-checkbox"/></div>
                             <?php else: ?>
                             <img src="<?php echo e(asset('img/unknown.png')); ?>" alt="" width="32">
                             <?php endif; ?>
                           </td>
                         </tr>
                         <span class="d-none"><?php echo e($contador3++); ?></span>
                         <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                         <div class="btn-success">Aciertos Coberturas = <?php echo e($numAciertos3); ?>/<?php echo e($numColumnas3*$contador3); ?></div>
                       </tbody>
                     </table>
                     <span class="d-none"><?php echo e($guardarAciertos3=$guardarAciertos3+$numAciertos3, $guardarColumnas3=$guardarColumnas3+($numColumnas3*$contador3)); ?></span>
                     <span class="d-none"><?php echo e($totalAciertos=$totalAciertos+$numAciertos3, $totalColumnas=$totalColumnas+($numColumnas3*$contador3)); ?></span>
                     
                     <div class="btn-success position-absolute"><?php echo e($guardarAciertos3); ?>/<?php echo e($guardarColumnas3); ?></div>

                   </div>
                 
                   <div class="tab-pane fade" id="tabD">
                     <span class="d-none"><?php echo e($numAciertos3=0, $contador3=0); ?></span>
                     <table class="table table-hover table-striped table-responsive">
                       <thead>
                         <tr class="fixed-table">
                           
                           <th scope="col">Subgrupo</th>
                           <th scope="col">Categoría</th>
                           <th scope="col">Endoso</th>
                           <th scope="col">Valor</th>
                           <span class="d-none"><?php echo e($numColumnas3=1); ?></span>
                         </tr>
                       </thead>
                       <tbody>
                         <?php $__currentLoopData = $endosos3; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $endoso): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                         <tr>
                           
                           <td><?php echo e($endoso->subgrupo); ?></td>
                           <td><?php echo e($endoso->categoria); ?></td>
                           <td><?php echo e($endoso->endoso); ?></td>
                           <td>
                             <?php if($endoso->valorEndoso == 1): ?>
                             <div class="checkdiv"><input disabled checked type="checkbox" class="le-checkbox"/></div>
                             <span class="d-none"><?php echo e($numAciertos3++); ?></span>
                             <?php elseif($endoso->valorEndoso == 0): ?>
                             <div class="checkdiv"><input disabled  type="checkbox" class="le-checkbox"/></div>
                             <?php else: ?>
                             <img src="<?php echo e(asset('img/unknown.png')); ?>" alt="" width="32">
                             <?php endif; ?>
                           </td>
                           <span class="d-none"><?php echo e($contador3++); ?></span>
                         </tr>
                         <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                         <div class="btn-success">Aciertos Coberturas = <?php echo e($numAciertos3); ?>/<?php echo e($numColumnas3*$contador3); ?></div>
                         <span class="d-none"><?php echo e($totalAciertos=$totalAciertos+$numAciertos3, $totalColumnas=$totalColumnas+($numColumnas3*$contador3)); ?></span>
                       </tbody>
                     </table>
                   </div>
                 
                   <div class="tab-pane fade" id="tabE">
                     <form class="d-flex w-25" id="searchform" onkeyup="filterListado()">
                       <input class="form-control me-2" type="text" placeholder="Busca por # de certificado " id="searchListado">
                       
                     </form>
                     <span class="d-none"><?php echo e($numAciertos3=0, $contador3=0); ?></span>

                     <table class="table table-hover table-striped table-responsive table-bordered">
                       <thead>
                         <tr class="fixed-table">
                           
                           <th scope="col">Certificado</th>
                           <th scope="col">Subgrupo</th>
                           <th scope="col">Categoría</th>
                           <th scope="col">Nombre</th>
                           <th scope="col">Antiguedad</th>
                           <th scope="col">Edad</th>
                           <th scope="col">Sexo</th>
                           <th scope="col">FechaAltaBaja</th>
                           <span class="d-none"><?php echo e($numColumnas3=6); ?></span>
                         </tr>
                       </thead>
                       <tbody id="tbody-listado_asegurados3">
                         <?php $__currentLoopData = $listado_asegurados3; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $listado_asegurado): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                         <tr>
                           
                           <td class="tr-td-certificado-listado_asegurados3"><?php echo e($listado_asegurado->certificado); ?></td>
                           <td><?php echo e($listado_asegurado->subgrupo); ?></td>
                           <td>
                             <?php if($listado_asegurado->categoria == 1): ?>
                             <span class="d-none"><?php echo e($numAciertos3++); ?></span>
                             <div class="checkdiv"><input disabled checked type="checkbox" class="le-checkbox"/></div>
                             <?php elseif($listado_asegurado->categoria == 0): ?>
                             <div class="checkdiv"><input disabled  type="checkbox" class="le-checkbox"/></div>
                             <?php else: ?>
                             <img src="<?php echo e(asset('img/unknown.png')); ?>" alt="" width="32">
                             <?php endif; ?>
                           </td>
                           <td>
                             <?php if($listado_asegurado->nombre == 1): ?>
                             <span class="d-none"><?php echo e($numAciertos3++); ?></span>
                             <div class="checkdiv"><input disabled checked type="checkbox" class="le-checkbox"/></div>
                             <?php elseif($listado_asegurado->nombre == 0): ?>
                             <div class="checkdiv"><input disabled  type="checkbox" class="le-checkbox"/></div>
                             <?php else: ?>
                             <img src="<?php echo e(asset('img/unknown.png')); ?>" alt="" width="32">
                             <?php endif; ?>
                           </td>
                           <td>
                             <?php if($listado_asegurado->antiguedad == 1): ?>
                             <span class="d-none"><?php echo e($numAciertos3++); ?></span>
                             <div class="checkdiv"><input disabled checked type="checkbox" class="le-checkbox"/></div>
                             <?php elseif($listado_asegurado->antiguedad == 0): ?>
                             <div class="checkdiv"><input disabled  type="checkbox" class="le-checkbox"/></div>
                             <?php else: ?>
                             <img src="<?php echo e(asset('img/unknown.png')); ?>" alt="" width="32">
                             <?php endif; ?>
                           </td>
                           <td>
                             <?php if($listado_asegurado->edad == 1): ?>
                             <span class="d-none"><?php echo e($numAciertos3++); ?></span>
                             <div class="checkdiv"><input disabled checked type="checkbox" class="le-checkbox"/></div>
                             <?php elseif($listado_asegurado->edad == 0): ?>
                             <div class="checkdiv"><input disabled  type="checkbox" class="le-checkbox"/></div>
                             <?php else: ?>
                             <img src="<?php echo e(asset('img/unknown.png')); ?>" alt="" width="32">
                             <?php endif; ?>
                           </td>
                           <td>
                             <?php if($listado_asegurado->sexo == 1): ?>
                             <span class="d-none"><?php echo e($numAciertos3++); ?></span>
                             <div class="checkdiv"><input disabled checked type="checkbox" class="le-checkbox"/></div>
                             <?php elseif($listado_asegurado->sexo == 0): ?>
                             <div class="checkdiv"><input disabled  type="checkbox" class="le-checkbox"/></div>
                             <?php else: ?>
                             <img src="<?php echo e(asset('img/unknown.png')); ?>" alt="" width="32">
                             <?php endif; ?>
                           </td>
                           <td>
                             <?php if($listado_asegurado->fechaAltaBaja == 1): ?>
                             <span class="d-none"><?php echo e($numAciertos3++); ?></span>
                             <div class="checkdiv"><input disabled checked type="checkbox" class="le-checkbox"/></div>
                             <?php elseif($listado_asegurado->fechaAltaBaja == 0): ?>
                             <div class="checkdiv"><input disabled  type="checkbox" class="le-checkbox"/></div>
                             <?php else: ?>
                             <img src="<?php echo e(asset('img/unknown.png')); ?>" alt="" width="32">
                             <?php endif; ?>
                           </td>
                           <span class="d-none"><?php echo e($contador3++); ?></span>
                         </tr>
                         <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                         <div class="btn-success">Aciertos Coberturas = <?php echo e($numAciertos3); ?>/<?php echo e($numColumnas3*$contador3); ?></div>
                         <span class="d-none"><?php echo e($totalAciertos=$totalAciertos+$numAciertos3, $totalColumnas=$totalColumnas+($numColumnas3*$contador3)); ?></span>

                       </tbody>
                     </table>
                   </div>
              </div>
            </td>
            <th scope="row"><?php echo e($noPoliza3); ?></th>
            <td><?php echo e($totalAciertos); ?>/<?php echo e($totalColumnas); ?></td>
            <td><a class="table-td_hover" href="<?php echo e(route('coincidencias.show', $noPoliza3)); ?>">Ver detalles</a></td>
          </tr>
          
        </tbody>
      </table>
    </section>

  </main>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\inter\resources\views/home.blade.php ENDPATH**/ ?>