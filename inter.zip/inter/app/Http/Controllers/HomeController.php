<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\NumPoliza;
use App\Models\Endosos;
use App\Models\ListadoAsegurados;
use App\Models\DetalleCoberturasDatos;
use App\Models\DetalleCoberturasCoberturas;
use App\Models\ConsentimientoVidaDatos;
use App\Models\CaratulaDatos;
use App\Models\CaratulaCoberturas;



class HomeController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $numPolizas = NumPoliza::all();
        
        $noPoliza='12000-4124-1';
        $numColumnas = 0;
        $numAciertos = 0;
        $contador = 0;
        $guardarAciertos = 0;
        $guardarColumnas = 0;
        $caratula_datos=CaratulaDatos::where('noPoliza', $noPoliza)->get();
        $caratula_coberturas = CaratulaCoberturas::where('noPoliza', $noPoliza)->get();
        $endosos = Endosos::where('noPoliza', $noPoliza)->get();
        $listado_asegurados = ListadoAsegurados::where('noPoliza', $noPoliza)->get();
        $detalle_cobertura_datos = DetalleCoberturasDatos::where('noPoliza', $noPoliza)->get();
        $detalle_cobertura_coberturas = DetalleCoberturasCoberturas::where('noPoliza', $noPoliza)->get();
        $consentimientos_vida_datos = ConsentimientoVidaDatos::where('noPoliza', $noPoliza)->get();
        $totalAciertos=0;
        $totalColumnas=0;
        $paraTabsA=0;
        $paraTabsC=0;


        $noPoliza2='12000-4252-2';
        $numColumnas2 = 0;
        $numAciertos2 = 0;
        $contador2 = 0;
        $guardarAciertos2 = 0;
        $guardarColumnas2 = 0;
        $caratula_datos2=CaratulaDatos::where('noPoliza', $noPoliza2)->get();
        $caratula_coberturas2 = CaratulaCoberturas::where('noPoliza', $noPoliza2)->get();
        $endosos2 = Endosos::where('noPoliza', $noPoliza2)->get();
        $listado_asegurados2 = ListadoAsegurados::where('noPoliza', $noPoliza2)->get();
        $detalle_cobertura_datos2 = DetalleCoberturasDatos::where('noPoliza', $noPoliza2)->get();
        $detalle_cobertura_coberturas2 = DetalleCoberturasCoberturas::where('noPoliza', $noPoliza2)->get();
        $consentimientos_vida_datos2 = ConsentimientoVidaDatos::where('noPoliza', $noPoliza2)->get();
        $paraTabsA2=0;
        $paraTabsC2=0;


        $noPoliza3='12000-4253-2';
        $numColumnas3 = 0;
        $numAciertos3 = 0;
        $contador3 = 0;
        $guardarAciertos3 = 0;
        $guardarColumnas3 = 0;
        $caratula_datos3=CaratulaDatos::where('noPoliza', $noPoliza3)->get();
        $caratula_coberturas3 = CaratulaCoberturas::where('noPoliza', $noPoliza3)->get();
        $endosos3 = Endosos::where('noPoliza', $noPoliza3)->get();
        $listado_asegurados3 = ListadoAsegurados::where('noPoliza', $noPoliza3)->get();
        $detalle_cobertura_datos3 = DetalleCoberturasDatos::where('noPoliza', $noPoliza3)->get();
        $detalle_cobertura_coberturas3 = DetalleCoberturasCoberturas::where('noPoliza', $noPoliza3)->get();
        $consentimientos_vida_datos3 = ConsentimientoVidaDatos::where('noPoliza', $noPoliza3)->get();
        $paraTabsA3='';
        $paraTabsC3='';




        return view('home', [
            // 'numAciertos'=>$numAciertos,

            'numPolizas'=>$numPolizas,

            'caratula_datos'=>$caratula_datos,
            'caratula_coberturas'=>$caratula_coberturas,
            'endosos'=>$endosos, 
            'listado_asegurados'=>$listado_asegurados,
            'detalle_cobertura_datos'=>$detalle_cobertura_datos,
            'detalle_cobertura_coberturas'=>$detalle_cobertura_coberturas,
            'consentimientos_vida_datos'=>$consentimientos_vida_datos,
            'noPoliza'=>$noPoliza,
            'numColumnas'=>$numColumnas,
            'numAciertos'=>$numAciertos, 
            'contador'=>$contador, 
            'noPoliza'=>$noPoliza, 
            'totalAciertos'=>$totalAciertos,
            'totalColumnas'=>$totalColumnas,
            'paraTabsA'=>$paraTabsA,
            'paraTabsC'=>$paraTabsA,

            'caratula_datos2'=>$caratula_datos2,
            'caratula_coberturas2'=>$caratula_coberturas2,
            'endosos2'=>$endosos2, 
            'listado_asegurados2'=>$listado_asegurados2,
            'detalle_cobertura_datos2'=>$detalle_cobertura_datos2,
            'detalle_cobertura_coberturas2'=>$detalle_cobertura_coberturas2,
            'consentimientos_vida_datos2'=>$consentimientos_vida_datos2,
            'noPoliza2'=>$noPoliza2,
            'numColumnas2'=>$numColumnas2,
            'numAciertos2'=>$numAciertos2, 
            'contador2'=>$contador2, 
            'noPoliza2'=>$noPoliza2, 
            'paraTabsA2'=>$paraTabsA2,
            'paraTabsC2'=>$paraTabsA2,

            'caratula_datos3'=>$caratula_datos3,
            'caratula_coberturas3'=>$caratula_coberturas3,
            'endosos3'=>$endosos3, 
            'listado_asegurados3'=>$listado_asegurados3,
            'detalle_cobertura_datos3'=>$detalle_cobertura_datos3,
            'detalle_cobertura_coberturas3'=>$detalle_cobertura_coberturas3,
            'consentimientos_vida_datos3'=>$consentimientos_vida_datos3,
            'noPoliza3'=>$noPoliza3,
            'numColumnas3'=>$numColumnas3,
            'numAciertos3'=>$numAciertos3, 
            'contador3'=>$contador3, 
            'noPoliza3'=>$noPoliza3, 
            'paraTabsA3'=>$paraTabsA3,
            'paraTabsC3'=>$paraTabsA3,


        ]);
        
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show()
    {
        
        
        $noPoliza1='12000-4124-1';

        $caratula_datos=CaratulaDatos::where('noPoliza', $noPoliza)->get();
        $caratula_coberturas = CaratulaCoberturas::where('noPoliza', $noPoliza)->get();

        $endosos = Endosos::where('noPoliza', $noPoliza)->get();

        $listado_asegurados = ListadoAsegurados::where('noPoliza', $noPoliza)->get();

        $detalle_cobertura_datos = DetalleCoberturasDatos::where('noPoliza', $noPoliza)->get();
        $detalle_cobertura_coberturas = DetalleCoberturasCoberturas::where('noPoliza', $noPoliza)->get();

        $consentimientos_vida_datos = ConsentimientoVidaDatos::where('noPoliza', $noPoliza)->get();

        $numColumnas = 13;
        $numAciertos = 0;

        $contador = 0;
        $guardarAciertos = 0;
        $guardarColumnas = 0;

        return view('tabs',[
            'caratula_datos'=>$caratula_datos,
            'caratula_coberturas'=>$caratula_coberturas,

            'endosos'=>$endosos, 

            'listado_asegurados'=>$listado_asegurados,

            'detalle_cobertura_datos'=>$detalle_cobertura_datos,
            'detalle_cobertura_coberturas'=>$detalle_cobertura_coberturas,

            'consentimientos_vida_datos'=>$consentimientos_vida_datos,
            
            'noPoliza1'=>$noPoliza,

            'numColumnas'=>$numColumnas,
            'numAciertos'=>$numAciertos, 

            'contador'=>$contador, 

        ]);
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }
}
