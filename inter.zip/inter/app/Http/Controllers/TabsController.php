<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Endosos;
use App\Models\ListadoAsegurados;
use App\Models\DetalleCoberturasDatos;
use App\Models\DetalleCoberturasCoberturas;
use App\Models\ConsentimientoVidaDatos;
use App\Models\CaratulaDatos;
use App\Models\CaratulaCoberturas;





class TabsController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {

    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($noPolizas)
    {
        
        $noPoliza=$noPolizas;
       


        $caratula_datos=CaratulaDatos::where('noPoliza', $noPoliza)->get();
        $caratula_coberturas = CaratulaCoberturas::where('noPoliza', $noPoliza)->get();

        $endosos = Endosos::where('noPoliza', $noPoliza)->get();

        $listado_asegurados = ListadoAsegurados::where('noPoliza', $noPoliza)->get();

        $detalle_cobertura_datos = DetalleCoberturasDatos::where('noPoliza', $noPoliza)->get();
        $detalle_cobertura_coberturas = DetalleCoberturasCoberturas::where('noPoliza', $noPoliza)->get();

        $consentimientos_vida_datos = ConsentimientoVidaDatos::where('noPoliza', $noPoliza)->get();

        $numColumnas = 0;
        $numAciertos = 0;

        $contador = 0;
        $guardarAciertos = 0;
        $guardarColumnas = 0;

        $caratulaA = 0;
        $caratulaAC = 0;

        return view('tabs',[
            'caratula_datos'=>$caratula_datos,
            'caratula_coberturas'=>$caratula_coberturas,

            'endosos'=>$endosos, 

            'listado_asegurados'=>$listado_asegurados,

            'detalle_cobertura_datos'=>$detalle_cobertura_datos,
            'detalle_cobertura_coberturas'=>$detalle_cobertura_coberturas,

            'consentimientos_vida_datos'=>$consentimientos_vida_datos,
            
            'noPoliza'=>$noPoliza,

            'numColumnas'=>$numColumnas,
            'numAciertos'=>$numAciertos, 

            'contador'=>$contador, 


        ]);
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }
}
