<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class ConsentimientoVidaDatos extends Model
{
    protected $table = "consentimientos_vida_datos";
    use HasFactory;
}
