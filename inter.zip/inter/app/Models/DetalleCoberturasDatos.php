<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class DetalleCoberturasDatos extends Model
{
    protected $table = "detalle_coberturas_datos";
    use HasFactory;
}

