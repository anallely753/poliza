<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class NumPoliza extends Model
{
    protected $table = "listado_polizas";
    use HasFactory;
}
