function filterConsentimientos(){
	
	console.log('hola');
	var FilterValue, input, ul, li, i, res;

	input = document.getElementById('searchConsentimientos');
	FilterValue = input.value;
	ul = document.getElementById('tbody-consentimientos_vida_datos');
	li = ul.getElementsByTagName('tr');

	for(i=0;i<li.length;i++){
		var a = li[i].getElementsByClassName('tr-td-certificado-consentimientos_vida_datos')[0];
		var b = a.textContent;
		console.log(b);

		// var b = a.textContent;
		// var y = res[i].getElementsByClassName('accordion-body')[0];
		// var z = y.textContent;
		// c =  li[i].getElementsByClassName('filtertext');
		// x = res[i].getElementsByClassName('accordion-body');
		// resshow=res[i];
		// console.log(c);
		if(b.toString().indexOf(FilterValue) > -1){
			li[i].style.display = "";
		} else{
			li[i].style.display = "none";
		}
	}
}

function filterListado(){
	
	console.log('hola');
	var FilterValue, input, ul, li, i, res;

	input = document.getElementById('searchListado');
	FilterValue = input.value;
	ul = document.getElementById('tbody-listado_asegurados');
	li = ul.getElementsByTagName('tr');

	for(i=0;i<li.length;i++){
		var a = li[i].getElementsByClassName('tr-td-certificado-listado_asegurados')[0];
		var b = a.textContent;
		console.log(b);

		// var b = a.textContent;
		// var y = res[i].getElementsByClassName('accordion-body')[0];
		// var z = y.textContent;
		// c =  li[i].getElementsByClassName('filtertext');
		// x = res[i].getElementsByClassName('accordion-body');
		// resshow=res[i];
		// console.log(c);
		if(b.toString().indexOf(FilterValue) > -1){
			li[i].style.display = "";
		} else{
			li[i].style.display = "none";
		}
	}
}

