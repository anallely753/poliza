// CAROUSEL BLOG
jQuery(document).ready(function() {

    $('#carousel-example').on('slide.bs.carousel', function (e) {

        var $e = $(e.relatedTarget);
        var idx = $e.index();
        var itemsPerSlide = 5;
        var totalItems = $('.carousel-item').length;
        
        if (idx >= totalItems-(itemsPerSlide-1)) {
            var it = itemsPerSlide - (totalItems - idx);
            for (var i=0; i<it; i++) {
                // append slides to end
                if (e.direction=="left") {
                    $('.carousel-item').eq(i).appendTo('.carousel-inner');
                }
                else {
                    $('.carousel-item').eq(0).appendTo('.carousel-inner');
                }
            }
        }
    });
    
});

// Get cards
var cards = $('.card-body');
var maxHeight = 0;

// Loop all cards and check height, if bigger than max then save it
for (var i = 0; i < cards.length; i++) {
  if (maxHeight < $(cards[i]).outerHeight()) {
    maxHeight = $(cards[i]).outerHeight();
  }
}
// Set ALL card bodies to this height
for (var i = 0; i < cards.length; i++) {
  $(cards[i]).height(maxHeight);
}



var soundbutton = document.getElementById("sound-button");
    var playbutton = document.getElementById("play-button");
    var videobanner = document.getElementById('banner');

   document.getElementById('popup_close').onclick = function () {
       document.getElementById('banner').autoplay = true;
       document.getElementById('banner').play();
        document.getElementById('play-img').src='images/xdata/pause-button.png';

       // console.log('hola');
    }
    document.getElementById('omitir').onclick = function () {
       document.getElementById('banner').autoplay = true;
       document.getElementById('banner').play();
        document.getElementById('play-img').src='images/xdata/pause-button.png';

       // console.log('hola');
    }

    document.getElementById('playbutton').onclick = function () {
        if(videobanner.paused){
          document.getElementById('banner').autoplay = true;
          document.getElementById('banner').play();
          document.getElementById('play-img').src='images/xdata/pause-button.png';
        } else {
          videobanner.pause();
          document.getElementById('play-img').src='images/xdata/play-button.png';
        }
    };
    document.getElementById('soundbutton').onclick = function () {
        if(videobanner.muted == true){
          videobanner.muted = false;
          document.getElementById('sound-img').src='images/xdata/sound-on.svg';
        } else {
          videobanner.muted = true;
          ismuted=true;
          document.getElementById('sound-img').src='images/xdata/sound-off.svg';
        }
    };
   
      function disableMute() { 
        vid.muted = false;
      } 

      function checkMute() { 
        alert(vid.muted);
      } 

$(window).on("load", function () {
    "use strict";
    $(".loader").fadeOut(200);
    $('.side-menu').removeClass('opacity-0');
});


$(document).ready(function(){
        // Video sonido
       var vid = document.getElementById("video1");

          function mute() { 
            vid.muted = true;
          } 
        // Modal 
        $( ".accordionflecha" ).click(function() {
            alert('Hola');
            if (  $( this ).css( "transform" ) == 'none' ){
                $(this).css("transform","rotate(45deg)");
            } else {
                $(this).css("transform","" );
            }
        });

        $("#exampleModal").modal('show');
        let navbartoggle = $("#navbar-toggle");
        sideMenuToggle.on("click", function () {
            $("body").addClass("overflow-hidden");
            sideMenu.addClass("side-menu-active");
            $(function () {
                setTimeout(function () {
                    $("#close_side_menu").fadeIn(300);
                }, 300);
            });
        });

        // Mailchimp

        
        ajaxMailChimpForm($("#mc-embedded-subscribe-form"), $("#subscribe-result"));
        function ajaxMailChimpForm($form, $resultElement){
            $form.submit(function(e) {
                e.preventDefault();

                if (!isValidEmail($form)) {
                    var error =  "Ingresa una dirección de e-mail válida";
                    $resultElement.html(error);
                    $resultElement.css("color", "#12424f");
                    $resultElement.css("font-size", ".8rem");
                } else {
                    submitSubscribeForm($form, $resultElement);
                }
            });
        }

        // Validate the email address in the form
        function isValidEmail($form) {
            // If email is empty, show error message.
            // contains just one @
            var email = $form.find("input[type='email']").val();
            if (!email || !email.length) {
                return false;
            } else if (email.indexOf("@") == -1) {
                return false;
            }

            return true;
        }

        // Submit the form with an ajax/jsonp request.
        // Based on http://stackoverflow.com/a/15120409/215821
        function submitSubscribeForm($form, $resultElement) {
            $.ajax({
                type: "GET",
                url: $form.attr("action"),
                data: $form.serialize(),
                cache: false,
                dataType: "jsonp",
                jsonp: "c", // trigger MailChimp to return a JSONP response
                contentType: "application/json; charset=utf-8",

                error: function(error){
                    // According to jquery docs, this is never called for cross-domain JSONP requests
                },

                success: function(data){
                    if (data.result != "success") {
                        var message = data.msg || "Disculpa, no pudimos subscribirte. Intenta más tarde.";
                        $resultElement.css("color", "#12424f");
                        $resultElement.css("font-size", ".8rem");

                        if (data.msg && data.msg.indexOf("Ya estás suscrito") >= 0) {
                            message = "Ya estás suscrito. ¡Gracias!";
                            $resultElement.css("color", "#12424f");
                            $resultElement.css("font-size", ".8rem");
                        }

                        $resultElement.html(message);

                    } else {
                        $('#popup').removeClass('popup').addClass('popupsuc');
                        $("#popup_close").attr("src", "images/xdata/close_blanco.png");
                        $("#popup_logo").attr("src", "images/xdata/logo60blanco.png");
                        $('#popup .modal-content').css('background-color', '#12424f');
                        $('#popup_h3').html('<h3 class="defaultcolor text-center font-bold px-2 mx-0 mt-3 mb-2 px-sm-4 mx-sm-0 mt-5 mb-sm-3 popuph3 mb-sm-4"   id="titicon">¡GRACIAS POR <span id="bgblue" style="background-color: #86e1d0;color: #12424f; padding: 4px;">UNIRTE A LA COMUNIDAD</span> DE <span style="white-space: nowrap; ">X-DATA!</span></h3>');
                        $("#mc-embedded-subscribe-form").remove();
                        $("#popupp").text("Ahora recibirás las actualizaciones de nuestro blog e información privilegiada sobre nuestros lanzamientos y eventos especiales");

                        // $('#popup_div').removeClass('p-4');
                        // $('#popup_div').addClass('p-md-4');
                        // $('#popup_div').addClass('p-lg-2');
                        // $('#popup_div').addClass('p-0');
                        // $("#popup_close").attr("src", "images/xdata/close_blanco.png");
                        // $("#popup_h3").html('<h3 class="defaultcolor text-center font-bold px-1 mx-2 mt-3 mb-2 px-sm-4 mx-sm-2 mt-5 mt-lg-4 mx-lg-0 px-lg-1 mb-sm-3 mb-sm-4 mb-lg-2"   id="titicon" style="color:white;">¡GRACIAS POR <span style="background-color: #86e1d0;color: #12424f; padding: 4px;">UNIRTE A LA COMUNIDAD</span> DE <span style="white-space: nowrap;">X-DATA!</span></h3>');
                        // $("#popup_h3").addClass('popuph3');
                        // $("#mc-embedded-subscribe-form").remove();
                        // $("#popupp").html('<p class="popupp text-center mt-4 mt-sm-5">Ahora recibirás las actualizaciones de nuestro blog e información privilegiada sobre nuestros lanzamientos y eventos especiales</p>');
                        
                        // $("#popup_logo").attr("src", "images/xdata/logo60blanco.png");

                    }
                }
            });
        }
});

jQuery($=> {
	/*Menu Onclick*/
	let sideMenuToggle = $("#sidemenu_toggle");
	let sideMenu = $(".side-menu");
	if (sideMenuToggle.length) {
	    sideMenuToggle.on("click", function () {
	        $("body").addClass("overflow-hidden");
	        sideMenu.addClass("side-menu-active");
	        $(function () {
	            setTimeout(function () {
	                $("#close_side_menu").fadeIn(300);
	            }, 300);
	        });
	    });
	    $("#close_side_menu , #btn_sideNavClose , .side-nav .nav-link.pagescroll").on("click", function () {
	        $("body").removeClass("overflow-hidden");
	        sideMenu.removeClass("side-menu-active");
	        $("#close_side_menu").fadeOut(200);
	        $(() => {
	            setTimeout(() => {
	                $('.sideNavPages').removeClass('show');
	                $('.fas').removeClass('rotate-180');
	            }, 400);
	        });
	    });
	    $(document).keyup(e => {
	        if (e.keyCode === 27) { // escape key maps to keycode `27`
	            if (sideMenu.hasClass("side-menu-active")) {
	                $("body").removeClass("overflow-hidden");
	                sideMenu.removeClass("side-menu-active");
	                $("#close_side_menu").fadeOut(200);
	                $tooltip.tooltipster('close');
	                $(() => {
	                    setTimeout(()=> {
	                        $('.sideNavPages').removeClass('show');
	                        $('.fas').removeClass('rotate-180');
	                    }, 400);
	                });
	            }
	        }
	    });
	}

	/*
	 * Side menu collapse opener
	 * */
	$(".collapsePagesSideMenu").on('click', function () {
	    $(this).children().toggleClass("rotate-180");
	});
});
