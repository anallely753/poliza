@extends('layouts.app')

@section('content')
<!--PreLoader style.css-->
  <div class="loader">
    <div class="loader-inner">
      <div class="cssload-loader"></div>
    </div>
  </div>
  <!--PreLoader Ends-->



<main class="main-inter">
  <h1 class="main-inter_h1">Interprotección</h1>
  <section class="container inter-main_table">
    <table class="table table-hover">
      <thead>
        <tr>
          <th scope="col">No. de Poliza</th>
          <th scope="col">Aciertos</th>
          <th></th>
        </tr>
      </thead>
      <tbody>
        @foreach($numPolizas as $numPoliza)
        <tr>
          <th scope="row">{{$numPoliza->noPoliza}}</th>
          <td>11</td>
          <td><a class="table-td_hover" href="{{ route('coincidencias.show', $numPoliza->noPoliza) }}">Ver detalles</a></td>
        </tr>
        @endforeach
      </tbody>
    </table>
  </section>

</main>
@endsection
