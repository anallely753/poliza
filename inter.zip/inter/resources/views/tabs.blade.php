@extends('layouts.app')

@section('content')

  <div class="body-tabs_inter">
    <main class="main-inter">
     <section class="container-fluid tabs-inter">
      <div class="main-inter_header">
        <!-- Flex header -->
       <div class="main-inter_flex">
         <div class="main-inter_header_titulos">
           <h4>No. Poliza</h4>
           <h3 class="main-inter_h3">{{$noPoliza}}</h3>
         </div>
          <div>
            <a href="{{ url('/') }}" class="ver-tabla ">Ver tabla general</a>
            <img src="{{asset('img/logos-tabs.svg')}}" alt="">
          </div>
       </div>

       {{-- Prueba --}}
       <div class="tab-content d-none">
          {{-- Carátula --}}
            <div class="tab-pane fade show active" >
              {{-- Carátula / Datos --}}
              <div class="table-title">Datos</div>
              <table class="table table-hover table-responsive ">
                <thead>
                  <tr class="fixed-table">
                    {{-- <th scope="col">Poliza</th> --}}
                    <th scope="col">Pagina</th>
                    <th scope="col">Plazo</th>
                    <th scope="col">Forma de Pago</th>
                    <th scope="col">Contributorio</th>
                    <th scope="col">Inicio Vigencia</th>
                    <th scope="col">Fin Vigencia</th>
                    <th scope="col">Tipo de Administracion</th>
                    <th scope="col">Datos del contratante</th>
                    <th scope="col">Prima Neta</th>
                    <th scope="col">Recargos</th>
                    <th scope="col">Gastos expedición</th>
                    <th scope="col">IVA</th>
                    <th scope="col">Prima Total</th>
                    <th scope="col">Moneda</th>
                    <span class="d-none">{{$numColumnas=13}}</span>
                  </tr>
                </thead>
                <tbody>
                  @foreach($caratula_datos as $caratula_dato)
                  <tr>
                    {{-- <th scope="row">{{$caratula_dato->noPoliza}}</th> --}}
                    <td>{{$caratula_dato->pagina}}</td>
                    <td>
                      @if($caratula_dato->plazo == 1)
                      <div class="checkdiv"><input disabled checked type="checkbox" class="le-checkbox"/></div>
                      <span class="d-none">{{$numAciertos++}}</span>
                      @elseif($caratula_dato->plazo == 0)
                      <div class="checkdiv"><input disabled  type="checkbox" class="le-checkbox"/></div>
                      @else
                      <img src="{{ asset('img/unknown.png') }}" alt="" width="32">
                      @endif
                    </td>
                    <td>
                      @if($caratula_dato->formaDePago == 1)
                      <span class="d-none">{{$numAciertos++}}</span>
                      <div class="checkdiv"><input disabled checked type="checkbox" class="le-checkbox"/></div>
                      @elseif($caratula_dato->formaDePago == 0)
                      <div class="checkdiv"><input disabled  type="checkbox" class="le-checkbox"/></div>
                      @else
                      <img src="{{ asset('img/unknown.png') }}" alt="" width="32">
                      @endif
                    </td>
                    <td>
                      @if($caratula_dato->contributorio == 1)
                      <span class="d-none">{{$numAciertos++}}</span>
                      <div class="checkdiv"><input disabled checked type="checkbox" class="le-checkbox"/></div>
                      @elseif($caratula_dato->contributorio == 0)
                      <div class="checkdiv"><input disabled  type="checkbox" class="le-checkbox"/></div>
                      @else
                      <img src="{{ asset('img/unknown.png') }}" alt="" width="32">
                      @endif
                    </td>
                    <td>
                      @if($caratula_dato->inicioVigencia == 1)
                      <span class="d-none">{{$numAciertos++}}</span>
                      <div class="checkdiv"><input disabled checked type="checkbox" class="le-checkbox"/></div>
                      @elseif($caratula_dato->inicioVigencia == 0)
                      <div class="checkdiv"><input disabled  type="checkbox" class="le-checkbox"/></div>
                      @else
                      <img src="{{ asset('img/unknown.png') }}" alt="" width="32">
                      @endif
                    </td>
                    <td>
                      @if($caratula_dato->finVigencia == 1)
                      <span class="d-none">{{$numAciertos++}}</span>
                      <div class="checkdiv"><input disabled checked type="checkbox" class="le-checkbox"/></div>
                      @elseif($caratula_dato->finVigencia == 0)
                      <div class="checkdiv"><input disabled  type="checkbox" class="le-checkbox"/></div>
                      @else
                      <img src="{{ asset('img/unknown.png') }}" alt="" width="32">
                      @endif
                    </td>
                    <td>
                      @if($caratula_dato->tipoDeAdministracion == 1)
                      <span class="d-none">{{$numAciertos++}}</span>
                      <div class="checkdiv"><input disabled checked type="checkbox" class="le-checkbox"/></div>
                      @elseif($caratula_dato->tipoDeAdministracion == 0)
                      <div class="checkdiv"><input disabled  type="checkbox" class="le-checkbox"/></div>
                      @else
                      <img src="{{ asset('img/unknown.png') }}" alt="" width="32">
                      @endif
                    </td>
                    <td>
                      @if($caratula_dato->datosDelContratante == 1)
                      <span class="d-none">{{$numAciertos++}}</span>
                      <div class="checkdiv"><input disabled checked type="checkbox" class="le-checkbox"/></div>
                      @elseif($caratula_dato->datosDelContratante == 0)
                      <div class="checkdiv"><input disabled  type="checkbox" class="le-checkbox"/></div>
                      @else
                      <img src="{{ asset('img/unknown.png') }}" alt="" width="32">
                      @endif
                    </td>
                    <td>
                      @if($caratula_dato->primaNeta == 1)
                      <span class="d-none">{{$numAciertos++}}</span>
                      <div class="checkdiv"><input disabled checked type="checkbox" class="le-checkbox"/></div>
                      @elseif($caratula_dato->primaNeta == 0)
                      <div class="checkdiv"><input disabled  type="checkbox" class="le-checkbox"/></div>
                      @else
                      <img src="{{ asset('img/unknown.png') }}" alt="" width="32">
                      @endif
                    </td>
                    <td>
                      @if($caratula_dato->recargos == 1)
                      <span class="d-none">{{$numAciertos++}}</span>
                      <div class="checkdiv"><input disabled checked type="checkbox" class="le-checkbox"/></div>
                      @elseif($caratula_dato->recargos == 0)
                      <div class="checkdiv"><input disabled  type="checkbox" class="le-checkbox"/></div>
                      @else
                      <img src="{{ asset('img/unknown.png') }}" alt="" width="32">
                      @endif
                    </td>
                    <td>
                      @if($caratula_dato->gtosExpedicion == 1)
                      <span class="d-none">{{$numAciertos++}}</span>
                      <div class="checkdiv"><input disabled checked type="checkbox" class="le-checkbox"/></div>
                      @elseif($caratula_dato->gtosExpedicion == 0)
                      <div class="checkdiv"><input disabled  type="checkbox" class="le-checkbox"/></div>
                      @else
                      <img src="{{ asset('img/unknown.png') }}" alt="" width="32">
                      @endif
                    </td>
                    <td>
                      @if($caratula_dato->IVA == 1)
                      <span class="d-none">{{$numAciertos++}}</span>
                      <div class="checkdiv"><input disabled checked type="checkbox" class="le-checkbox"/></div>
                      @elseif($caratula_dato->IVA == 0)
                      <div class="checkdiv"><input disabled  type="checkbox" class="le-checkbox"/></div>
                      @else
                      <img src="{{ asset('img/unknown.png') }}" alt="" width="32">
                      @endif
                    </td>
                    <td>
                      @if($caratula_dato->primaTotal == 1)
                      <span class="d-none">{{$numAciertos++}}</span>
                      <div class="checkdiv"><input disabled checked type="checkbox" class="le-checkbox"/></div>
                      @elseif($caratula_dato->primaTotal == 0)
                      <div class="checkdiv"><input disabled  type="checkbox" class="le-checkbox"/></div>
                      @else
                      <img src="{{ asset('img/unknown.png') }}" alt="" width="32">
                      @endif
                    </td>
                    <td>
                      @if($caratula_dato->moneda == 1)
                      <span class="d-none">{{$numAciertos++}}</span>
                      <div class="checkdiv"><input disabled checked type="checkbox" class="le-checkbox"/></div>
                      @elseif($caratula_dato->moneda == 0)
                      <div class="checkdiv"><input disabled  type="checkbox" class="le-checkbox"/></div>
                      @else
                      <img src="{{ asset('img/unknown.png') }}" alt="" width="32">
                      @endif
                    </td>
                  </tr>
                  <span class="d-none">{{ $contador++ }}</span>
                  @endforeach
                  <div class="btn-success d-none">Aciertos Datos= {{$numAciertos}}/{{ $numColumnas*$contador}}</div>
                </tbody>
              </table>
              {{-- Guardar datos de tabla 1 --}}
              <span class="d-none">{{$guardarAciertos=$numAciertos, $guardarColumnas=$numColumnas*$contador}}</span>
             {{--  {{$guardarAciertos}}
              {{$guardarColumnas}} --}}
              {{-- Carátula / Coberturas --}}
              <div class="table-title">Coberturas</div>
              <span class="d-none">{{$numAciertos=0, $numColumnas=0, $contador=0}}</span>
              <table class="table table-hover  table-responsive ">
                <thead>
                  <tr class="fixed-table">
                    {{-- <th scope="col">Poliza</th> --}}
                    <th scope="col">Pagina</th>
                    <th scope="col">Cobertura</th>
                    <th scope="col">Suma Asegurada</th>
                    <th scope="col">Prima Neta</th>
                    <span class="d-none">{{$numColumnas=2}}</span>
                  </tr>
                </thead>
                  {{-- <span class="d-none">{{ $caratulaI=0 }}</span> --}}
                <tbody>
                  @foreach($caratula_coberturas as $caratula_cobertura)
                  <tr>
                    {{-- <th scope="row">{{$caratula_dato->noPoliza}}</th> --}}
                    <td>{{$caratula_cobertura->pagina}}</td>
                    <td>
                      {{$caratula_cobertura->cobertura}}
                    </td>
                    <td>
                      @if($caratula_cobertura->sumaAsegurada == 1)
                      <div class="checkdiv"><input disabled checked type="checkbox" class="le-checkbox"/></div>
                      <span class="d-none">{{$numAciertos++}}</span>

                      @elseif($caratula_cobertura->sumaAsegurada == 0)
                      <div class="checkdiv"><input disabled  type="checkbox" class="le-checkbox"/></div>
                      @else
                      <img src="{{ asset('img/unknown.png') }}" alt="" width="32">
                      @endif
                    </td>
                    <td>
                      @if($caratula_cobertura->primaNeta == 1)
                      <span class="d-none">{{$numAciertos++}}</span>
                      <div class="checkdiv"><input disabled checked type="checkbox" class="le-checkbox"/></div>
                      @elseif($caratula_cobertura->primaNeta == 0)
                      <div class="checkdiv"><input disabled  type="checkbox" class="le-checkbox"/></div>
                      @else
                      <img src="{{ asset('img/unknown.png') }}" alt="" width="32">
                      @endif
                    </td>
                  </tr>
                  <span class="d-none">{{ $contador++ }}</span>
                  @endforeach
                  <div class="btn-success d-none">Aciertos Coberturas = {{$numAciertos}}/{{ $numColumnas*$contador}}</div>
                </tbody>
              </table>
              <span class="d-none">{{$guardarAciertos=$guardarAciertos+$numAciertos, $guardarColumnas=$guardarColumnas+($numColumnas*$contador)}}</span>

              {{-- Datos finales --}}
              <div class="btn-success d-none position-absolute">{{$caratulaA = $guardarAciertos}}/{{$caratulaC = $guardarColumnas}}</div>

                 {{--  <div class="btn-success">{{$caratulaVD+$caratulaVC}}/{{ $caratulaNumC*$caratulaI+$caratulaNumD*$caratulaI}}</div> --}}
            </div>

          {{-- Consentimientos --}}
            <div class="tab-pane fade" >
              <form class="d-flex w-25" id="searchform" onkeyup="filterConsentimientos()">
                <input class="form-control me-2 d-flex shadow-none" type="text" placeholder="No. de certificado" id="searchConsentimientos">
                <button type="submit" disabled><img src="{{asset('img/search.svg')}}"  alt="" ></button/>
              </form>
              <span class="d-none">{{$numAciertos=0, $contador=0}}</span>
              <table class="table table-hover table-responsive ">
                <thead>
                  <tr class="fixed-table">
                    {{-- <th scope="col">Poliza</th> --}}
                    <th scope="col">Certificado</th>
                    <th scope="col">Nombre</th>
                    <th scope="col">Sexo</th>
                    <th scope="col">Edad</th>
                    <th scope="col">Fecha de Nacimiento</th>
                    <th scope="col">Datos del contratante</th>
                    <th scope="col">Plazo</th>
                    <th scope="col">Forma de Pago</th>
                    <th scope="col">Contributorio</th>
                    <th scope="col">Inicio Vigencia</th>
                    <th scope="col">Fin Vigencia</th>
                    <th scope="col">Moneda</th>
                    <span class="d-none">{{$numColumnas=11}}</span>
                  </tr>
                </thead>
                <tbody id="tbody-consentimientos_vida_datos">
                  @foreach($consentimientos_vida_datos as $consentimientos_vida_dato)
                  <tr class="tr-consentimientos_vida_datos">
                    <td class="tr-td-certificado-consentimientos_vida_datos">{{$consentimientos_vida_dato->certificado}}</td>
                    <td>
                      @if($consentimientos_vida_dato->nombre == 1)
                      <span class="d-none">{{$numAciertos++}}</span>
                      <div class="checkdiv"><input disabled checked type="checkbox" class="le-checkbox"/></div>
                      @elseif($consentimientos_vida_dato->nombre == 0)
                      <div class="checkdiv"><input disabled  type="checkbox" class="le-checkbox"/></div>
                      @else
                      <img src="{{ asset('img/unknown.png') }}" alt="" width="32">
                      @endif
                    </td>
                    <td>
                      @if($consentimientos_vida_dato->sexo == 1)
                      <span class="d-none">{{$numAciertos++}}</span>
                      <div class="checkdiv"><input disabled checked type="checkbox" class="le-checkbox"/></div>
                      @elseif($consentimientos_vida_dato->nombre == 0)
                      <div class="checkdiv"><input disabled  type="checkbox" class="le-checkbox"/></div>
                      @else
                      <img src="{{ asset('img/unknown.png') }}" alt="" width="32">
                      @endif
                    </td>
                    <td>
                      @if($consentimientos_vida_dato->edad == 1)
                      <span class="d-none">{{$numAciertos++}}</span>
                      <div class="checkdiv"><input disabled checked type="checkbox" class="le-checkbox"/></div>
                      @elseif($consentimientos_vida_dato->edad == 0)
                      <div class="checkdiv"><input disabled  type="checkbox" class="le-checkbox"/></div>
                      @else
                      <img src="{{ asset('img/unknown.png') }}" alt="" width="32">
                      @endif
                    </td>
                    <td>
                      @if($consentimientos_vida_dato->fechaDeNacimiento == 1)
                      <span class="d-none">{{$numAciertos++}}</span>
                      <div class="checkdiv"><input disabled checked type="checkbox" class="le-checkbox"/></div>
                      @elseif($consentimientos_vida_dato->fechaDeNacimiento == 0)
                      <div class="checkdiv"><input disabled  type="checkbox" class="le-checkbox"/></div>
                      @else
                      <img src="{{ asset('img/unknown.png') }}" alt="" width="32">
                      @endif
                    </td>
                    <td>
                      @if($consentimientos_vida_dato->datosDelContratante == 1)
                      <span class="d-none">{{$numAciertos++}}</span>
                      <div class="checkdiv"><input disabled checked type="checkbox" class="le-checkbox"/></div>
                      @elseif($consentimientos_vida_dato->datosDelContratante == 0)
                      <div class="checkdiv"><input disabled  type="checkbox" class="le-checkbox"/></div>
                      @else
                      <img src="{{ asset('img/unknown.png') }}" alt="" width="32">
                      @endif
                    </td>
                    <td>
                      @if($consentimientos_vida_dato->plazo == 1)
                      <span class="d-none">{{$numAciertos++}}</span>
                      <div class="checkdiv"><input disabled checked type="checkbox" class="le-checkbox"/></div>
                      @elseif($consentimientos_vida_dato->plazo == 0)
                      <div class="checkdiv"><input disabled  type="checkbox" class="le-checkbox"/></div>
                      @else
                      <img src="{{ asset('img/unknown.png') }}" alt="" width="32">
                      @endif
                    </td>
                    <td>
                      @if($consentimientos_vida_dato->formaDePago == 1)
                      <span class="d-none">{{$numAciertos++}}</span>
                      <div class="checkdiv"><input disabled checked type="checkbox" class="le-checkbox"/></div>
                      @elseif($consentimientos_vida_dato->formaDePago == 0)
                      <div class="checkdiv"><input disabled  type="checkbox" class="le-checkbox"/></div>
                      @else
                      <img src="{{ asset('img/unknown.png') }}" alt="" width="32">
                      @endif
                    </td>
                    <td>
                      @if($consentimientos_vida_dato->contributorio == 1)
                      <span class="d-none">{{$numAciertos++}}</span>
                      <div class="checkdiv"><input disabled checked type="checkbox" class="le-checkbox"/></div>
                      @elseif($consentimientos_vida_dato->contributorio == 0)
                      <div class="checkdiv"><input disabled  type="checkbox" class="le-checkbox"/></div>
                      @else
                      <img src="{{ asset('img/unknown.png') }}" alt="" width="32">
                      @endif
                    </td>
                    <td>
                      @if($consentimientos_vida_dato->inicioVigencia == 1)
                      <span class="d-none">{{$numAciertos++}}</span>
                      <div class="checkdiv"><input disabled checked type="checkbox" class="le-checkbox"/></div>
                      @elseif($consentimientos_vida_dato->inicioVigencia == 0)
                      <div class="checkdiv"><input disabled  type="checkbox" class="le-checkbox"/></div>
                      @else
                      <img src="{{ asset('img/unknown.png') }}" alt="" width="32">
                      @endif
                    </td>
                    <td>
                      @if($consentimientos_vida_dato->finVigencia == 1)
                      <span class="d-none">{{$numAciertos++}}</span>
                      <div class="checkdiv"><input disabled checked type="checkbox" class="le-checkbox"/></div>
                      @elseif($consentimientos_vida_dato->finVigencia == 0)
                      <div class="checkdiv"><input disabled  type="checkbox" class="le-checkbox"/></div>
                      @else
                      <img src="{{ asset('img/unknown.png') }}" alt="" width="32">
                      @endif
                    </td>
                    <td>
                      @if($consentimientos_vida_dato->moneda == 1)
                      <span class="d-none">{{$numAciertos++}}</span>
                      <div class="checkdiv"><input disabled checked type="checkbox" class="le-checkbox"/></div>
                      @elseif($consentimientos_vida_dato->moneda == 0)
                      <div class="checkdiv"><input disabled  type="checkbox" class="le-checkbox"/></div>
                      @else
                      <img src="{{ asset('img/unknown.png') }}" alt="" width="32">
                      @endif
                    </td>
                    <span class="d-none">{{$contador++}}</span>
                  </tr>
                    {{-- <span class="d-none">{{}}</span> --}}
                  @endforeach
                  <div class="btn-success d-none">Aciertos Coberturas = {{$conA=$numAciertos}}/{{ $conC = $numColumnas*$contador}}</div>

                </tbody>
              </table>
            </div>

          {{-- Detalle coberturas --}}
            <div class="tab-pane fade" >
              {{-- Detalle coberturas / Datos --}}
              <div class="table-title">Datos</div>
              <span class="d-none">{{$numAciertos=0, $contador=0}}</span>
              <table class="table table-hover table-responsive">
                <thead>
                  <tr class="fixed-table">
                    {{-- <th scope="col">Poliza</th> --}}
                    <th scope="col">Pagina</th>
                    <th scope="col">Plazo</th>
                    <th scope="col">Forma de Pago</th>
                    <th scope="col">Contributorio</th>
                    <th scope="col">Inicio Vigencia</th>
                    <th scope="col">Fin Vigencia</th>
                    <th scope="col">Asegurados</th>
                    <th scope="col">Datos del contratante</th>
                    <th scope="col">Prima Neta</th>
                    <th scope="col">Recargos</th>
                    <th scope="col">Gastos expedición</th>
                    <th scope="col">IVA</th>
                    <th scope="col">Prima Total</th>
                    <th scope="col">Moneda</th>
                    <span class="d-none">{{$numColumnas=13}}</span>
                  </tr>
                </thead>
                <tbody>
                  @foreach($detalle_cobertura_datos as $detalle_cobertura_dato)
                  <tr>
                    {{-- <th scope="row">{{$detalle_cobertura_dato->noPoliza}}</th> --}}
                    <td>{{$detalle_cobertura_dato->pagina}}</td>
                    <td>
                      @if($detalle_cobertura_dato->plazo == 1)
                      <div class="checkdiv"><input disabled checked type="checkbox" class="le-checkbox"/></div>
                      <span class="d-none">{{$numAciertos++}}</span>
                      @elseif($detalle_cobertura_dato->plazo == 0)
                      <div class="checkdiv"><input disabled  type="checkbox" class="le-checkbox"/></div>
                      @else
                      <img src="{{ asset('img/unknown.png') }}" alt="" width="32">
                      @endif
                    </td>
                    <td>
                      @if($detalle_cobertura_dato->formaDePago == 1)
                      <span class="d-none">{{$numAciertos++}}</span>
                      <div class="checkdiv"><input disabled checked type="checkbox" class="le-checkbox"/></div>
                      @elseif($detalle_cobertura_dato->formaDePago == 0)
                      <div class="checkdiv"><input disabled  type="checkbox" class="le-checkbox"/></div>
                      @else
                      <img src="{{ asset('img/unknown.png') }}" alt="" width="32">
                      @endif
                    </td>
                    <td>
                      @if($detalle_cobertura_dato->contributorio == 1)
                      <span class="d-none">{{$numAciertos++}}</span>
                      <div class="checkdiv"><input disabled checked type="checkbox" class="le-checkbox"/></div>
                      @elseif($detalle_cobertura_dato->contributorio == 0)
                      <div class="checkdiv"><input disabled  type="checkbox" class="le-checkbox"/></div>
                      @else
                      <img src="{{ asset('img/unknown.png') }}" alt="" width="32">
                      @endif
                    </td>
                    <td>
                      @if($detalle_cobertura_dato->inicioVigencia == 1)
                      <span class="d-none">{{$numAciertos++}}</span>
                      <div class="checkdiv"><input disabled checked type="checkbox" class="le-checkbox"/></div>
                      @elseif($detalle_cobertura_dato->inicioVigencia == 0)
                      <div class="checkdiv"><input disabled  type="checkbox" class="le-checkbox"/></div>
                      @else
                      <img src="{{ asset('img/unknown.png') }}" alt="" width="32">
                      @endif
                    </td>
                    <td>
                      @if($detalle_cobertura_dato->finVigencia == 1)
                      <span class="d-none">{{$numAciertos++}}</span>
                      <div class="checkdiv"><input disabled checked type="checkbox" class="le-checkbox"/></div>
                      @elseif($detalle_cobertura_dato->finVigencia == 0)
                      <div class="checkdiv"><input disabled  type="checkbox" class="le-checkbox"/></div>
                      @else
                      <img src="{{ asset('img/unknown.png') }}" alt="" width="32">
                      @endif
                    </td>
                    <td>
                      @if($detalle_cobertura_dato->asegurados == 1)
                      <span class="d-none">{{$numAciertos++}}</span>
                      <div class="checkdiv"><input disabled checked type="checkbox" class="le-checkbox"/></div>
                      @elseif($detalle_cobertura_dato->asegurados == 0)
                      <div class="checkdiv"><input disabled  type="checkbox" class="le-checkbox"/></div>
                      @else
                      <img src="{{ asset('img/unknown.png') }}" alt="" width="32">
                      @endif
                    </td>
                    <td>
                      @if($detalle_cobertura_dato->datosDelContratante == 1)
                      <span class="d-none">{{$numAciertos++}}</span>
                      <div class="checkdiv"><input disabled checked type="checkbox" class="le-checkbox"/></div>
                      @elseif($detalle_cobertura_dato->datosDelContratante == 0)
                      <div class="checkdiv"><input disabled  type="checkbox" class="le-checkbox"/></div>
                      @else
                      <img src="{{ asset('img/unknown.png') }}" alt="" width="32">
                      @endif
                    </td>
                    <td>
                      @if($detalle_cobertura_dato->primaNeta == 1)
                      <span class="d-none">{{$numAciertos++}}</span>
                      <div class="checkdiv"><input disabled checked type="checkbox" class="le-checkbox"/></div>
                      @elseif($detalle_cobertura_dato->primaNeta == 0)
                      <div class="checkdiv"><input disabled  type="checkbox" class="le-checkbox"/></div>
                      @else
                      <img src="{{ asset('img/unknown.png') }}" alt="" width="32">
                      @endif
                    </td>
                    <td>
                      @if($detalle_cobertura_dato->recargos == 1)
                      <span class="d-none">{{$numAciertos++}}</span>
                      <div class="checkdiv"><input disabled checked type="checkbox" class="le-checkbox"/></div>
                      @elseif($detalle_cobertura_dato->recargos == 0)
                      <div class="checkdiv"><input disabled  type="checkbox" class="le-checkbox"/></div>
                      @else
                      <img src="{{ asset('img/unknown.png') }}" alt="" width="32">
                      @endif
                    </td>
                    <td>
                      @if($detalle_cobertura_dato->gtosExpedicion == 1)
                      <span class="d-none">{{$numAciertos++}}</span>
                      <div class="checkdiv"><input disabled checked type="checkbox" class="le-checkbox"/></div>
                      @elseif($detalle_cobertura_dato->gtosExpedicion == 0)
                      <div class="checkdiv"><input disabled  type="checkbox" class="le-checkbox"/></div>
                      @else
                      <img src="{{ asset('img/unknown.png') }}" alt="" width="32">
                      @endif
                    </td>
                    <td>
                      @if($detalle_cobertura_dato->IVA == 1)
                      <span class="d-none">{{$numAciertos++}}</span>
                      <div class="checkdiv"><input disabled checked type="checkbox" class="le-checkbox"/></div>
                      @elseif($detalle_cobertura_dato->IVA == 0)
                      <div class="checkdiv"><input disabled  type="checkbox" class="le-checkbox"/></div>
                      @else
                      <img src="{{ asset('img/unknown.png') }}" alt="" width="32">
                      @endif
                    </td>
                    <td>
                      @if($detalle_cobertura_dato->primaTotal == 1)
                      <span class="d-none">{{$numAciertos++}}</span>
                      <div class="checkdiv"><input disabled checked type="checkbox" class="le-checkbox"/></div>
                      @elseif($detalle_cobertura_dato->primaTotal == 0)
                      <div class="checkdiv"><input disabled  type="checkbox" class="le-checkbox"/></div>
                      @else
                      <img src="{{ asset('img/unknown.png') }}" alt="" width="32">
                      @endif
                    </td>
                    <td>
                      @if($detalle_cobertura_dato->moneda == 1)
                      <span class="d-none">{{$numAciertos++}}</span>
                      <div class="checkdiv"><input disabled checked type="checkbox" class="le-checkbox"/></div>
                      @elseif($detalle_cobertura_dato->moneda == 0)
                      <div class="checkdiv"><input disabled  type="checkbox" class="le-checkbox"/></div>
                      @else
                      <img src="{{ asset('img/unknown.png') }}" alt="" width="32">
                      @endif
                    </td>
                  </tr>
                  <span class="d-none">{{ $contador++ }}</span>
                  @endforeach
                  <div class="btn-success d-none">Aciertos Datos= {{$numAciertos}}/{{ $numColumnas*$contador}}</div>
                </tbody>
              </table>
              {{-- Guardar datos   --}}
              <span class="d-none">{{$guardarAciertos=$numAciertos, $guardarColumnas=$numColumnas*$contador}}</span>
              {{-- {{$guardarAciertos}}
              {{$guardarColumnas}} --}}
              {{-- Detalle coberturas / Coberturas --}}
              <div class="table-title">Datos</div>
              <span class="d-none">{{$numAciertos=0, $numColumnas=0, $contador=0}}</span>
              <table class="table table-hover  table-responsive ">
                <thead>
                  <tr class="fixed-table">
                    <th scope="col">Pagina</th>
                    <th scope="col">Cobertura</th>
                    <th scope="col">Prima Neta</th>
                    <span class="d-none">{{$numColumnas=1}}</span>
                  </tr>
                </thead>
                <tbody>
                  @foreach($detalle_cobertura_coberturas as $detalle_cobertura_cobertura)
                  <tr>
                    {{-- <th scope="row">{{$caratula_dato->noPoliza}}</th> --}}
                    <td>{{$detalle_cobertura_cobertura->pagina}}</td>
                    <td>
                      {{$detalle_cobertura_cobertura->cobertura}}
                    </td>
                    <td>
                      @if($detalle_cobertura_cobertura->primaNeta == 1)
                      <span class="d-none">{{$numAciertos++}}</span>
                      <div class="checkdiv"><input disabled checked type="checkbox" class="le-checkbox"/></div>
                      @elseif($detalle_cobertura_cobertura->primaNeta == 0)
                      <div class="checkdiv"><input disabled  type="checkbox" class="le-checkbox"/></div>
                      @else
                      <img src="{{ asset('img/unknown.png') }}" alt="" width="32">
                      @endif
                    </td>
                  </tr>
                  <span class="d-none">{{ $contador++ }}</span>
                  @endforeach
                  <div class="btn-success d-none">Aciertos Coberturas = {{$numAciertos}}/{{ $numColumnas*$contador}}</div>
                </tbody>
              </table>
              <span class="d-none">{{$guardarAciertos=$guardarAciertos+$numAciertos, $guardarColumnas=$guardarColumnas+($numColumnas*$contador)}}</span>

              {{-- Datos finales --}}
              <div class="btn-success d-none position-absolute">{{$DetA=$guardarAciertos}}/{{$DetC=$guardarColumnas}}</div>
            </div>

          {{-- Endosos especiales --}}
            <div class="tab-pane fade" >
              <span class="d-none">{{$numAciertos=0, $contador=0}}</span>
              <table class="table table-hover table-responsive">
                <thead>
                  <tr class="fixed-table">
                    {{-- <th scope="col">Poliza</th> --}}
                    <th scope="col">Subgrupo</th>
                    <th scope="col">Categoría</th>
                    <th scope="col">Endoso</th>
                    <th scope="col">Valor</th>
                    <span class="d-none">{{$numColumnas=1}}</span>
                  </tr>
                </thead>
                <tbody>
                  @foreach($endosos as $endoso)
                  <tr>
                    {{-- <th scope="row">{{$endoso->noPoliza}}</th> --}}
                    <td>{{$endoso->subgrupo}}</td>
                    <td>{{$endoso->categoria}}</td>
                    <td>{{$endoso->endoso}}</td>
                    <td>
                      @if($endoso->valorEndoso == 1)
                      <div class="checkdiv"><input disabled checked type="checkbox" class="le-checkbox"/></div>
                      <span class="d-none">{{$numAciertos++}}</span>
                      @elseif($endoso->valorEndoso == 0)
                      <div class="checkdiv"><input disabled  type="checkbox" class="le-checkbox"/></div>
                      @else
                      <img src="{{ asset('img/unknown.png') }}" alt="" width="32">
                      @endif
                    </td>
                    <span class="d-none">{{$contador++}}</span>
                  </tr>
                  @endforeach
                  <div class="btn-success d-none">Aciertos Coberturas = {{$EnA=$numAciertos}}/{{$EnC= $numColumnas*$contador}}</div>
                </tbody>
              </table>
            </div>

          {{-- Listado asegurados --}}
            <div class="tab-pane fade">
              <form class="d-flex w-25" id="searchform" onkeyup="filterListado()">
                <input class="form-control me-2 shadow-none" type="text" placeholder="No. de certificado" id="searchListado">
                <button type="submit" disabled><img src="{{asset('img/search.svg')}}"  alt="" ></button/>
                {{-- <button class="btn btn-outline-success" disabled type="submit">Search</button> --}}
              </form>
              {{-- <form class="d-flex w-25" id="searchform" onkeyup="filterListado()">
                <input class="form-control me-2 d-flex shadow-none" type="text" placeholder="No. de certificado" id="searchListado">
                <button type="submit" disabled><img src="{{asset('img/search.svg')}}"  alt="" ></button/>
              </form> --}}
              <span class="d-none">{{$numAciertos=0, $contador=0}}</span>

              <table class="table table-hover table-responsive ">
                <thead>
                  <tr class="fixed-table">
                    {{-- <th scope="col">Poliza</th> --}}
                    <th scope="col">Certificado</th>
                    <th scope="col">Subgrupo</th>
                    <th scope="col">Categoría</th>
                    <th scope="col">Nombre</th>
                    <th scope="col">Antiguedad</th>
                    <th scope="col">Edad</th>
                    <th scope="col">Sexo</th>
                    <th scope="col">Fecha Alta/Baja</th>
                    <span class="d-none">{{$numColumnas=6}}</span>
                  </tr>
                </thead>
                <tbody id="tbody-listado_asegurados">
                  @foreach($listado_asegurados as $listado_asegurado)
                  <tr>
                    {{-- <th scope="row">{{$listado_asegurado->noPoliza}}</th> --}}
                    <td class="tr-td-certificado-listado_asegurados">{{$listado_asegurado->certificado}}</td>
                    <td>{{$listado_asegurado->subgrupo}}</td>
                    <td>
                      @if($listado_asegurado->categoria == 1)
                      <span class="d-none">{{$numAciertos++}}</span>
                      <div class="checkdiv"><input disabled checked type="checkbox" class="le-checkbox"/></div>
                      @elseif($listado_asegurado->categoria == 0)
                      <div class="checkdiv"><input disabled  type="checkbox" class="le-checkbox"/></div>
                      @else
                      <img src="{{ asset('img/unknown.png') }}" alt="" width="32">
                      @endif
                    </td>
                    <td>
                      @if($listado_asegurado->nombre == 1)
                      <span class="d-none">{{$numAciertos++}}</span>
                      <div class="checkdiv"><input disabled checked type="checkbox" class="le-checkbox"/></div>
                      @elseif($listado_asegurado->nombre == 0)
                      <div class="checkdiv"><input disabled  type="checkbox" class="le-checkbox"/></div>
                      @else
                      <img src="{{ asset('img/unknown.png') }}" alt="" width="32">
                      @endif
                    </td>
                    <td>
                      @if($listado_asegurado->antiguedad == 1)
                      <span class="d-none">{{$numAciertos++}}</span>
                      <div class="checkdiv"><input disabled checked type="checkbox" class="le-checkbox"/></div>
                      @elseif($listado_asegurado->antiguedad == 0)
                      <div class="checkdiv"><input disabled  type="checkbox" class="le-checkbox"/></div>
                      @else
                      <img src="{{ asset('img/unknown.png') }}" alt="" width="32">
                      @endif
                    </td>
                    <td>
                      @if($listado_asegurado->edad == 1)
                      <span class="d-none">{{$numAciertos++}}</span>
                      <div class="checkdiv"><input disabled checked type="checkbox" class="le-checkbox"/></div>
                      @elseif($listado_asegurado->edad == 0)
                      <div class="checkdiv"><input disabled  type="checkbox" class="le-checkbox"/></div>
                      @else
                      <img src="{{ asset('img/unknown.png') }}" alt="" width="32">
                      @endif
                    </td>
                    <td>
                      @if($listado_asegurado->sexo == 1)
                      <span class="d-none">{{$numAciertos++}}</span>
                      <div class="checkdiv"><input disabled checked type="checkbox" class="le-checkbox"/></div>
                      @elseif($listado_asegurado->sexo == 0)
                      <div class="checkdiv"><input disabled  type="checkbox" class="le-checkbox"/></div>
                      @else
                      <img src="{{ asset('img/unknown.png') }}" alt="" width="32">
                      @endif
                    </td>
                    <td>
                      @if($listado_asegurado->fechaAltaBaja == 1)
                      <span class="d-none">{{$numAciertos++}}</span>
                      <div class="checkdiv"><input disabled checked type="checkbox" class="le-checkbox"/></div>
                      @elseif($listado_asegurado->fechaAltaBaja == 0)
                      <div class="checkdiv"><input disabled  type="checkbox" class="le-checkbox"/></div>
                      @else
                      <img src="{{ asset('img/unknown.png') }}" alt="" width="32">
                      @endif
                    </td>
                    <span class="d-none">{{$contador++}}</span>
                  </tr>
                  @endforeach
                  <div class="btn-success d-none">Aciertos Coberturas = {{$LisA=$numAciertos}}/{{$LisC= $numColumnas*$contador}}</div>
                </tbody>
              </table>
            </div>
       </div>

       {{-- Fin prueba --}}

       <!-- Tabs header -->
        <div class="nav-tabs-wrapper">
            <ul class="nav nav-tabs dragscroll horizontal">
                <li class="nav-item"><a class="nav-link active" data-toggle="tab" href="#tabA"><img src="{{asset('img/consentimientos-icon.svg')}}" alt="">Carátula <br>{{$caratulaA}}/{{$caratulaC}}</a></li>
                <li class="nav-item"><a class="nav-link" data-toggle="tab" href="#tabB"><img src="{{asset('img/consentimientos-icon.svg')}}" alt="">Consentimientos <br>{{$conA}}/{{$conC}}</a></li>
                <li class="nav-item"><a class="nav-link" data-toggle="tab" href="#tabC"><img src="{{asset('img/detalle-icon.svg')}}" alt="">Detalle coberturas <br>{{$DetA}}/{{$DetC}}</a></li>
                <li class="nav-item"><a class="nav-link" data-toggle="tab" href="#tabD"><img src="{{asset('img/endosos-icon.svg')}}" alt="">Endosos especiales <br>{{$EnA}}/{{$EnC}}</a></li>
                <li class="nav-item"><a class="nav-link" data-toggle="tab" href="#tabE"><img src="{{asset('img/asegurados-icon.svg')}}" alt="">Listado asegurados <br>{{$LisA}}/{{$LisC}}</a></li>
            </ul>
        </div>
      </div>
         <div class="tab-content">
            {{-- Carátula --}}
              <div class="tab-pane fade show active" id="tabA">
                {{-- Carátula / Datos --}}
                <div class="table-title">Datos</div>
                <table class="table table-hover table-responsive ">
                  <thead>
                    <tr class="fixed-table">
                      {{-- <th scope="col">Poliza</th> --}}
                      <th scope="col">Pagina</th>
                      <th scope="col">Plazo</th>
                      <th scope="col">Forma de Pago</th>
                      <th scope="col">Contributorio</th>
                      <th scope="col">Inicio Vigencia</th>
                      <th scope="col">Fin Vigencia</th>
                      <th scope="col">Tipo de Administracion</th>
                      <th scope="col">Datos del contratante</th>
                      <th scope="col">Prima Neta</th>
                      <th scope="col">Recargos</th>
                      <th scope="col">Gastos expedición</th>
                      <th scope="col">IVA</th>
                      <th scope="col">Prima Total</th>
                      <th scope="col">Moneda</th>
                      <span class="d-none">{{$numColumnas=13}}</span>
                    </tr>
                  </thead>
                  <tbody>
                    @foreach($caratula_datos as $caratula_dato)
                    <tr>
                      {{-- <th scope="row">{{$caratula_dato->noPoliza}}</th> --}}
                      <td>{{$caratula_dato->pagina}}</td>
                      <td>
                        @if($caratula_dato->plazo == 1)
                        <div class="checkdiv"><input disabled checked type="checkbox" class="le-checkbox"/></div>
                        <span class="d-none">{{$numAciertos++}}</span>
                        @elseif($caratula_dato->plazo == 0)
                        <div class="checkdiv"><input disabled  type="checkbox" class="le-checkbox"/></div>
                        @else
                        <img src="{{ asset('img/unknown.png') }}" alt="" width="32">
                        @endif
                      </td>
                      <td>
                        @if($caratula_dato->formaDePago == 1)
                        <span class="d-none">{{$numAciertos++}}</span>
                        <div class="checkdiv"><input disabled checked type="checkbox" class="le-checkbox"/></div>
                        @elseif($caratula_dato->formaDePago == 0)
                        <div class="checkdiv"><input disabled  type="checkbox" class="le-checkbox"/></div>
                        @else
                        <img src="{{ asset('img/unknown.png') }}" alt="" width="32">
                        @endif
                      </td>
                      <td>
                        @if($caratula_dato->contributorio == 1)
                        <span class="d-none">{{$numAciertos++}}</span>
                        <div class="checkdiv"><input disabled checked type="checkbox" class="le-checkbox"/></div>
                        @elseif($caratula_dato->contributorio == 0)
                        <div class="checkdiv"><input disabled  type="checkbox" class="le-checkbox"/></div>
                        @else
                        <img src="{{ asset('img/unknown.png') }}" alt="" width="32">
                        @endif
                      </td>
                      <td>
                        @if($caratula_dato->inicioVigencia == 1)
                        <span class="d-none">{{$numAciertos++}}</span>
                        <div class="checkdiv"><input disabled checked type="checkbox" class="le-checkbox"/></div>
                        @elseif($caratula_dato->inicioVigencia == 0)
                        <div class="checkdiv"><input disabled  type="checkbox" class="le-checkbox"/></div>
                        @else
                        <img src="{{ asset('img/unknown.png') }}" alt="" width="32">
                        @endif
                      </td>
                      <td>
                        @if($caratula_dato->finVigencia == 1)
                        <span class="d-none">{{$numAciertos++}}</span>
                        <div class="checkdiv"><input disabled checked type="checkbox" class="le-checkbox"/></div>
                        @elseif($caratula_dato->finVigencia == 0)
                        <div class="checkdiv"><input disabled  type="checkbox" class="le-checkbox"/></div>
                        @else
                        <img src="{{ asset('img/unknown.png') }}" alt="" width="32">
                        @endif
                      </td>
                      <td>
                        @if($caratula_dato->tipoDeAdministracion == 1)
                        <span class="d-none">{{$numAciertos++}}</span>
                        <div class="checkdiv"><input disabled checked type="checkbox" class="le-checkbox"/></div>
                        @elseif($caratula_dato->tipoDeAdministracion == 0)
                        <div class="checkdiv"><input disabled  type="checkbox" class="le-checkbox"/></div>
                        @else
                        <img src="{{ asset('img/unknown.png') }}" alt="" width="32">
                        @endif
                      </td>
                      <td>
                        @if($caratula_dato->datosDelContratante == 1)
                        <span class="d-none">{{$numAciertos++}}</span>
                        <div class="checkdiv"><input disabled checked type="checkbox" class="le-checkbox"/></div>
                        @elseif($caratula_dato->datosDelContratante == 0)
                        <div class="checkdiv"><input disabled  type="checkbox" class="le-checkbox"/></div>
                        @else
                        <img src="{{ asset('img/unknown.png') }}" alt="" width="32">
                        @endif
                      </td>
                      <td>
                        @if($caratula_dato->primaNeta == 1)
                        <span class="d-none">{{$numAciertos++}}</span>
                        <div class="checkdiv"><input disabled checked type="checkbox" class="le-checkbox"/></div>
                        @elseif($caratula_dato->primaNeta == 0)
                        <div class="checkdiv"><input disabled  type="checkbox" class="le-checkbox"/></div>
                        @else
                        <img src="{{ asset('img/unknown.png') }}" alt="" width="32">
                        @endif
                      </td>
                      <td>
                        @if($caratula_dato->recargos == 1)
                        <span class="d-none">{{$numAciertos++}}</span>
                        <div class="checkdiv"><input disabled checked type="checkbox" class="le-checkbox"/></div>
                        @elseif($caratula_dato->recargos == 0)
                        <div class="checkdiv"><input disabled  type="checkbox" class="le-checkbox"/></div>
                        @else
                        <img src="{{ asset('img/unknown.png') }}" alt="" width="32">
                        @endif
                      </td>
                      <td>
                        @if($caratula_dato->gtosExpedicion == 1)
                        <span class="d-none">{{$numAciertos++}}</span>
                        <div class="checkdiv"><input disabled checked type="checkbox" class="le-checkbox"/></div>
                        @elseif($caratula_dato->gtosExpedicion == 0)
                        <div class="checkdiv"><input disabled  type="checkbox" class="le-checkbox"/></div>
                        @else
                        <img src="{{ asset('img/unknown.png') }}" alt="" width="32">
                        @endif
                      </td>
                      <td>
                        @if($caratula_dato->IVA == 1)
                        <span class="d-none">{{$numAciertos++}}</span>
                        <div class="checkdiv"><input disabled checked type="checkbox" class="le-checkbox"/></div>
                        @elseif($caratula_dato->IVA == 0)
                        <div class="checkdiv"><input disabled  type="checkbox" class="le-checkbox"/></div>
                        @else
                        <img src="{{ asset('img/unknown.png') }}" alt="" width="32">
                        @endif
                      </td>
                      <td>
                        @if($caratula_dato->primaTotal == 1)
                        <span class="d-none">{{$numAciertos++}}</span>
                        <div class="checkdiv"><input disabled checked type="checkbox" class="le-checkbox"/></div>
                        @elseif($caratula_dato->primaTotal == 0)
                        <div class="checkdiv"><input disabled  type="checkbox" class="le-checkbox"/></div>
                        @else
                        <img src="{{ asset('img/unknown.png') }}" alt="" width="32">
                        @endif
                      </td>
                      <td>
                        @if($caratula_dato->moneda == 1)
                        <span class="d-none">{{$numAciertos++}}</span>
                        <div class="checkdiv"><input disabled checked type="checkbox" class="le-checkbox"/></div>
                        @elseif($caratula_dato->moneda == 0)
                        <div class="checkdiv"><input disabled  type="checkbox" class="le-checkbox"/></div>
                        @else
                        <img src="{{ asset('img/unknown.png') }}" alt="" width="32">
                        @endif
                      </td>
                    </tr>
                    <span class="d-none">{{ $contador++ }}</span>
                    @endforeach
                    <div class="btn-success d-none">Aciertos Datos= {{$numAciertos}}/{{ $numColumnas*$contador}}</div>
                  </tbody>
                </table>
                {{-- Guardar datos de tabla 1 --}}
                <span class="d-none">{{$guardarAciertos=$numAciertos, $guardarColumnas=$numColumnas*$contador}}</span>
               {{--  {{$guardarAciertos}}
                {{$guardarColumnas}} --}}
                {{-- Carátula / Coberturas --}}
                <div class="table-title">Coberturas</div>
                <span class="d-none">{{$numAciertos=0, $numColumnas=0, $contador=0}}</span>
                <table class="table table-hover  table-responsive ">
                  <thead>
                    <tr class="fixed-table">
                      {{-- <th scope="col">Poliza</th> --}}
                      <th scope="col">Pagina</th>
                      <th scope="col">Cobertura</th>
                      <th scope="col">Suma Asegurada</th>
                      <th scope="col">Prima Neta</th>
                      <span class="d-none">{{$numColumnas=2}}</span>
                    </tr>
                  </thead>
                    {{-- <span class="d-none">{{ $caratulaI=0 }}</span> --}}
                  <tbody>
                    @foreach($caratula_coberturas as $caratula_cobertura)
                    <tr>
                      {{-- <th scope="row">{{$caratula_dato->noPoliza}}</th> --}}
                      <td>{{$caratula_cobertura->pagina}}</td>
                      <td>
                        {{$caratula_cobertura->cobertura}}
                      </td>
                      <td>
                        @if($caratula_cobertura->sumaAsegurada == 1)
                        <div class="checkdiv"><input disabled checked type="checkbox" class="le-checkbox"/></div>
                        <span class="d-none">{{$numAciertos++}}</span>

                        @elseif($caratula_cobertura->sumaAsegurada == 0)
                        <div class="checkdiv"><input disabled  type="checkbox" class="le-checkbox"/></div>
                        @else
                        <img src="{{ asset('img/unknown.png') }}" alt="" width="32">
                        @endif
                      </td>
                      <td>
                        @if($caratula_cobertura->primaNeta == 1)
                        <span class="d-none">{{$numAciertos++}}</span>
                        <div class="checkdiv"><input disabled checked type="checkbox" class="le-checkbox"/></div>
                        @elseif($caratula_cobertura->primaNeta == 0)
                        <div class="checkdiv"><input disabled  type="checkbox" class="le-checkbox"/></div>
                        @else
                        <img src="{{ asset('img/unknown.png') }}" alt="" width="32">
                        @endif
                      </td>
                    </tr>
                    <span class="d-none">{{ $contador++ }}</span>
                    @endforeach
                    <div class="btn-success d-none">Aciertos Coberturas = {{$numAciertos}}/{{ $numColumnas*$contador}}</div>
                  </tbody>
                </table>
                <span class="d-none">{{$guardarAciertos=$guardarAciertos+$numAciertos, $guardarColumnas=$guardarColumnas+($numColumnas*$contador)}}</span>

                {{-- Datos finales --}}
                <div class="btn-success d-none position-absolute">{{$guardarAciertos}}/{{$guardarColumnas}}</div>

                   {{--  <div class="btn-success">{{$caratulaVD+$caratulaVC}}/{{ $caratulaNumC*$caratulaI+$caratulaNumD*$caratulaI}}</div> --}}
              </div>

            {{-- Consentimientos --}}
              <div class="tab-pane fade" id="tabB">
                <form class="d-flex w-25" id="searchform" onkeyup="filterConsentimientos()">
                  <input class="form-control me-2 d-flex shadow-none" type="text" placeholder="No. de certificado" id="searchConsentimientos">
                  <button type="submit" disabled><img src="{{asset('img/search.svg')}}"  alt="" ></button/>
                </form>
                <span class="d-none">{{$numAciertos=0, $contador=0}}</span>
                <table class="table table-hover table-responsive ">
                  <thead>
                    <tr class="fixed-table">
                      {{-- <th scope="col">Poliza</th> --}}
                      <th scope="col">Certificado</th>
                      <th scope="col">Nombre</th>
                      <th scope="col">Sexo</th>
                      <th scope="col">Edad</th>
                      <th scope="col">Fecha de Nacimiento</th>
                      <th scope="col">Datos del contratante</th>
                      <th scope="col">Plazo</th>
                      <th scope="col">Forma de Pago</th>
                      <th scope="col">Contributorio</th>
                      <th scope="col">Inicio Vigencia</th>
                      <th scope="col">Fin Vigencia</th>
                      <th scope="col">Moneda</th>
                      <span class="d-none">{{$numColumnas=11}}</span>
                    </tr>
                  </thead>
                  <tbody id="tbody-consentimientos_vida_datos">
                    @foreach($consentimientos_vida_datos as $consentimientos_vida_dato)
                    <tr class="tr-consentimientos_vida_datos">
                      <td class="tr-td-certificado-consentimientos_vida_datos">{{$consentimientos_vida_dato->certificado}}</td>
                      <td>
                        @if($consentimientos_vida_dato->nombre == 1)
                        <span class="d-none">{{$numAciertos++}}</span>
                        <div class="checkdiv"><input disabled checked type="checkbox" class="le-checkbox"/></div>
                        @elseif($consentimientos_vida_dato->nombre == 0)
                        <div class="checkdiv"><input disabled  type="checkbox" class="le-checkbox"/></div>
                        @else
                        <img src="{{ asset('img/unknown.png') }}" alt="" width="32">
                        @endif
                      </td>
                      <td>
                        @if($consentimientos_vida_dato->sexo == 1)
                        <span class="d-none">{{$numAciertos++}}</span>
                        <div class="checkdiv"><input disabled checked type="checkbox" class="le-checkbox"/></div>
                        @elseif($consentimientos_vida_dato->nombre == 0)
                        <div class="checkdiv"><input disabled  type="checkbox" class="le-checkbox"/></div>
                        @else
                        <img src="{{ asset('img/unknown.png') }}" alt="" width="32">
                        @endif
                      </td>
                      <td>
                        @if($consentimientos_vida_dato->edad == 1)
                        <span class="d-none">{{$numAciertos++}}</span>
                        <div class="checkdiv"><input disabled checked type="checkbox" class="le-checkbox"/></div>
                        @elseif($consentimientos_vida_dato->edad == 0)
                        <div class="checkdiv"><input disabled  type="checkbox" class="le-checkbox"/></div>
                        @else
                        <img src="{{ asset('img/unknown.png') }}" alt="" width="32">
                        @endif
                      </td>
                      <td>
                        @if($consentimientos_vida_dato->fechaDeNacimiento == 1)
                        <span class="d-none">{{$numAciertos++}}</span>
                        <div class="checkdiv"><input disabled checked type="checkbox" class="le-checkbox"/></div>
                        @elseif($consentimientos_vida_dato->fechaDeNacimiento == 0)
                        <div class="checkdiv"><input disabled  type="checkbox" class="le-checkbox"/></div>
                        @else
                        <img src="{{ asset('img/unknown.png') }}" alt="" width="32">
                        @endif
                      </td>
                      <td>
                        @if($consentimientos_vida_dato->datosDelContratante == 1)
                        <span class="d-none">{{$numAciertos++}}</span>
                        <div class="checkdiv"><input disabled checked type="checkbox" class="le-checkbox"/></div>
                        @elseif($consentimientos_vida_dato->datosDelContratante == 0)
                        <div class="checkdiv"><input disabled  type="checkbox" class="le-checkbox"/></div>
                        @else
                        <img src="{{ asset('img/unknown.png') }}" alt="" width="32">
                        @endif
                      </td>
                      <td>
                        @if($consentimientos_vida_dato->plazo == 1)
                        <span class="d-none">{{$numAciertos++}}</span>
                        <div class="checkdiv"><input disabled checked type="checkbox" class="le-checkbox"/></div>
                        @elseif($consentimientos_vida_dato->plazo == 0)
                        <div class="checkdiv"><input disabled  type="checkbox" class="le-checkbox"/></div>
                        @else
                        <img src="{{ asset('img/unknown.png') }}" alt="" width="32">
                        @endif
                      </td>
                      <td>
                        @if($consentimientos_vida_dato->formaDePago == 1)
                        <span class="d-none">{{$numAciertos++}}</span>
                        <div class="checkdiv"><input disabled checked type="checkbox" class="le-checkbox"/></div>
                        @elseif($consentimientos_vida_dato->formaDePago == 0)
                        <div class="checkdiv"><input disabled  type="checkbox" class="le-checkbox"/></div>
                        @else
                        <img src="{{ asset('img/unknown.png') }}" alt="" width="32">
                        @endif
                      </td>
                      <td>
                        @if($consentimientos_vida_dato->contributorio == 1)
                        <span class="d-none">{{$numAciertos++}}</span>
                        <div class="checkdiv"><input disabled checked type="checkbox" class="le-checkbox"/></div>
                        @elseif($consentimientos_vida_dato->contributorio == 0)
                        <div class="checkdiv"><input disabled  type="checkbox" class="le-checkbox"/></div>
                        @else
                        <img src="{{ asset('img/unknown.png') }}" alt="" width="32">
                        @endif
                      </td>
                      <td>
                        @if($consentimientos_vida_dato->inicioVigencia == 1)
                        <span class="d-none">{{$numAciertos++}}</span>
                        <div class="checkdiv"><input disabled checked type="checkbox" class="le-checkbox"/></div>
                        @elseif($consentimientos_vida_dato->inicioVigencia == 0)
                        <div class="checkdiv"><input disabled  type="checkbox" class="le-checkbox"/></div>
                        @else
                        <img src="{{ asset('img/unknown.png') }}" alt="" width="32">
                        @endif
                      </td>
                      <td>
                        @if($consentimientos_vida_dato->finVigencia == 1)
                        <span class="d-none">{{$numAciertos++}}</span>
                        <div class="checkdiv"><input disabled checked type="checkbox" class="le-checkbox"/></div>
                        @elseif($consentimientos_vida_dato->finVigencia == 0)
                        <div class="checkdiv"><input disabled  type="checkbox" class="le-checkbox"/></div>
                        @else
                        <img src="{{ asset('img/unknown.png') }}" alt="" width="32">
                        @endif
                      </td>
                      <td>
                        @if($consentimientos_vida_dato->moneda == 1)
                        <span class="d-none">{{$numAciertos++}}</span>
                        <div class="checkdiv"><input disabled checked type="checkbox" class="le-checkbox"/></div>
                        @elseif($consentimientos_vida_dato->moneda == 0)
                        <div class="checkdiv"><input disabled  type="checkbox" class="le-checkbox"/></div>
                        @else
                        <img src="{{ asset('img/unknown.png') }}" alt="" width="32">
                        @endif
                      </td>
                      <span class="d-none">{{$contador++}}</span>
                    </tr>
                      {{-- <span class="d-none">{{}}</span> --}}
                    @endforeach
                    <div class="btn-success d-none">Aciertos Coberturas = {{$numAciertos}}/{{ $numColumnas*$contador}}</div>
                  </tbody>
                </table>
              </div>

            {{-- Detalle coberturas --}}
              <div class="tab-pane fade" id="tabC">
                {{-- Detalle coberturas / Datos --}}
                <div class="table-title">Datos</div>
                <span class="d-none">{{$numAciertos=0, $contador=0}}</span>
                <table class="table table-hover table-responsive">
                  <thead>
                    <tr class="fixed-table">
                      {{-- <th scope="col">Poliza</th> --}}
                      <th scope="col">Pagina</th>
                      <th scope="col">Plazo</th>
                      <th scope="col">Forma de Pago</th>
                      <th scope="col">Contributorio</th>
                      <th scope="col">Inicio Vigencia</th>
                      <th scope="col">Fin Vigencia</th>
                      <th scope="col">Asegurados</th>
                      <th scope="col">Datos del contratante</th>
                      <th scope="col">Prima Neta</th>
                      <th scope="col">Recargos</th>
                      <th scope="col">Gastos expedición</th>
                      <th scope="col">IVA</th>
                      <th scope="col">Prima Total</th>
                      <th scope="col">Moneda</th>
                      <span class="d-none">{{$numColumnas=13}}</span>
                    </tr>
                  </thead>
                  <tbody>
                    @foreach($detalle_cobertura_datos as $detalle_cobertura_dato)
                    <tr>
                      {{-- <th scope="row">{{$detalle_cobertura_dato->noPoliza}}</th> --}}
                      <td>{{$detalle_cobertura_dato->pagina}}</td>
                      <td>
                        @if($detalle_cobertura_dato->plazo == 1)
                        <div class="checkdiv"><input disabled checked type="checkbox" class="le-checkbox"/></div>
                        <span class="d-none">{{$numAciertos++}}</span>
                        @elseif($detalle_cobertura_dato->plazo == 0)
                        <div class="checkdiv"><input disabled  type="checkbox" class="le-checkbox"/></div>
                        @else
                        <img src="{{ asset('img/unknown.png') }}" alt="" width="32">
                        @endif
                      </td>
                      <td>
                        @if($detalle_cobertura_dato->formaDePago == 1)
                        <span class="d-none">{{$numAciertos++}}</span>
                        <div class="checkdiv"><input disabled checked type="checkbox" class="le-checkbox"/></div>
                        @elseif($detalle_cobertura_dato->formaDePago == 0)
                        <div class="checkdiv"><input disabled  type="checkbox" class="le-checkbox"/></div>
                        @else
                        <img src="{{ asset('img/unknown.png') }}" alt="" width="32">
                        @endif
                      </td>
                      <td>
                        @if($detalle_cobertura_dato->contributorio == 1)
                        <span class="d-none">{{$numAciertos++}}</span>
                        <div class="checkdiv"><input disabled checked type="checkbox" class="le-checkbox"/></div>
                        @elseif($detalle_cobertura_dato->contributorio == 0)
                        <div class="checkdiv"><input disabled  type="checkbox" class="le-checkbox"/></div>
                        @else
                        <img src="{{ asset('img/unknown.png') }}" alt="" width="32">
                        @endif
                      </td>
                      <td>
                        @if($detalle_cobertura_dato->inicioVigencia == 1)
                        <span class="d-none">{{$numAciertos++}}</span>
                        <div class="checkdiv"><input disabled checked type="checkbox" class="le-checkbox"/></div>
                        @elseif($detalle_cobertura_dato->inicioVigencia == 0)
                        <div class="checkdiv"><input disabled  type="checkbox" class="le-checkbox"/></div>
                        @else
                        <img src="{{ asset('img/unknown.png') }}" alt="" width="32">
                        @endif
                      </td>
                      <td>
                        @if($detalle_cobertura_dato->finVigencia == 1)
                        <span class="d-none">{{$numAciertos++}}</span>
                        <div class="checkdiv"><input disabled checked type="checkbox" class="le-checkbox"/></div>
                        @elseif($detalle_cobertura_dato->finVigencia == 0)
                        <div class="checkdiv"><input disabled  type="checkbox" class="le-checkbox"/></div>
                        @else
                        <img src="{{ asset('img/unknown.png') }}" alt="" width="32">
                        @endif
                      </td>
                      <td>
                        @if($detalle_cobertura_dato->asegurados == 1)
                        <span class="d-none">{{$numAciertos++}}</span>
                        <div class="checkdiv"><input disabled checked type="checkbox" class="le-checkbox"/></div>
                        @elseif($detalle_cobertura_dato->asegurados == 0)
                        <div class="checkdiv"><input disabled  type="checkbox" class="le-checkbox"/></div>
                        @else
                        <img src="{{ asset('img/unknown.png') }}" alt="" width="32">
                        @endif
                      </td>
                      <td>
                        @if($detalle_cobertura_dato->datosDelContratante == 1)
                        <span class="d-none">{{$numAciertos++}}</span>
                        <div class="checkdiv"><input disabled checked type="checkbox" class="le-checkbox"/></div>
                        @elseif($detalle_cobertura_dato->datosDelContratante == 0)
                        <div class="checkdiv"><input disabled  type="checkbox" class="le-checkbox"/></div>
                        @else
                        <img src="{{ asset('img/unknown.png') }}" alt="" width="32">
                        @endif
                      </td>
                      <td>
                        @if($detalle_cobertura_dato->primaNeta == 1)
                        <span class="d-none">{{$numAciertos++}}</span>
                        <div class="checkdiv"><input disabled checked type="checkbox" class="le-checkbox"/></div>
                        @elseif($detalle_cobertura_dato->primaNeta == 0)
                        <div class="checkdiv"><input disabled  type="checkbox" class="le-checkbox"/></div>
                        @else
                        <img src="{{ asset('img/unknown.png') }}" alt="" width="32">
                        @endif
                      </td>
                      <td>
                        @if($detalle_cobertura_dato->recargos == 1)
                        <span class="d-none">{{$numAciertos++}}</span>
                        <div class="checkdiv"><input disabled checked type="checkbox" class="le-checkbox"/></div>
                        @elseif($detalle_cobertura_dato->recargos == 0)
                        <div class="checkdiv"><input disabled  type="checkbox" class="le-checkbox"/></div>
                        @else
                        <img src="{{ asset('img/unknown.png') }}" alt="" width="32">
                        @endif
                      </td>
                      <td>
                        @if($detalle_cobertura_dato->gtosExpedicion == 1)
                        <span class="d-none">{{$numAciertos++}}</span>
                        <div class="checkdiv"><input disabled checked type="checkbox" class="le-checkbox"/></div>
                        @elseif($detalle_cobertura_dato->gtosExpedicion == 0)
                        <div class="checkdiv"><input disabled  type="checkbox" class="le-checkbox"/></div>
                        @else
                        <img src="{{ asset('img/unknown.png') }}" alt="" width="32">
                        @endif
                      </td>
                      <td>
                        @if($detalle_cobertura_dato->IVA == 1)
                        <span class="d-none">{{$numAciertos++}}</span>
                        <div class="checkdiv"><input disabled checked type="checkbox" class="le-checkbox"/></div>
                        @elseif($detalle_cobertura_dato->IVA == 0)
                        <div class="checkdiv"><input disabled  type="checkbox" class="le-checkbox"/></div>
                        @else
                        <img src="{{ asset('img/unknown.png') }}" alt="" width="32">
                        @endif
                      </td>
                      <td>
                        @if($detalle_cobertura_dato->primaTotal == 1)
                        <span class="d-none">{{$numAciertos++}}</span>
                        <div class="checkdiv"><input disabled checked type="checkbox" class="le-checkbox"/></div>
                        @elseif($detalle_cobertura_dato->primaTotal == 0)
                        <div class="checkdiv"><input disabled  type="checkbox" class="le-checkbox"/></div>
                        @else
                        <img src="{{ asset('img/unknown.png') }}" alt="" width="32">
                        @endif
                      </td>
                      <td>
                        @if($detalle_cobertura_dato->moneda == 1)
                        <span class="d-none">{{$numAciertos++}}</span>
                        <div class="checkdiv"><input disabled checked type="checkbox" class="le-checkbox"/></div>
                        @elseif($detalle_cobertura_dato->moneda == 0)
                        <div class="checkdiv"><input disabled  type="checkbox" class="le-checkbox"/></div>
                        @else
                        <img src="{{ asset('img/unknown.png') }}" alt="" width="32">
                        @endif
                      </td>
                    </tr>
                    <span class="d-none">{{ $contador++ }}</span>
                    @endforeach
                    <div class="btn-success d-none">Aciertos Datos= {{$numAciertos}}/{{ $numColumnas*$contador}}</div>
                  </tbody>
                </table>
                {{-- Guardar datos   --}}
                <span class="d-none">{{$guardarAciertos=$numAciertos, $guardarColumnas=$numColumnas*$contador}}</span>
                {{-- {{$guardarAciertos}}
                {{$guardarColumnas}} --}}
                {{-- Detalle coberturas / Coberturas --}}
                <div class="table-title">Datos</div>
                <span class="d-none">{{$numAciertos=0, $numColumnas=0, $contador=0}}</span>
                <table class="table table-hover  table-responsive ">
                  <thead>
                    <tr class="fixed-table">
                      <th scope="col">Pagina</th>
                      <th scope="col">Cobertura</th>
                      <th scope="col">Prima Neta</th>
                      <span class="d-none">{{$numColumnas=1}}</span>
                    </tr>
                  </thead>
                  <tbody>
                    @foreach($detalle_cobertura_coberturas as $detalle_cobertura_cobertura)
                    <tr>
                      {{-- <th scope="row">{{$caratula_dato->noPoliza}}</th> --}}
                      <td>{{$detalle_cobertura_cobertura->pagina}}</td>
                      <td>
                        {{$detalle_cobertura_cobertura->cobertura}}
                      </td>
                      <td>
                        @if($detalle_cobertura_cobertura->primaNeta == 1)
                        <span class="d-none">{{$numAciertos++}}</span>
                        <div class="checkdiv"><input disabled checked type="checkbox" class="le-checkbox"/></div>
                        @elseif($detalle_cobertura_cobertura->primaNeta == 0)
                        <div class="checkdiv"><input disabled  type="checkbox" class="le-checkbox"/></div>
                        @else
                        <img src="{{ asset('img/unknown.png') }}" alt="" width="32">
                        @endif
                      </td>
                    </tr>
                    <span class="d-none">{{ $contador++ }}</span>
                    @endforeach
                    <div class="btn-success d-none">Aciertos Coberturas = {{$numAciertos}}/{{ $numColumnas*$contador}}</div>
                  </tbody>
                </table>
                <span class="d-none">{{$guardarAciertos=$guardarAciertos+$numAciertos, $guardarColumnas=$guardarColumnas+($numColumnas*$contador)}}</span>

                {{-- Datos finales --}}
                <div class="btn-success d-none position-absolute">{{$guardarAciertos}}/{{$guardarColumnas}}</div>
              </div>

            {{-- Endosos especiales --}}
              <div class="tab-pane fade" id="tabD">
                <span class="d-none">{{$numAciertos=0, $contador=0}}</span>
                <table class="table table-hover table-responsive">
                  <thead>
                    <tr class="fixed-table">
                      {{-- <th scope="col">Poliza</th> --}}
                      <th scope="col">Subgrupo</th>
                      <th scope="col">Categoría</th>
                      <th scope="col">Endoso</th>
                      <th scope="col">Valor</th>
                      <span class="d-none">{{$numColumnas=1}}</span>
                    </tr>
                  </thead>
                  <tbody>
                    @foreach($endosos as $endoso)
                    <tr>
                      {{-- <th scope="row">{{$endoso->noPoliza}}</th> --}}
                      <td>{{$endoso->subgrupo}}</td>
                      <td>{{$endoso->categoria}}</td>
                      <td>{{$endoso->endoso}}</td>
                      <td>
                        @if($endoso->valorEndoso == 1)
                        <div class="checkdiv"><input disabled checked type="checkbox" class="le-checkbox"/></div>
                        <span class="d-none">{{$numAciertos++}}</span>
                        @elseif($endoso->valorEndoso == 0)
                        <div class="checkdiv"><input disabled  type="checkbox" class="le-checkbox"/></div>
                        @else
                        <img src="{{ asset('img/unknown.png') }}" alt="" width="32">
                        @endif
                      </td>
                      <span class="d-none">{{$contador++}}</span>
                    </tr>
                    @endforeach
                    <div class="btn-success d-none">Aciertos Coberturas = {{$numAciertos}}/{{ $numColumnas*$contador}}</div>
                  </tbody>
                </table>
              </div>

            {{-- Listado asegurados --}}
              <div class="tab-pane fade" id="tabE">
                <form class="d-flex w-25" id="searchform" onkeyup="filterListado()">
                  <input class="form-control me-2 shadow-none" type="text" placeholder="No. de certificado" id="searchListado">
                  <button type="submit" disabled><img src="{{asset('img/search.svg')}}"  alt="" ></button/>
                  {{-- <button class="btn btn-outline-success" disabled type="submit">Search</button> --}}
                </form>
                {{-- <form class="d-flex w-25" id="searchform" onkeyup="filterListado()">
                  <input class="form-control me-2 d-flex shadow-none" type="text" placeholder="No. de certificado" id="searchListado">
                  <button type="submit" disabled><img src="{{asset('img/search.svg')}}"  alt="" ></button/>
                </form> --}}
                <span class="d-none">{{$numAciertos=0, $contador=0}}</span>

                <table class="table table-hover table-responsive ">
                  <thead>
                    <tr class="fixed-table">
                      {{-- <th scope="col">Poliza</th> --}}
                      <th scope="col">Certificado</th>
                      <th scope="col">Subgrupo</th>
                      <th scope="col">Categoría</th>
                      <th scope="col">Nombre</th>
                      <th scope="col">Antiguedad</th>
                      <th scope="col">Edad</th>
                      <th scope="col">Sexo</th>
                      <th scope="col">Fecha Alta/Baja</th>
                      <span class="d-none">{{$numColumnas=6}}</span>
                    </tr>
                  </thead>
                  <tbody id="tbody-listado_asegurados">
                    @foreach($listado_asegurados as $listado_asegurado)
                    <tr>
                      {{-- <th scope="row">{{$listado_asegurado->noPoliza}}</th> --}}
                      <td class="tr-td-certificado-listado_asegurados">{{$listado_asegurado->certificado}}</td>
                      <td>{{$listado_asegurado->subgrupo}}</td>
                      <td>
                        @if($listado_asegurado->categoria == 1)
                        <span class="d-none">{{$numAciertos++}}</span>
                        <div class="checkdiv"><input disabled checked type="checkbox" class="le-checkbox"/></div>
                        @elseif($listado_asegurado->categoria == 0)
                        <div class="checkdiv"><input disabled  type="checkbox" class="le-checkbox"/></div>
                        @else
                        <img src="{{ asset('img/unknown.png') }}" alt="" width="32">
                        @endif
                      </td>
                      <td>
                        @if($listado_asegurado->nombre == 1)
                        <span class="d-none">{{$numAciertos++}}</span>
                        <div class="checkdiv"><input disabled checked type="checkbox" class="le-checkbox"/></div>
                        @elseif($listado_asegurado->nombre == 0)
                        <div class="checkdiv"><input disabled  type="checkbox" class="le-checkbox"/></div>
                        @else
                        <img src="{{ asset('img/unknown.png') }}" alt="" width="32">
                        @endif
                      </td>
                      <td>
                        @if($listado_asegurado->antiguedad == 1)
                        <span class="d-none">{{$numAciertos++}}</span>
                        <div class="checkdiv"><input disabled checked type="checkbox" class="le-checkbox"/></div>
                        @elseif($listado_asegurado->antiguedad == 0)
                        <div class="checkdiv"><input disabled  type="checkbox" class="le-checkbox"/></div>
                        @else
                        <img src="{{ asset('img/unknown.png') }}" alt="" width="32">
                        @endif
                      </td>
                      <td>
                        @if($listado_asegurado->edad == 1)
                        <span class="d-none">{{$numAciertos++}}</span>
                        <div class="checkdiv"><input disabled checked type="checkbox" class="le-checkbox"/></div>
                        @elseif($listado_asegurado->edad == 0)
                        <div class="checkdiv"><input disabled  type="checkbox" class="le-checkbox"/></div>
                        @else
                        <img src="{{ asset('img/unknown.png') }}" alt="" width="32">
                        @endif
                      </td>
                      <td>
                        @if($listado_asegurado->sexo == 1)
                        <span class="d-none">{{$numAciertos++}}</span>
                        <div class="checkdiv"><input disabled checked type="checkbox" class="le-checkbox"/></div>
                        @elseif($listado_asegurado->sexo == 0)
                        <div class="checkdiv"><input disabled  type="checkbox" class="le-checkbox"/></div>
                        @else
                        <img src="{{ asset('img/unknown.png') }}" alt="" width="32">
                        @endif
                      </td>
                      <td>
                        @if($listado_asegurado->fechaAltaBaja == 1)
                        <span class="d-none">{{$numAciertos++}}</span>
                        <div class="checkdiv"><input disabled checked type="checkbox" class="le-checkbox"/></div>
                        @elseif($listado_asegurado->fechaAltaBaja == 0)
                        <div class="checkdiv"><input disabled  type="checkbox" class="le-checkbox"/></div>
                        @else
                        <img src="{{ asset('img/unknown.png') }}" alt="" width="32">
                        @endif
                      </td>
                      <span class="d-none">{{$contador++}}</span>
                    </tr>
                    @endforeach
                    <div class="btn-success d-none">Aciertos Coberturas = {{$numAciertos}}/{{ $numColumnas*$contador}}</div>
                  </tbody>
                </table>
              </div>
         </div>
       <!-- End Tabs -->

     </section>
    </main>
  </div>


@endsection
