<td class="d-none">
  <div class="tab-content">
     {{-- Carátula --}}
       <div class="tab-pane fade show active" id="tabA">
         {{-- Carátula / Datos --}}
         <h3 class="main-inter_h3">Datos</h3>
         <table class="table table-hover table-striped table-responsive table-bordered">
           <thead>
             <tr class="fixed-table">
               {{-- <th scope="col">Poliza</th> --}}
               <th scope="col">Pagina</th>
               <th scope="col">Plazo</th>
               <th scope="col">Forma de Pago</th>
               <th scope="col">Contributorio</th>
               <th scope="col">inicio Vigencia</th>
               <th scope="col">fin Vigencia</th>
               <th scope="col">tipoDeAdministracion</th>
               <th scope="col">Datos del contratante</th>
               <th scope="col">Prima Neta</th>
               <th scope="col">Recargos</th>
               <th scope="col">Gastos expedición</th>
               <th scope="col">IVA</th>
               <th scope="col">Prima Total</th>
               <th scope="col">Moneda</th>
               <span class="d-none">{{$numColumnas3=13}}</span>
             </tr>
           </thead>
           <tbody>
             @foreach($caratula_datos3 as $caratula_dato)
             <tr>
               {{-- <th scope="row">{{$caratula_dato->noPoliza}}</th> --}}
               <td>{{$caratula_dato->pagina}}</td>
               <td>
                 @if($caratula_dato->plazo == 1)
                 <div class="checkdiv"><input disabled checked type="checkbox" class="le-checkbox"/></div>
                 <span class="d-none">{{$numAciertos3++}}</span>
                 @elseif($caratula_dato->plazo == 0)
                 <div class="checkdiv"><input disabled  type="checkbox" class="le-checkbox"/></div>
                 @else
                 <img src="{{ asset('img/unknown.png') }}" alt="" width="32">
                 @endif
               </td>
               <td>
                 @if($caratula_dato->formaDePago == 1)
                 <span class="d-none">{{$numAciertos3++}}</span>
                 <div class="checkdiv"><input disabled checked type="checkbox" class="le-checkbox"/></div>
                 @elseif($caratula_dato->formaDePago == 0)
                 <div class="checkdiv"><input disabled  type="checkbox" class="le-checkbox"/></div>
                 @else
                 <img src="{{ asset('img/unknown.png') }}" alt="" width="32">
                 @endif
               </td>
               <td>
                 @if($caratula_dato->contributorio == 1)
                 <span class="d-none">{{$numAciertos3++}}</span>
                 <div class="checkdiv"><input disabled checked type="checkbox" class="le-checkbox"/></div>
                 @elseif($caratula_dato->contributorio == 0)
                 <div class="checkdiv"><input disabled  type="checkbox" class="le-checkbox"/></div>
                 @else
                 <img src="{{ asset('img/unknown.png') }}" alt="" width="32">
                 @endif
               </td>
               <td>
                 @if($caratula_dato->inicioVigencia == 1)
                 <span class="d-none">{{$numAciertos3++}}</span>
                 <div class="checkdiv"><input disabled checked type="checkbox" class="le-checkbox"/></div>
                 @elseif($caratula_dato->inicioVigencia == 0)
                 <div class="checkdiv"><input disabled  type="checkbox" class="le-checkbox"/></div>
                 @else
                 <img src="{{ asset('img/unknown.png') }}" alt="" width="32">
                 @endif
               </td>
               <td>
                 @if($caratula_dato->finVigencia == 1)
                 <span class="d-none">{{$numAciertos3++}}</span>
                 <div class="checkdiv"><input disabled checked type="checkbox" class="le-checkbox"/></div>
                 @elseif($caratula_dato->finVigencia == 0)
                 <div class="checkdiv"><input disabled  type="checkbox" class="le-checkbox"/></div>
                 @else
                 <img src="{{ asset('img/unknown.png') }}" alt="" width="32">
                 @endif
               </td>
               <td>
                 @if($caratula_dato->tipoDeAdministracion == 1)
                 <span class="d-none">{{$numAciertos3++}}</span>
                 <div class="checkdiv"><input disabled checked type="checkbox" class="le-checkbox"/></div>
                 @elseif($caratula_dato->tipoDeAdministracion == 0)
                 <div class="checkdiv"><input disabled  type="checkbox" class="le-checkbox"/></div>
                 @else
                 <img src="{{ asset('img/unknown.png') }}" alt="" width="32">
                 @endif
               </td>
               <td>
                 @if($caratula_dato->datosDelContratante == 1)
                 <span class="d-none">{{$numAciertos3++}}</span>
                 <div class="checkdiv"><input disabled checked type="checkbox" class="le-checkbox"/></div>
                 @elseif($caratula_dato->datosDelContratante == 0)
                 <div class="checkdiv"><input disabled  type="checkbox" class="le-checkbox"/></div>
                 @else
                 <img src="{{ asset('img/unknown.png') }}" alt="" width="32">
                 @endif
               </td>
               <td>
                 @if($caratula_dato->primaNeta == 1)
                 <span class="d-none">{{$numAciertos3++}}</span>
                 <div class="checkdiv"><input disabled checked type="checkbox" class="le-checkbox"/></div>
                 @elseif($caratula_dato->primaNeta == 0)
                 <div class="checkdiv"><input disabled  type="checkbox" class="le-checkbox"/></div>
                 @else
                 <img src="{{ asset('img/unknown.png') }}" alt="" width="32">
                 @endif
               </td>
               <td>
                 @if($caratula_dato->recargos == 1)
                 <span class="d-none">{{$numAciertos3++}}</span>
                 <div class="checkdiv"><input disabled checked type="checkbox" class="le-checkbox"/></div>
                 @elseif($caratula_dato->recargos == 0)
                 <div class="checkdiv"><input disabled  type="checkbox" class="le-checkbox"/></div>
                 @else
                 <img src="{{ asset('img/unknown.png') }}" alt="" width="32">
                 @endif
               </td>
               <td>
                 @if($caratula_dato->gtosExpedicion == 1)
                 <span class="d-none">{{$numAciertos3++}}</span>
                 <div class="checkdiv"><input disabled checked type="checkbox" class="le-checkbox"/></div>
                 @elseif($caratula_dato->gtosExpedicion == 0)
                 <div class="checkdiv"><input disabled  type="checkbox" class="le-checkbox"/></div>
                 @else
                 <img src="{{ asset('img/unknown.png') }}" alt="" width="32">
                 @endif
               </td>
               <td>
                 @if($caratula_dato->IVA == 1)
                 <span class="d-none">{{$numAciertos3++}}</span>
                 <div class="checkdiv"><input disabled checked type="checkbox" class="le-checkbox"/></div>
                 @elseif($caratula_dato->IVA == 0)
                 <div class="checkdiv"><input disabled  type="checkbox" class="le-checkbox"/></div>
                 @else
                 <img src="{{ asset('img/unknown.png') }}" alt="" width="32">
                 @endif
               </td>
               <td>
                 @if($caratula_dato->primaTotal == 1)
                 <span class="d-none">{{$numAciertos3++}}</span>
                 <div class="checkdiv"><input disabled checked type="checkbox" class="le-checkbox"/></div>
                 @elseif($caratula_dato->primaTotal == 0)
                 <div class="checkdiv"><input disabled  type="checkbox" class="le-checkbox"/></div>
                 @else
                 <img src="{{ asset('img/unknown.png') }}" alt="" width="32">
                 @endif
               </td>
               <td>
                 @if($caratula_dato->moneda == 1)
                 <span class="d-none">{{$numAciertos3++}}</span>
                 <div class="checkdiv"><input disabled checked type="checkbox" class="le-checkbox"/></div>
                 @elseif($caratula_dato->moneda == 0)
                 <div class="checkdiv"><input disabled  type="checkbox" class="le-checkbox"/></div>
                 @else
                 <img src="{{ asset('img/unknown.png') }}" alt="" width="32">
                 @endif
               </td>
             </tr>
             <span class="d-none">{{ $contador3++ }}</span>
             @endforeach
             <div class="btn-success">Aciertos Datos= {{$numAciertos3}}/{{ $numColumnas3*$contador3}}</div>
           </tbody>
         </table>
         {{-- Guardar datos de tabla 1 --}}
         <span class="d-none">{{$guardarAciertos3=$numAciertos3, $guardarColumnas3=$numColumnas3*$contador3}}</span>
         {{$guardarAciertos3}}
         {{$guardarColumnas3}}
          <span class="d-none">{{$totalAciertos=$totalAciertos+$numAciertos3, $totalColumnas=$totalColumnas+($numColumnas3*$contador3)}}</span>

         {{-- Carátula / Coberturas --}}
         <h3 class="main-inter_h3">Coberturas</h3>
         <span class="d-none">{{$numAciertos3=0, $numColumnas3=0, $contador3=0}}</span>
         <table class="table table-hover table-striped table-responsive table-bordered">
           <thead>
             <tr class="fixed-table">
               {{-- <th scope="col">Poliza</th> --}}
               <th scope="col">Pagina</th>
               <th scope="col">Cobertura</th>
               <th scope="col">Suma Asegurada</th>
               <th scope="col">Prima Neta</th>
               <span class="d-none">{{$numColumnas3=2}}</span>
             </tr>
           </thead>
             {{-- <span class="d-none">{{ $caratulaI=0 }}</span> --}}
           <tbody>
             @foreach($caratula_coberturas2 as $caratula_cobertura)
             <tr>
               {{-- <th scope="row">{{$caratula_dato->noPoliza}}</th> --}}
               <td>{{$caratula_cobertura->pagina}}</td>
               <td>
                 {{$caratula_cobertura->cobertura}}
               </td>
               <td>
                 @if($caratula_cobertura->sumaAsegurada == 1)
                 <div class="checkdiv"><input disabled checked type="checkbox" class="le-checkbox"/></div>
                 <span class="d-none">{{$numAciertos3++}}</span>

                 @elseif($caratula_cobertura->sumaAsegurada == 0)
                 <div class="checkdiv"><input disabled  type="checkbox" class="le-checkbox"/></div>
                 @else
                 <img src="{{ asset('img/unknown.png') }}" alt="" width="32">
                 @endif
               </td>
               <td>
                 @if($caratula_cobertura->primaNeta == 1)
                 <span class="d-none">{{$numAciertos3++}}</span>
                 <div class="checkdiv"><input disabled checked type="checkbox" class="le-checkbox"/></div>
                 @elseif($caratula_cobertura->primaNeta == 0)
                 <div class="checkdiv"><input disabled  type="checkbox" class="le-checkbox"/></div>
                 @else
                 <img src="{{ asset('img/unknown.png') }}" alt="" width="32">
                 @endif
               </td>
             </tr>
             <span class="d-none">{{ $contador3++ }}</span>
             @endforeach
             <div class="btn-success">Aciertos Coberturas = {{$numAciertos3}}/{{ $numColumnas3*$contador3}}</div>
           </tbody>
         </table>
         <span class="d-none">{{$guardarAciertos3=$guardarAciertos3+$numAciertos3, $guardarColumnas3=$guardarColumnas3+($numColumnas3*$contador3)}}</span>

         {{-- Datos finales --}}
         <div class="btn-success position-absolute">{{$guardarAciertos3}}/{{$guardarColumnas3}}</div>
         <div class="btn-success position-absolute">{{$totalAciertos=$guardarAciertos3}}/{{$totalColumnas=$guardarColumnas3}}</div>


            {{--  <div class="btn-success">{{$caratulaVD+$caratulaVC}}/{{ $caratulaNumC*$caratulaI+$caratulaNumD*$caratulaI}}</div> --}}
       </div>

     {{-- Consentimientos --}}
       <div class="tab-pane fade" id="tabB">
         <form class="d-flex w-25" id="searchform" onkeyup="filterConsentimientos()">
           <input class="form-control me-2" type="text" placeholder="Busca por # de certificado " id="searchConsentimientos">
           {{-- <button class="btn btn-outline-success" disabled type="submit">Search</button> --}}
         </form>
         <span class="d-none">{{$numAciertos3=0, $contador3=0}}</span>
         <table class="table table-hover table-striped table-responsive table-bordered">
           <thead>
             <tr class="fixed-table">
               {{-- <th scope="col">Poliza</th> --}}
               <th scope="col">Certificado</th>
               <th scope="col">Nombre</th>
               <th scope="col">Sexo</th>
               <th scope="col">Edad</th>
               <th scope="col">Fecha de Nacimiento</th>
               <th scope="col">Datos del contratante</th>
               <th scope="col">Plazo</th>
               <th scope="col">Forma de Pago</th>
               <th scope="col">Contributorio</th>
               <th scope="col">Inicio Vigencia</th>
               <th scope="col">Fin Vigencia</th>
               <th scope="col">Moneda</th>
               <span class="d-none">{{$numColumnas3=11}}</span>
             </tr>
           </thead>
           <tbody id="tbody-consentimientos_vida_datos3">
             @foreach($consentimientos_vida_datos3 as $consentimientos_vida_dato)
             <tr class="tr-consentimientos_vida_datos3">
               <td class="tr-td-certificado-consentimientos_vida_datos3">{{$consentimientos_vida_dato->certificado}}</td>
               <td>
                 @if($consentimientos_vida_dato->nombre == 1)
                 <span class="d-none">{{$numAciertos3++}}</span>
                 <div class="checkdiv"><input disabled checked type="checkbox" class="le-checkbox"/></div>
                 @elseif($consentimientos_vida_dato->nombre == 0)
                 <div class="checkdiv"><input disabled  type="checkbox" class="le-checkbox"/></div>
                 @else
                 <img src="{{ asset('img/unknown.png') }}" alt="" width="32">
                 @endif
               </td>
               <td>
                 @if($consentimientos_vida_dato->sexo == 1)
                 <span class="d-none">{{$numAciertos3++}}</span>
                 <div class="checkdiv"><input disabled checked type="checkbox" class="le-checkbox"/></div>
                 @elseif($consentimientos_vida_dato->nombre == 0)
                 <div class="checkdiv"><input disabled  type="checkbox" class="le-checkbox"/></div>
                 @else
                 <img src="{{ asset('img/unknown.png') }}" alt="" width="32">
                 @endif
               </td>
               <td>
                 @if($consentimientos_vida_dato->edad == 1)
                 <span class="d-none">{{$numAciertos3++}}</span>
                 <div class="checkdiv"><input disabled checked type="checkbox" class="le-checkbox"/></div>
                 @elseif($consentimientos_vida_dato->edad == 0)
                 <div class="checkdiv"><input disabled  type="checkbox" class="le-checkbox"/></div>
                 @else
                 <img src="{{ asset('img/unknown.png') }}" alt="" width="32">
                 @endif
               </td>
               <td>
                 @if($consentimientos_vida_dato->fechaDeNacimiento == 1)
                 <span class="d-none">{{$numAciertos3++}}</span>
                 <div class="checkdiv"><input disabled checked type="checkbox" class="le-checkbox"/></div>
                 @elseif($consentimientos_vida_dato->fechaDeNacimiento == 0)
                 <div class="checkdiv"><input disabled  type="checkbox" class="le-checkbox"/></div>
                 @else
                 <img src="{{ asset('img/unknown.png') }}" alt="" width="32">
                 @endif
               </td>
               <td>
                 @if($consentimientos_vida_dato->datosDelContratante == 1)
                 <span class="d-none">{{$numAciertos3++}}</span>
                 <div class="checkdiv"><input disabled checked type="checkbox" class="le-checkbox"/></div>
                 @elseif($consentimientos_vida_dato->datosDelContratante == 0)
                 <div class="checkdiv"><input disabled  type="checkbox" class="le-checkbox"/></div>
                 @else
                 <img src="{{ asset('img/unknown.png') }}" alt="" width="32">
                 @endif
               </td>
               <td>
                 @if($consentimientos_vida_dato->plazo == 1)
                 <span class="d-none">{{$numAciertos3++}}</span>
                 <div class="checkdiv"><input disabled checked type="checkbox" class="le-checkbox"/></div>
                 @elseif($consentimientos_vida_dato->plazo == 0)
                 <div class="checkdiv"><input disabled  type="checkbox" class="le-checkbox"/></div>
                 @else
                 <img src="{{ asset('img/unknown.png') }}" alt="" width="32">
                 @endif
               </td>
               <td>
                 @if($consentimientos_vida_dato->formaDePago == 1)
                 <span class="d-none">{{$numAciertos3++}}</span>
                 <div class="checkdiv"><input disabled checked type="checkbox" class="le-checkbox"/></div>
                 @elseif($consentimientos_vida_dato->formaDePago == 0)
                 <div class="checkdiv"><input disabled  type="checkbox" class="le-checkbox"/></div>
                 @else
                 <img src="{{ asset('img/unknown.png') }}" alt="" width="32">
                 @endif
               </td>
               <td>
                 @if($consentimientos_vida_dato->contributorio == 1)
                 <span class="d-none">{{$numAciertos3++}}</span>
                 <div class="checkdiv"><input disabled checked type="checkbox" class="le-checkbox"/></div>
                 @elseif($consentimientos_vida_dato->contributorio == 0)
                 <div class="checkdiv"><input disabled  type="checkbox" class="le-checkbox"/></div>
                 @else
                 <img src="{{ asset('img/unknown.png') }}" alt="" width="32">
                 @endif
               </td>
               <td>
                 @if($consentimientos_vida_dato->inicioVigencia == 1)
                 <span class="d-none">{{$numAciertos3++}}</span>
                 <div class="checkdiv"><input disabled checked type="checkbox" class="le-checkbox"/></div>
                 @elseif($consentimientos_vida_dato->inicioVigencia == 0)
                 <div class="checkdiv"><input disabled  type="checkbox" class="le-checkbox"/></div>
                 @else
                 <img src="{{ asset('img/unknown.png') }}" alt="" width="32">
                 @endif
               </td>
               <td>
                 @if($consentimientos_vida_dato->finVigencia == 1)
                 <span class="d-none">{{$numAciertos3++}}</span>
                 <div class="checkdiv"><input disabled checked type="checkbox" class="le-checkbox"/></div>
                 @elseif($consentimientos_vida_dato->finVigencia == 0)
                 <div class="checkdiv"><input disabled  type="checkbox" class="le-checkbox"/></div>
                 @else
                 <img src="{{ asset('img/unknown.png') }}" alt="" width="32">
                 @endif
               </td>
               <td>
                 @if($consentimientos_vida_dato->moneda == 1)
                 <span class="d-none">{{$numAciertos3++}}</span>
                 <div class="checkdiv"><input disabled checked type="checkbox" class="le-checkbox"/></div>
                 @elseif($consentimientos_vida_dato->moneda == 0)
                 <div class="checkdiv"><input disabled  type="checkbox" class="le-checkbox"/></div>
                 @else
                 <img src="{{ asset('img/unknown.png') }}" alt="" width="32">
                 @endif
               </td>
               <span class="d-none">{{$contador3++}}</span>
             </tr>
               {{-- <span class="d-none">{{}}</span> --}}
             @endforeach
             <div class="btn-success">Aciertos Coberturas = {{$numAciertos3}}/{{ $numColumnas3*$contador3}}</div>
             <span class="d-none">{{$totalAciertos=$totalAciertos+$numAciertos3, $totalColumnas=$totalColumnas+($numColumnas3*$contador3)}}</span>
           </tbody>
         </table>
       </div>
     {{-- Detalle coberturas --}}
       <div class="tab-pane fade" id="tabC">
         {{-- Detalle coberturas / Datos --}}
         <h3 class="main-inter_h3">Datos</h3>
         <span class="d-none">{{$numAciertos3=0, $contador3=0}}</span>
         <table class="table table-hover table-striped table-responsive table-bordered">
           <thead>
             <tr class="fixed-table">
               {{-- <th scope="col">Poliza</th> --}}
               <th scope="col">Pagina</th>
               <th scope="col">Plazo</th>
               <th scope="col">Forma de Pago</th>
               <th scope="col">Contributorio</th>
               <th scope="col">inicio Vigencia</th>
               <th scope="col">fin Vigencia</th>
               <th scope="col">asegurados</th>
               <th scope="col">Datos del contratante</th>
               <th scope="col">Prima Neta</th>
               <th scope="col">Recargos</th>
               <th scope="col">Gastos expedición</th>
               <th scope="col">IVA</th>
               <th scope="col">Prima Total</th>
               <th scope="col">Moneda</th>
               <span class="d-none">{{$numColumnas3=13}}</span>
             </tr>
           </thead>
           <tbody>
             @foreach($detalle_cobertura_datos3 as $detalle_cobertura_dato)
             <tr>
               {{-- <th scope="row">{{$detalle_cobertura_dato->noPoliza}}</th> --}}
               <td>{{$detalle_cobertura_dato->pagina}}</td>
               <td>
                 @if($detalle_cobertura_dato->plazo == 1)
                 <div class="checkdiv"><input disabled checked type="checkbox" class="le-checkbox"/></div>
                 <span class="d-none">{{$numAciertos3++}}</span>
                 @elseif($detalle_cobertura_dato->plazo == 0)
                 <div class="checkdiv"><input disabled  type="checkbox" class="le-checkbox"/></div>
                 @else
                 <img src="{{ asset('img/unknown.png') }}" alt="" width="32">
                 @endif
               </td>
               <td>
                 @if($detalle_cobertura_dato->formaDePago == 1)
                 <span class="d-none">{{$numAciertos3++}}</span>
                 <div class="checkdiv"><input disabled checked type="checkbox" class="le-checkbox"/></div>
                 @elseif($detalle_cobertura_dato->formaDePago == 0)
                 <div class="checkdiv"><input disabled  type="checkbox" class="le-checkbox"/></div>
                 @else
                 <img src="{{ asset('img/unknown.png') }}" alt="" width="32">
                 @endif
               </td>
               <td>
                 @if($detalle_cobertura_dato->contributorio == 1)
                 <span class="d-none">{{$numAciertos3++}}</span>
                 <div class="checkdiv"><input disabled checked type="checkbox" class="le-checkbox"/></div>
                 @elseif($detalle_cobertura_dato->contributorio == 0)
                 <div class="checkdiv"><input disabled  type="checkbox" class="le-checkbox"/></div>
                 @else
                 <img src="{{ asset('img/unknown.png') }}" alt="" width="32">
                 @endif
               </td>
               <td>
                 @if($detalle_cobertura_dato->inicioVigencia == 1)
                 <span class="d-none">{{$numAciertos3++}}</span>
                 <div class="checkdiv"><input disabled checked type="checkbox" class="le-checkbox"/></div>
                 @elseif($detalle_cobertura_dato->inicioVigencia == 0)
                 <div class="checkdiv"><input disabled  type="checkbox" class="le-checkbox"/></div>
                 @else
                 <img src="{{ asset('img/unknown.png') }}" alt="" width="32">
                 @endif
               </td>
               <td>
                 @if($detalle_cobertura_dato->finVigencia == 1)
                 <span class="d-none">{{$numAciertos3++}}</span>
                 <div class="checkdiv"><input disabled checked type="checkbox" class="le-checkbox"/></div>
                 @elseif($detalle_cobertura_dato->finVigencia == 0)
                 <div class="checkdiv"><input disabled  type="checkbox" class="le-checkbox"/></div>
                 @else
                 <img src="{{ asset('img/unknown.png') }}" alt="" width="32">
                 @endif
               </td>
               <td>
                 @if($detalle_cobertura_dato->asegurados == 1)
                 <span class="d-none">{{$numAciertos3++}}</span>
                 <div class="checkdiv"><input disabled checked type="checkbox" class="le-checkbox"/></div>
                 @elseif($detalle_cobertura_dato->asegurados == 0)
                 <div class="checkdiv"><input disabled  type="checkbox" class="le-checkbox"/></div>
                 @else
                 <img src="{{ asset('img/unknown.png') }}" alt="" width="32">
                 @endif
               </td>
               <td>
                 @if($detalle_cobertura_dato->datosDelContratante == 1)
                 <span class="d-none">{{$numAciertos3++}}</span>
                 <div class="checkdiv"><input disabled checked type="checkbox" class="le-checkbox"/></div>
                 @elseif($detalle_cobertura_dato->datosDelContratante == 0)
                 <div class="checkdiv"><input disabled  type="checkbox" class="le-checkbox"/></div>
                 @else
                 <img src="{{ asset('img/unknown.png') }}" alt="" width="32">
                 @endif
               </td>
               <td>
                 @if($detalle_cobertura_dato->primaNeta == 1)
                 <span class="d-none">{{$numAciertos3++}}</span>
                 <div class="checkdiv"><input disabled checked type="checkbox" class="le-checkbox"/></div>
                 @elseif($detalle_cobertura_dato->primaNeta == 0)
                 <div class="checkdiv"><input disabled  type="checkbox" class="le-checkbox"/></div>
                 @else
                 <img src="{{ asset('img/unknown.png') }}" alt="" width="32">
                 @endif
               </td>
               <td>
                 @if($detalle_cobertura_dato->recargos == 1)
                 <span class="d-none">{{$numAciertos3++}}</span>
                 <div class="checkdiv"><input disabled checked type="checkbox" class="le-checkbox"/></div>
                 @elseif($detalle_cobertura_dato->recargos == 0)
                 <div class="checkdiv"><input disabled  type="checkbox" class="le-checkbox"/></div>
                 @else
                 <img src="{{ asset('img/unknown.png') }}" alt="" width="32">
                 @endif
               </td>
               <td>
                 @if($detalle_cobertura_dato->gtosExpedicion == 1)
                 <span class="d-none">{{$numAciertos3++}}</span>
                 <div class="checkdiv"><input disabled checked type="checkbox" class="le-checkbox"/></div>
                 @elseif($detalle_cobertura_dato->gtosExpedicion == 0)
                 <div class="checkdiv"><input disabled  type="checkbox" class="le-checkbox"/></div>
                 @else
                 <img src="{{ asset('img/unknown.png') }}" alt="" width="32">
                 @endif
               </td>
               <td>
                 @if($detalle_cobertura_dato->IVA == 1)
                 <span class="d-none">{{$numAciertos3++}}</span>
                 <div class="checkdiv"><input disabled checked type="checkbox" class="le-checkbox"/></div>
                 @elseif($detalle_cobertura_dato->IVA == 0)
                 <div class="checkdiv"><input disabled  type="checkbox" class="le-checkbox"/></div>
                 @else
                 <img src="{{ asset('img/unknown.png') }}" alt="" width="32">
                 @endif
               </td>
               <td>
                 @if($detalle_cobertura_dato->primaTotal == 1)
                 <span class="d-none">{{$numAciertos3++}}</span>
                 <div class="checkdiv"><input disabled checked type="checkbox" class="le-checkbox"/></div>
                 @elseif($detalle_cobertura_dato->primaTotal == 0)
                 <div class="checkdiv"><input disabled  type="checkbox" class="le-checkbox"/></div>
                 @else
                 <img src="{{ asset('img/unknown.png') }}" alt="" width="32">
                 @endif
               </td>
               <td>
                 @if($detalle_cobertura_dato->moneda == 1)
                 <span class="d-none">{{$numAciertos3++}}</span>
                 <div class="checkdiv"><input disabled checked type="checkbox" class="le-checkbox"/></div>
                 @elseif($detalle_cobertura_dato->moneda == 0)
                 <div class="checkdiv"><input disabled  type="checkbox" class="le-checkbox"/></div>
                 @else
                 <img src="{{ asset('img/unknown.png') }}" alt="" width="32">
                 @endif
               </td>
             </tr>
             <span class="d-none">{{ $contador3++ }}</span>
             @endforeach
             <div class="btn-success">Aciertos Datos= {{$numAciertos3}}/{{ $numColumnas3*$contador3}}</div>
           </tbody>
         </table>
         {{-- Guardar datos   --}}
         <span class="d-none">{{$guardarAciertos3=$numAciertos3, $guardarColumnas3=$numColumnas3*$contador3}}</span>
         <span class="d-none">{{$totalAciertos=$totalAciertos+$numAciertos3, $totalColumnas=$totalColumnas+($numColumnas3*$contador3)}}</span>

         {{$guardarAciertos3}}
         {{$guardarColumnas3}}
         {{-- Detalle coberturas / Coberturas --}}
         <h3 class="main-inter_h3">Coberturas</h3>
         <span class="d-none">{{$numAciertos3=0, $numColumnas3=0, $contador3=0}}</span>
         <table class="table table-hover table-striped table-responsive table-bordered">
           <thead>
             <tr class="fixed-table">
               <th scope="col">Pagina</th>
               <th scope="col">Cobertura</th>
               <th scope="col">Prima Neta</th>
               <span class="d-none">{{$numColumnas3=1}}</span>
             </tr>
           </thead>
           <tbody>
             @foreach($detalle_cobertura_coberturas3 as $detalle_cobertura_cobertura)
             <tr>
               {{-- <th scope="row">{{$caratula_dato->noPoliza}}</th> --}}
               <td>{{$detalle_cobertura_cobertura->pagina}}</td>
               <td>
                 {{$detalle_cobertura_cobertura->cobertura}}
               </td>
               <td>
                 @if($detalle_cobertura_cobertura->primaNeta == 1)
                 <span class="d-none">{{$numAciertos3++}}</span>
                 <div class="checkdiv"><input disabled checked type="checkbox" class="le-checkbox"/></div>
                 @elseif($detalle_cobertura_cobertura->primaNeta == 0)
                 <div class="checkdiv"><input disabled  type="checkbox" class="le-checkbox"/></div>
                 @else
                 <img src="{{ asset('img/unknown.png') }}" alt="" width="32">
                 @endif
               </td>
             </tr>
             <span class="d-none">{{ $contador3++ }}</span>
             @endforeach
             <div class="btn-success">Aciertos Coberturas = {{$numAciertos3}}/{{ $numColumnas3*$contador3}}</div>
           </tbody>
         </table>
         <span class="d-none">{{$guardarAciertos3=$guardarAciertos3+$numAciertos3, $guardarColumnas3=$guardarColumnas3+($numColumnas3*$contador3)}}</span>
         <span class="d-none">{{$totalAciertos=$totalAciertos+$numAciertos3, $totalColumnas=$totalColumnas+($numColumnas3*$contador3)}}</span>
         {{-- Datos finales --}}
         <div class="btn-success position-absolute">{{$guardarAciertos3}}/{{$guardarColumnas3}}</div>

       </div>
     {{-- endosos3 especiales --}}
       <div class="tab-pane fade" id="tabD">
         <span class="d-none">{{$numAciertos3=0, $contador3=0}}</span>
         <table class="table table-hover table-striped table-responsive">
           <thead>
             <tr class="fixed-table">
               {{-- <th scope="col">Poliza</th> --}}
               <th scope="col">Subgrupo</th>
               <th scope="col">Categoría</th>
               <th scope="col">Endoso</th>
               <th scope="col">Valor</th>
               <span class="d-none">{{$numColumnas3=1}}</span>
             </tr>
           </thead>
           <tbody>
             @foreach($endosos3 as $endoso)
             <tr>
               {{-- <th scope="row">{{$endoso->noPoliza}}</th> --}}
               <td>{{$endoso->subgrupo}}</td>
               <td>{{$endoso->categoria}}</td>
               <td>{{$endoso->endoso}}</td>
               <td>
                 @if($endoso->valorEndoso == 1)
                 <div class="checkdiv"><input disabled checked type="checkbox" class="le-checkbox"/></div>
                 <span class="d-none">{{$numAciertos3++}}</span>
                 @elseif($endoso->valorEndoso == 0)
                 <div class="checkdiv"><input disabled  type="checkbox" class="le-checkbox"/></div>
                 @else
                 <img src="{{ asset('img/unknown.png') }}" alt="" width="32">
                 @endif
               </td>
               <span class="d-none">{{$contador3++}}</span>
             </tr>
             @endforeach
             <div class="btn-success">Aciertos Coberturas = {{$numAciertos3}}/{{ $numColumnas3*$contador3}}</div>
             <span class="d-none">{{$totalAciertos=$totalAciertos+$numAciertos3, $totalColumnas=$totalColumnas+($numColumnas3*$contador3)}}</span>
           </tbody>
         </table>
       </div>
     {{-- Listado asegurados --}}
       <div class="tab-pane fade" id="tabE">
         <form class="d-flex w-25" id="searchform" onkeyup="filterListado()">
           <input class="form-control me-2" type="text" placeholder="Busca por # de certificado " id="searchListado">
           {{-- <button class="btn btn-outline-success" disabled type="submit">Search</button> --}}
         </form>
         <span class="d-none">{{$numAciertos3=0, $contador3=0}}</span>

         <table class="table table-hover table-striped table-responsive table-bordered">
           <thead>
             <tr class="fixed-table">
               {{-- <th scope="col">Poliza</th> --}}
               <th scope="col">Certificado</th>
               <th scope="col">Subgrupo</th>
               <th scope="col">Categoría</th>
               <th scope="col">Nombre</th>
               <th scope="col">Antiguedad</th>
               <th scope="col">Edad</th>
               <th scope="col">Sexo</th>
               <th scope="col">FechaAltaBaja</th>
               <span class="d-none">{{$numColumnas3=6}}</span>
             </tr>
           </thead>
           <tbody id="tbody-listado_asegurados3">
             @foreach($listado_asegurados3 as $listado_asegurado)
             <tr>
               {{-- <th scope="row">{{$listado_asegurado->noPoliza}}</th> --}}
               <td class="tr-td-certificado-listado_asegurados3">{{$listado_asegurado->certificado}}</td>
               <td>{{$listado_asegurado->subgrupo}}</td>
               <td>
                 @if($listado_asegurado->categoria == 1)
                 <span class="d-none">{{$numAciertos3++}}</span>
                 <div class="checkdiv"><input disabled checked type="checkbox" class="le-checkbox"/></div>
                 @elseif($listado_asegurado->categoria == 0)
                 <div class="checkdiv"><input disabled  type="checkbox" class="le-checkbox"/></div>
                 @else
                 <img src="{{ asset('img/unknown.png') }}" alt="" width="32">
                 @endif
               </td>
               <td>
                 @if($listado_asegurado->nombre == 1)
                 <span class="d-none">{{$numAciertos3++}}</span>
                 <div class="checkdiv"><input disabled checked type="checkbox" class="le-checkbox"/></div>
                 @elseif($listado_asegurado->nombre == 0)
                 <div class="checkdiv"><input disabled  type="checkbox" class="le-checkbox"/></div>
                 @else
                 <img src="{{ asset('img/unknown.png') }}" alt="" width="32">
                 @endif
               </td>
               <td>
                 @if($listado_asegurado->antiguedad == 1)
                 <span class="d-none">{{$numAciertos3++}}</span>
                 <div class="checkdiv"><input disabled checked type="checkbox" class="le-checkbox"/></div>
                 @elseif($listado_asegurado->antiguedad == 0)
                 <div class="checkdiv"><input disabled  type="checkbox" class="le-checkbox"/></div>
                 @else
                 <img src="{{ asset('img/unknown.png') }}" alt="" width="32">
                 @endif
               </td>
               <td>
                 @if($listado_asegurado->edad == 1)
                 <span class="d-none">{{$numAciertos3++}}</span>
                 <div class="checkdiv"><input disabled checked type="checkbox" class="le-checkbox"/></div>
                 @elseif($listado_asegurado->edad == 0)
                 <div class="checkdiv"><input disabled  type="checkbox" class="le-checkbox"/></div>
                 @else
                 <img src="{{ asset('img/unknown.png') }}" alt="" width="32">
                 @endif
               </td>
               <td>
                 @if($listado_asegurado->sexo == 1)
                 <span class="d-none">{{$numAciertos3++}}</span>
                 <div class="checkdiv"><input disabled checked type="checkbox" class="le-checkbox"/></div>
                 @elseif($listado_asegurado->sexo == 0)
                 <div class="checkdiv"><input disabled  type="checkbox" class="le-checkbox"/></div>
                 @else
                 <img src="{{ asset('img/unknown.png') }}" alt="" width="32">
                 @endif
               </td>
               <td>
                 @if($listado_asegurado->fechaAltaBaja == 1)
                 <span class="d-none">{{$numAciertos3++}}</span>
                 <div class="checkdiv"><input disabled checked type="checkbox" class="le-checkbox"/></div>
                 @elseif($listado_asegurado->fechaAltaBaja == 0)
                 <div class="checkdiv"><input disabled  type="checkbox" class="le-checkbox"/></div>
                 @else
                 <img src="{{ asset('img/unknown.png') }}" alt="" width="32">
                 @endif
               </td>
               <span class="d-none">{{$contador3++}}</span>
             </tr>
             @endforeach
             <div class="btn-success">Aciertos Coberturas = {{$numAciertos3}}/{{ $numColumnas3*$contador3}}</div>
             <span class="d-none">{{$totalAciertos=$totalAciertos+$numAciertos3, $totalColumnas=$totalColumnas+($numColumnas3*$contador3)}}</span>

           </tbody>
         </table>
       </div>
  </div>
</td>

